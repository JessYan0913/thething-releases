// 井字棋面板 —— 无 import / 无 JSX，define 在顶层同步调用。
// 可用全局：globalThis.__THETHING_PANEL__ = { React, ReactDOM, ui, define }

const { React } = globalThis.__THETHING_PANEL__
const h = React.createElement

// 所有可能的三连：横向 3、纵向 3、两条对角线
const LINES = [
  [0, 1, 2],
  [3, 4, 5],
  [6, 7, 8],
  [0, 3, 6],
  [1, 4, 7],
  [2, 5, 8],
  [0, 4, 8],
  [2, 4, 6],
]

// 返回 { player, line } 或 null。line 是获胜的三个格子下标，用于高亮。
function getWinner(board) {
  for (let i = 0; i < LINES.length; i += 1) {
    const line = LINES[i]
    const a = board[line[0]]
    if (a && a === board[line[1]] && a === board[line[2]]) {
      return { player: a, line: line }
    }
  }
  return null
}

function TicTacToe() {
  const [board, setBoard] = React.useState(function () {
    return [null, null, null, null, null, null, null, null, null]
  })
  const [turn, setTurn] = React.useState('X')
  const [lastMove, setLastMove] = React.useState(-1)
  const [score, setScore] = React.useState({ X: 0, O: 0, draw: 0 })

  const winner = React.useMemo(function () {
    return getWinner(board)
  }, [board])

  const filled = board.filter(Boolean).length
  const isDraw = !winner && filled === 9
  const isOver = Boolean(winner) || isDraw

  function play(index) {
    if (board[index] || isOver) return
    const next = board.slice()
    next[index] = turn

    const w = getWinner(next)
    const draw = !w && next.every(Boolean)

    if (w) {
      setScore(function (s) {
        const copy = { X: s.X, O: s.O, draw: s.draw }
        copy[w.player] += 1
        return copy
      })
    } else if (draw) {
      setScore(function (s) {
        return { X: s.X, O: s.O, draw: s.draw + 1 }
      })
    } else {
      setTurn(turn === 'X' ? 'O' : 'X')
    }

    setBoard(next)
    setLastMove(index)
  }

  function restart() {
    setBoard([null, null, null, null, null, null, null, null, null])
    setTurn('X')
    setLastMove(-1)
  }

  function clearScore() {
    setScore({ X: 0, O: 0, draw: 0 })
    restart()
  }

  const winSet = winner ? winner.line : []

  let status
  if (winner) {
    status = h('span', { className: 'ttt-status-win' }, winner.player + ' 获胜！')
  } else if (isDraw) {
    status = h('span', { className: 'ttt-status-draw' }, '平局，谁也没赢')
  } else {
    status = h(
      'span',
      { className: 'ttt-status-turn' },
      '轮到 ',
      h('strong', { className: 'ttt-mark ttt-mark-' + turn }, turn),
      ' 落子',
    )
  }

  const cells = board.map(function (value, index) {
    const classes = ['ttt-cell']
    if (value) classes.push('is-' + value)
    if (winSet.indexOf(index) !== -1) classes.push('is-win')
    if (index === lastMove) classes.push('is-last')

    return h(
      'button',
      {
        key: index,
        type: 'button',
        className: classes.join(' '),
        onClick: function () {
          play(index)
        },
        disabled: isOver || Boolean(value),
        'aria-label': '第 ' + (index + 1) + ' 格' + (value ? '，' + value : '，空'),
      },
      value ? h('span', { className: 'ttt-glyph' }, value) : null,
    )
  })

  return h(
    'div',
    { className: 'ttt-root' },
    h(
      'div',
      { className: 'ttt-head' },
      h('h2', { className: 'ttt-title' }, '井字棋'),
      h('div', { className: 'ttt-status' }, status),
    ),

    h('div', { className: 'ttt-board' }, cells),

    h(
      'div',
      { className: 'ttt-score' },
      h('span', { className: 'ttt-score-item' }, 'X ', h('b', null, String(score.X))),
      h('span', { className: 'ttt-score-item' }, 'O ', h('b', null, String(score.O))),
      h('span', { className: 'ttt-score-item' }, '平 ', h('b', null, String(score.draw))),
    ),

    h(
      'div',
      { className: 'ttt-actions' },
      h(
        'button',
        { type: 'button', className: 'ttt-btn ttt-btn-primary', onClick: restart },
        isOver ? '再来一局' : '重开',
      ),
      h(
        'button',
        { type: 'button', className: 'ttt-btn', onClick: clearScore },
        '清空比分',
      ),
    ),

    h('p', { className: 'ttt-hint' }, 'X 先手，轮流落子，先连成三子者胜。'),
  )
}

globalThis.__THETHING_PANEL__.define({
  'tic-tac-toe': function () {
    return TicTacToe
  },
})
