// 五子棋面板 —— 无 import / 无 JSX，define 在顶层同步调用。
// 可用全局：globalThis.__THETHING_PANEL__ = { React, ReactDOM, ui, define }

const { React } = globalThis.__THETHING_PANEL__
const h = React.createElement

const SIZE = 15 // 15 路棋盘
const EMPTY = 0
const BLACK = 1
const WHITE = 2

const DIRS = [
  [1, 0],
  [0, 1],
  [1, 1],
  [1, -1],
]

function createBoard() {
  return new Array(SIZE * SIZE).fill(EMPTY)
}

function inBoard(x, y) {
  return x >= 0 && y >= 0 && x < SIZE && y < SIZE
}

// 落子后判定胜负：从该点向四个方向延伸，返回成线的所有格子下标，未成线返回 null
function findWinLine(board, index, player) {
  const x0 = index % SIZE
  const y0 = Math.floor(index / SIZE)
  for (let d = 0; d < DIRS.length; d += 1) {
    const dx = DIRS[d][0]
    const dy = DIRS[d][1]
    const line = [index]
    // 正反两个方向分别延伸
    for (let sign = -1; sign <= 1; sign += 2) {
      for (let k = 1; k < SIZE; k += 1) {
        const nx = x0 + dx * k * sign
        const ny = y0 + dy * k * sign
        if (!inBoard(nx, ny)) break
        if (board[ny * SIZE + nx] !== player) break
        line.push(ny * SIZE + nx)
      }
    }
    if (line.length >= 5) {
      // 按行优先顺序排好，方便绘制高亮动画
      line.sort(function (a, b) {
        return a - b
      })
      return line
    }
  }
  return null
}

// 候选点：已有棋子周围 2 格内的空位（空盘时取天元）
function getCandidates(board) {
  const out = []
  let hasStone = false
  for (let y = 0; y < SIZE; y += 1) {
    for (let x = 0; x < SIZE; x += 1) {
      if (board[y * SIZE + x] === EMPTY) continue
      hasStone = true
      for (let dy = -2; dy <= 2; dy += 1) {
        for (let dx = -2; dx <= 2; dx += 1) {
          const nx = x + dx
          const ny = y + dy
          if (!inBoard(nx, ny)) continue
          const id = ny * SIZE + nx
          if (board[id] === EMPTY) out.push(id)
        }
      }
    }
  }
  if (!hasStone) return [Math.floor((SIZE * SIZE) / 2)]
  const uniq = Array.from(new Set(out))
  return uniq
}

// 窗口打分表：窗口内只有己方棋子时，按数量给分（天然覆盖跳活三等断点形状）
const WINDOW_SCORE = [0, 1, 12, 160, 2600, 200000]

// 在 (x,y) 落 player 子之后，这一点的进攻价值（只看自己形成的形状）
function attackScore(board, index, player) {
  const x0 = index % SIZE
  const y0 = Math.floor(index / SIZE)
  let total = 0
  for (let d = 0; d < DIRS.length; d += 1) {
    const dx = DIRS[d][0]
    const dy = DIRS[d][1]
    // 覆盖所有包含该点的长度 5 窗口
    for (let off = 0; off <= 4; off += 1) {
      const sx = x0 - dx * off
      const sy = y0 - dy * off
      const ex = sx + dx * 4
      const ey = sy + dy * 4
      if (!inBoard(sx, sy) || !inBoard(ex, ey)) continue
      let mine = 0
      let blocked = false
      for (let k = 0; k <= 4; k += 1) {
        const v = board[(sy + dy * k) * SIZE + (sx + dx * k)]
        if (v === player) mine += 1
        else if (v !== EMPTY) {
          blocked = true
          break
        }
      }
      if (blocked) continue
      // 该点上放的是自己的子，窗口内至少 1 个
      total += WINDOW_SCORE[mine]
    }
  }
  return total
}

// 综合评估：进攻 + 防守（对手在同点的收益），defense 权重区分难度
function evaluateMove(board, index, player, defense) {
  const attack = attackScore(board, index, player)
  const enemy = player === BLACK ? WHITE : BLACK
  const defend = attackScore(board, index, enemy)
  return attack + defend * defense
}

function pickAiMove(board, player, difficulty) {
  const candidates = getCandidates(board)
  if (candidates.length === 0) return -1
  const enemy = player === BLACK ? WHITE : BLACK

  // 能赢就赢
  for (let i = 0; i < candidates.length; i += 1) {
    const id = candidates[i]
    const probe = board.slice()
    probe[id] = player
    if (findWinLine(probe, id, player)) return id
  }
  // 对手下一步能赢就堵
  for (let i = 0; i < candidates.length; i += 1) {
    const id = candidates[i]
    const probe = board.slice()
    probe[id] = enemy
    if (findWinLine(probe, id, enemy)) return id
  }

  const defense = difficulty === 'easy' ? 0.35 : difficulty === 'medium' ? 0.85 : 1.05
  const scored = candidates.map(function (id) {
    return { id: id, score: evaluateMove(board, id, player, defense) }
  })
  scored.sort(function (a, b) {
    return b.score - a.score
  })

  if (difficulty === 'easy') {
    // 简单：前若干名里随机，且偶尔走差一点的点
    const pool = scored.slice(0, Math.min(8, scored.length))
    const pick = pool[Math.floor(Math.random() * pool.length)]
    return pick.id
  }
  if (difficulty === 'medium') {
    const pool = scored.slice(0, Math.min(2, scored.length))
    return pool[Math.floor(Math.random() * pool.length)].id
  }
  return scored[0].id
}

function Gomoku() {
  const [board, setBoard] = React.useState(createBoard)
  const [turn, setTurn] = React.useState(BLACK)
  const [history, setHistory] = React.useState([]) // 落子顺序，用于悔棋与重放
  const [winLine, setWinLine] = React.useState(null)
  const [mode, setMode] = React.useState('pve') // pve | pvp
  const [difficulty, setDifficulty] = React.useState('medium')
  const [score, setScore] = React.useState({ black: 0, white: 0, draw: 0 })
  const [thinking, setThinking] = React.useState(false)
  // 同一事件循环内的重复点击（批次未刷新前状态还是旧的）直接忽略，避免两个子落同一点
  const tickLock = React.useRef(false)

  const human = BLACK
  const ai = WHITE
  const gameOver = Boolean(winLine) || history.length === SIZE * SIZE

  function reset() {
    setBoard(createBoard())
    setTurn(BLACK)
    setHistory([])
    setWinLine(null)
    setThinking(false)
  }

  function switchMode(next) {
    setMode(next)
    reset()
  }

  // 落子核心：返回新盘面
  function place(currentBoard, index, player) {
    const next = currentBoard.slice()
    next[index] = player
    const line = findWinLine(next, index, player)
    return { board: next, line: line }
  }

  function commit(index, player) {
    if (tickLock.current) return
    if (board[index] !== EMPTY || gameOver) return
    tickLock.current = true
    setTimeout(function () {
      tickLock.current = false
    }, 0)
    const result = place(board, index, player)
    setBoard(result.board)
    setHistory(history.concat([{ index: index, player: player }]))
    if (result.line) {
      setWinLine(result.line)
      setScore(function (s) {
        const copy = { black: s.black, white: s.white, draw: s.draw }
        if (player === BLACK) copy.black += 1
        else copy.white += 1
        return copy
      })
      setTurn(player === BLACK ? WHITE : BLACK)
      return
    }
    if (result.board.filter(Boolean).length === SIZE * SIZE) {
      setScore(function (s) {
        return { black: s.black, white: s.white, draw: s.draw + 1 }
      })
    }
    setTurn(player === BLACK ? WHITE : BLACK)
  }

  function handleClick(index) {
    if (thinking || gameOver) return
    if (mode === 'pve' && turn !== human) return
    commit(index, turn)
  }

  function undo() {
    if (history.length === 0) return
    let steps = 1
    // 人机模式一次退两步，回到自己的回合
    if (mode === 'pve' && history.length >= 2 && history[history.length - 1].player === ai) {
      steps = 2
    }
    const keep = history.slice(0, history.length - steps)
    const nextBoard = createBoard()
    for (let i = 0; i < keep.length; i += 1) {
      nextBoard[keep[i].index] = keep[i].player
    }
    setHistory(keep)
    setBoard(nextBoard)
    setWinLine(null)
    setTurn(keep.length > 0 ? (keep[keep.length - 1].player === BLACK ? WHITE : BLACK) : BLACK)
    setThinking(false)
  }

  function clearScore() {
    setScore({ black: 0, white: 0, draw: 0 })
    reset()
  }

  // AI 走子：延迟一点，避免瞬落
  React.useEffect(
    function () {
      if (mode !== 'pve') return undefined
      if (gameOver) return undefined
      if (turn !== ai) return undefined
      setThinking(true)
      const timer = setTimeout(function () {
        const move = pickAiMove(board, ai, difficulty)
        setThinking(false)
        if (move < 0) return
        commit(move, ai)
      }, difficulty === 'easy' ? 240 : 380)
      return function () {
        clearTimeout(timer)
        setThinking(false)
      }
    },
    [turn, mode, gameOver, board, difficulty],
  )

  const winSet = winLine || []
  const lastMove = history.length > 0 ? history[history.length - 1].index : -1

  let statusText
  let statusClass = 'gm-status-turn'
  if (winLine) {
    const winner = board[winLine[0]]
    statusText = (winner === BLACK ? '黑棋' : '白棋') + ' 五子连线，获胜！'
    statusClass = 'gm-status-win'
  } else if (history.length === SIZE * SIZE) {
    statusText = '棋盘已满，平局'
    statusClass = 'gm-status-draw'
  } else if (mode === 'pve' && turn === ai) {
    statusText = thinking ? 'AI 思考中…' : '轮到 AI'
  } else {
    statusText = (turn === BLACK ? '黑棋' : '白棋') + ' 落子'
  }

  const cells = []
  // 网格线用绝对定位的细线画，交点正好落在每个格子的中心
  const gridLines = []
  for (let i = 0; i < SIZE; i += 1) {
    const pos = ((i + 0.5) / SIZE) * 100 + '%'
    gridLines.push(h('div', { key: 'v' + i, className: 'gm-line gm-line-v', style: { left: pos } }))
    gridLines.push(h('div', { key: 'hr' + i, className: 'gm-line gm-line-h', style: { top: pos } }))
  }
  const STARS = [
    [3, 3],
    [11, 3],
    [3, 11],
    [11, 11],
    [7, 7],
  ]
  const starDots = STARS.map(function (p) {
    return h('div', {
      key: 'star' + p[0] + '-' + p[1],
      className: 'gm-star',
      style: {
        left: ((p[0] + 0.5) / SIZE) * 100 + '%',
        top: ((p[1] + 0.5) / SIZE) * 100 + '%',
      },
    })
  })

  const boardChildren = [
    h('div', { key: 'overlay', className: 'gm-overlay' }, gridLines.concat(starDots)),
  ]
  for (let y = 0; y < SIZE; y += 1) {
    for (let x = 0; x < SIZE; x += 1) {
      const id = y * SIZE + x
      const value = board[id]
      const classes = ['gm-cell']
      if (value === BLACK) classes.push('is-black')
      if (value === WHITE) classes.push('is-white')
      if (winSet.indexOf(id) !== -1) classes.push('is-win')
      if (id === lastMove) classes.push('is-last')

      cells.push(
        h('button', {
          key: id,
          type: 'button',
          className: classes.join(' '),
          onClick: function () {
            handleClick(id)
          },
          disabled: Boolean(value) || gameOver || (mode === 'pve' && turn !== human),
          'aria-label': '第' + (y + 1) + '行第' + (x + 1) + '列',
        }),
      )
    }
  }

  return h(
    'div',
    { className: 'gm-root' },
    h(
      'div',
      { className: 'gm-head' },
      h('h2', { className: 'gm-title' }, '五子棋'),
      h('div', { className: 'gm-status ' + statusClass }, statusText),
    ),

    h('div', { className: 'gm-board-wrap' }, h('div', { className: 'gm-board' }, boardChildren.concat(cells))),

    h(
      'div',
      { className: 'gm-controls' },
      h(
        'div',
        { className: 'gm-group' },
        h('span', { className: 'gm-label' }, '模式'),
        h(
          'button',
          {
            type: 'button',
            className: 'gm-chip' + (mode === 'pve' ? ' is-on' : ''),
            onClick: function () {
              switchMode('pve')
            },
          },
          '人机',
        ),
        h(
          'button',
          {
            type: 'button',
            className: 'gm-chip' + (mode === 'pvp' ? ' is-on' : ''),
            onClick: function () {
              switchMode('pvp')
            },
          },
          '双人',
        ),
      ),
      mode === 'pve'
        ? h(
            'div',
            { className: 'gm-group' },
            h('span', { className: 'gm-label' }, '难度'),
            h(
              'button',
              {
                type: 'button',
                className: 'gm-chip' + (difficulty === 'easy' ? ' is-on' : ''),
                onClick: function () {
                  setDifficulty('easy')
                },
              },
              '简单',
            ),
            h(
              'button',
              {
                type: 'button',
                className: 'gm-chip' + (difficulty === 'medium' ? ' is-on' : ''),
                onClick: function () {
                  setDifficulty('medium')
                },
              },
              '普通',
            ),
            h(
              'button',
              {
                type: 'button',
                className: 'gm-chip' + (difficulty === 'hard' ? ' is-on' : ''),
                onClick: function () {
                  setDifficulty('hard')
                },
              },
              '困难',
            ),
          )
        : null,
    ),

    h(
      'div',
      { className: 'gm-score' },
      h('span', { className: 'gm-score-item' }, '黑 ', h('b', null, String(score.black))),
      h('span', { className: 'gm-score-item' }, '白 ', h('b', null, String(score.white))),
      h('span', { className: 'gm-score-item' }, '平 ', h('b', null, String(score.draw))),
    ),

    h(
      'div',
      { className: 'gm-actions' },
      h(
        'button',
        {
          type: 'button',
          className: 'gm-btn gm-btn-primary',
          onClick: reset,
        },
        gameOver ? '再来一局' : '重开',
      ),
      h(
        'button',
        {
          type: 'button',
          className: 'gm-btn',
          onClick: undo,
          disabled: history.length === 0,
        },
        '悔棋',
      ),
      h(
        'button',
        { type: 'button', className: 'gm-btn', onClick: clearScore },
        '清空比分',
      ),
    ),

    h(
      'p',
      { className: 'gm-hint' },
      '你执黑先行，点击落子，先连成五子者胜。人机模式下悔棋会一次退回两步。',
    ),
  )
}

globalThis.__THETHING_PANEL__.define({
  gomoku: function () {
    return Gomoku
  },
})
