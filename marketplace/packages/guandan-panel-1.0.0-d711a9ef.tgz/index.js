// ============================================================================
// 掼蛋 Agent 面板 —— 完整引擎 + 规则基线 agent + React UI
// 约束：无 import/export、无 JSX、define() 顶层同步调用
// 规则基准：竞技掼蛋竞赛规则（试行）2022 + 主流平台通用规则
// ============================================================================

// ----------------------------------------------------------------------------
// 常量与牌工具
// ----------------------------------------------------------------------------
const SUITS = ['S', 'H', 'C', 'D'] // 黑桃、红桃、梅花、方块
const RANK_TEXT = { 3: '3', 4: '4', 5: '5', 6: '6', 7: '7', 8: '8', 9: '9', 10: '10', 11: 'J', 12: 'Q', 13: 'K', 14: 'A', 15: '2' }
const RANK_OF_TEXT = Object.fromEntries(Object.entries(RANK_TEXT).map(([k, v]) => [v, Number(k)]))
const RANK_2 = 15
const RANK_A = 14
const SMALL_JOKER = 16
const BIG_JOKER = 17

// 牌面 rank 在顺子等连续性中的序号：2→1, 3→2, …, K→12, A→13
function rseq(r) {
  if (r === RANK_2) return 1
  if (r === RANK_A) return 13
  return r - 1
}
// 从序号回到 rank
function rseqBack(s) {
  if (s === 1) return RANK_2
  if (s === 13) return RANK_A
  return s + 1
}

// 5 张牌是否构成顺子连续（含 A2345 环绕：A 作 1）
function isSeq5(ranks) {
  const seq = ranks.map(rseq)
  if (seq.every((s, i) => i === 0 || s === seq[i - 1] + 1)) return true
  // A2345 环绕：集合 = {A,2,3,4,5}（排序后 [2,3,4,5,A] → seq [1,2,3,4,13]）
  if (ranks.includes(RANK_A) && ranks.includes(RANK_2)) {
    const others = ranks.filter((r) => r !== RANK_A && r !== RANK_2).sort((a, b) => a - b)
    return others.length === 3 && others[0] === 3 && others[1] === 4 && others[2] === 5
  }
  return false
}

// 有效点数（用于牌力比较）：大王17 > 小王16 > 级牌15 > A14 > … > 3 > 2(非级牌2)
function effRank(rank, level) {
  if (rank === BIG_JOKER) return 17
  if (rank === SMALL_JOKER) return 16
  if (rank === level) return 15
  if (rank === RANK_2) return 2
  return rank
}

// 是否为逢人配（红桃级牌）
function isWild(card, level) {
  return card.suit === 'H' && card.rank === level
}

function cardText(card) {
  if (card.rank === BIG_JOKER) return '大王'
  if (card.rank === SMALL_JOKER) return '小王'
  return RANK_TEXT[card.rank] + (card.suit === 'S' ? '♠' : card.suit === 'H' ? '♥' : card.suit === 'C' ? '♣' : '♦')
}

function cardsText(cards) {
  return cards.map(cardText).join(' ')
}

// ----------------------------------------------------------------------------
// 牌型识别（无配牌版）
// 返回 { type, eff, size } 或 null
// type: single/pair/triple/triple_pair/straight/straight_pair/plane/
//       bomb/straight_flush/four_joker
// ----------------------------------------------------------------------------
function detectPlain(cards, level) {
  const n = cards.length
  if (n === 0) return null
  // 王的处理：四大天王 / 单张王 / 同色王对子；三张王、混搭非法
  const jokers = cards.filter((c) => c.rank >= SMALL_JOKER)
  if (jokers.length > 0) {
    if (n === 4 && jokers.length === 4) {
      const ks = jokers.map((c) => c.rank).sort()
      if (ks[0] === SMALL_JOKER && ks[1] === SMALL_JOKER && ks[2] === BIG_JOKER && ks[3] === BIG_JOKER) {
        return { type: 'four_joker', eff: 99, size: 4 }
      }
      return null
    }
    if (n === 1 && jokers.length === 1) {
      return { type: 'single', eff: jokers[0].rank === BIG_JOKER ? 17 : 16, size: 1 }
    }
    if (n === 2 && jokers.length === 2) {
      if (jokers[0].rank === jokers[1].rank) {
        return { type: 'pair', eff: jokers[0].rank === BIG_JOKER ? 17 : 16, size: 2 }
      }
      return null
    }
    return null
  }

  const groups = {}
  for (const c of cards) {
    if (!groups[c.rank]) groups[c.rank] = []
    groups[c.rank].push(c)
  }
  const ranks = Object.keys(groups)
    .map(Number)
    .sort((a, b) => rseq(a) - rseq(b))
  const seq = ranks.map(rseq)

  // 单 rank
  if (ranks.length === 1) {
    const m = groups[ranks[0]].length
    const e = effRank(ranks[0], level)
    if (m === 1) return { type: 'single', eff: e, size: 1 }
    if (m === 2) return { type: 'pair', eff: e, size: 2 }
    if (m === 3) return { type: 'triple', eff: e, size: 3 }
    if (m >= 4 && m <= 10) return { type: 'bomb', eff: e, size: m }
    return null
  }
  // 三带二（3+2，两部分不同点数）
  if (n === 5 && ranks.length === 2) {
    const a = groups[ranks[0]].length
    const b = groups[ranks[1]].length
    if ((a === 3 && b === 2) || (a === 2 && b === 3)) {
      const tr = a === 3 ? ranks[0] : ranks[1]
      return { type: 'triple_pair', eff: effRank(tr, level), size: 5 }
    }
    return null
  }
  // 顺子 / 同花顺（5 张连续，允许 A2345）
  if (n === 5 && ranks.length === 5 && isSeq5(ranks)) {
    if (level === RANK_2 && ranks.some((r) => r === RANK_2)) return null // 打2时2是级牌不可入顺
    const sameSuit = cards.every((c) => c.suit === cards[0].suit)
    const maxEff = effRank(ranks[4], level)
    return { type: sameSuit ? 'straight_flush' : 'straight', eff: maxEff, size: 5 }
  }
  // 三连对（6 张，3 组对子连续）
  if (n === 6 && ranks.length === 3 && seq.every((s, i) => i === 0 || s === seq[i - 1] + 1) && ranks.every((r) => groups[r].length === 2)) {
    if (level === RANK_2 && ranks.some((r) => r === RANK_2)) return null
    return { type: 'straight_pair', eff: effRank(ranks[2], level), size: 6 }
  }
  // 钢板（6 张，2 组三张连续）
  if (n === 6 && ranks.length === 2 && seq[1] === seq[0] + 1 && ranks.every((r) => groups[r].length === 3)) {
    if (level === RANK_2 && ranks.some((r) => r === RANK_2)) return null
    return { type: 'plane', eff: effRank(ranks[1], level), size: 6 }
  }
  return null
}

// 带配牌（逢人配）的识别：枚举配牌变成的 rank（3..A 及 2），逐个跑 detectPlain
// 返回所有合法解释中【最强】的一个（炸弹层级优先，其次 eff）——出牌者总是把配牌配成最有利的
function detect(cards, level) {
  const wilds = cards.filter((c) => isWild(c, level))
  const rest = cards.filter((c) => !isWild(c, level))
  const w = wilds.length
  const candidates = []
  const rankChoices = [RANK_2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, RANK_A]
  const build = (assigns) => {
    const cds = rest.slice()
    for (let i = 0; i < w; i++) cds.push({ suit: 'H', rank: assigns[i] })
    candidates.push(cds)
  }
  if (w === 0) {
    candidates.push(rest)
  } else if (w === 1) {
    for (const r of rankChoices) build([r])
  } else {
    for (const r1 of rankChoices) for (const r2 of rankChoices) build([r1, r2])
  }
  let best = null
  for (const cds of candidates) {
    const r = detectPlain(cds, level)
    if (!r) continue
    if (!best) {
      best = r
      continue
    }
    const bc = bombClass(best.type, best.size)
    const cc = bombClass(r.type, r.size)
    if (cc > bc || (cc === bc && r.eff > best.eff)) best = r
  }
  return best
}

// ----------------------------------------------------------------------------
// 大小比较
// ----------------------------------------------------------------------------
// 炸弹层级：四大天王4 > 6张以上炸弹3 > 同花顺2 > 5张炸弹1 > 4张炸弹0；普通为-1
function bombClass(type, size) {
  if (type === 'four_joker') return 4
  if (type === 'bomb') return size >= 6 ? 3 : size === 5 ? 1 : 0
  if (type === 'straight_flush') return 2
  return -1
}

function canBeat(prev, cur) {
  const pc = bombClass(prev.type, prev.size)
  const cc = bombClass(cur.type, cur.size)
  if (cc >= 0 && pc < 0) return true // 炸弹压普通
  if (pc >= 0 && cc >= 0) {
    if (cc !== pc) return cc > pc
    if (cur.type === 'four_joker') return false
    return cur.eff > prev.eff
  }
  if (pc >= 0) return false // 普通不能压炸弹
  if (cur.type !== prev.type || cur.size !== prev.size) return false
  return cur.eff > prev.eff
}

// ----------------------------------------------------------------------------
// 候选生成
// ----------------------------------------------------------------------------
// 生成手牌的所有合法出牌候选（配牌自动具体化）。
// 返回数组，每项 { cards: [..具体化后的牌..], type, eff, size }
function genCandidates(hand, level, prev) {
  const wilds = hand.filter((c) => isWild(c, level))
  const rest = hand.filter((c) => !isWild(c, level))
  const w = wilds.length
  const groups = {}
  for (const c of rest) {
    if (!groups[c.rank]) groups[c.rank] = []
    groups[c.rank].push(c)
  }
  const result = []
  const seen = new Set()

  // 取某 rank 的 need 张牌（真实牌优先，不足用配牌补，配牌具体化为该 rank）
  // 返回 { cards, usedWild } 或 null；若 forceSuit 提供则优先取该花色的牌
  const take = (rank, need, used, forceSuit) => {
    let pool = groups[rank] || []
    if (forceSuit) pool = pool.filter((c) => c.suit === forceSuit)
    const got = pool.slice(0, need)
    let left = need - got.length
    let u = used
    const list = got.slice()
    while (left > 0 && u < w) {
      // wild 标记：这是配牌具体化成的牌，play 校验时按配牌匹配
      list.push({ suit: forceSuit || 'H', rank, wild: true })
      u++
      left--
    }
    if (left > 0) return null
    return { cards: list, usedWild: u }
  }

  const add = (cds, type, eff, size) => {
    const key = cardsText(cds)
    if (seen.has(key)) return
    seen.add(key)
    result.push({ cards: cds, type, eff, size })
  }

  const rankList = [RANK_2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, RANK_A]

  // --- 单张 ---
  for (const c of rest) add([c], 'single', effRank(c.rank, level), 1)
  if (w > 0) add([{ suit: 'H', rank: level }], 'single', 15, 1) // 配牌作级牌单张

  // --- 王对子 / 四大天王 ---
  const sj = rest.filter((c) => c.rank === SMALL_JOKER)
  const bj = rest.filter((c) => c.rank === BIG_JOKER)
  if (sj.length >= 2) add(sj.slice(0, 2), 'pair', 16, 2)
  if (bj.length >= 2) add(bj.slice(0, 2), 'pair', 17, 2)
  if (sj.length >= 2 && bj.length >= 2) add(sj.slice(0, 2).concat(bj.slice(0, 2)), 'four_joker', 99, 4)

  // --- 对子 / 三张 / 炸弹（同 rank 组）---
  for (const r of rankList) {
    const have = (groups[r] || []).length
    for (let k = 2; k <= have + w; k++) {
      const t = take(r, k, 0)
      if (!t) continue
      if (k === 2) add(t.cards, 'pair', effRank(r, level), 2)
      else if (k === 3) add(t.cards, 'triple', effRank(r, level), 3)
      else if (k >= 4 && k <= 10) add(t.cards, 'bomb', effRank(r, level), k)
    }
  }

  // --- 三带二（固定 3+2，两部分不同点数）---
  for (const tr of rankList) {
    const t1 = take(tr, 3, 0)
    if (!t1) continue
    for (const pr of rankList) {
      if (pr === tr) continue
      const t2 = take(pr, 2, t1.usedWild)
      if (!t2) continue
      add(t1.cards.concat(t2.cards), 'triple_pair', effRank(tr, level), 5)
    }
  }

  // --- 顺子 / 同花顺（窗口 [s..s+4]，s=1..9 即 2..A）---
  // 打 2 时窗口不能含 2（rseq=1）
  for (let s = 1; s <= 9; s++) {
    if (level === RANK_2 && s === 1) continue
    const ranks = [s, s + 1, s + 2, s + 3, s + 4].map(rseqBack)
    // 普通顺子：每点取一张（优先不取配牌的花色，任意即可）
    let ok = true
    const cds = []
    let used = 0
    for (const r of ranks) {
      const t = take(r, 1, used)
      if (!t) { ok = false; break }
      cds.push(t.cards[0])
      used = t.usedWild
    }
    if (ok) add(cds, 'straight', effRank(ranks[4], level), 5)
    // 同花顺：每个花色尝试
    for (const suit of SUITS) {
      let ok2 = true
      const cds2 = []
      let used2 = 0
      for (const r of ranks) {
        const t = take(r, 1, used2, suit)
        if (!t) { ok2 = false; break }
        cds2.push(t.cards[0])
        used2 = t.usedWild
      }
      if (ok2) add(cds2, 'straight_flush', effRank(ranks[4], level), 5)
    }
  }

  // --- 三连对（窗口 [s..s+2]）---
  for (let s = 1; s <= 11; s++) {
    if (level === RANK_2 && s === 1) continue
    const ranks = [s, s + 1, s + 2].map(rseqBack)
    let ok = true
    const cds = []
    let used = 0
    for (const r of ranks) {
      const t = take(r, 2, used)
      if (!t) { ok = false; break }
      cds.push(...t.cards)
      used = t.usedWild
    }
    if (ok) add(cds, 'straight_pair', effRank(ranks[2], level), 6)
  }

  // --- 钢板（窗口 [s..s+1]，各取 3 张）---
  for (let s = 1; s <= 12; s++) {
    if (level === RANK_2 && s === 1) continue
    const ranks = [s, s + 1].map(rseqBack)
    let ok = true
    const cds = []
    let used = 0
    for (const r of ranks) {
      const t = take(r, 3, used)
      if (!t) { ok = false; break }
      cds.push(...t.cards)
      used = t.usedWild
    }
    if (ok) add(cds, 'plane', effRank(ranks[1], level), 6)
  }

  // --- 压牌过滤 ---
  if (prev) {
    return result.filter((c) => canBeat(prev, c))
  }
  return result
}

// 生成单类型更大的候选（压牌优化入口，与 genCandidates+filter 等价但更聚焦）
// 目前直接复用 genCandidates + canBeat 过滤（候选量级可接受）

// ----------------------------------------------------------------------------
// 牌局状态机
// ----------------------------------------------------------------------------
// 座位 0..3，队伍：0 和 2 一队（team 0），1 和 3 一队（team 1）
// 出牌顺序：0 → 1 → 2 → 3 → 0（面板上显示为逆时针）
const TEAM = (i) => (i % 2 === 0 ? 0 : 1)
const NEXT = (i) => (i + 1) % 4

function shuffle(arr, seed) {
  const a = arr.slice()
  let s = seed || 42
  for (let i = a.length - 1; i > 0; i--) {
    s = (s * 1103515245 + 12345) % 2147483647
    const j = s % (i + 1)
    const t = a[i]
    a[i] = a[j]
    a[j] = t
  }
  return a
}

function newDeck() {
  // 两副牌共 108 张：52×2 普通牌 + 4 王
  const deck = []
  for (let copy = 0; copy < 2; copy++) {
    for (const suit of SUITS) for (const rank of [3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, RANK_A, RANK_2]) deck.push({ suit, rank })
  }
  deck.push({ suit: 'J', rank: SMALL_JOKER })
  deck.push({ suit: 'J', rank: SMALL_JOKER })
  deck.push({ suit: 'J', rank: BIG_JOKER })
  deck.push({ suit: 'J', rank: BIG_JOKER })
  return deck
}

class Game {
  constructor(opts) {
    this.opts = Object.assign(
      { withGong: true, jieFeng: 'teammate', gongReturn: 'any', seat: 0 },
      opts || {},
    )
    this.level = RANK_2 // 当前本局打的级牌（= 进攻方 activeTeam 的级牌）
    this.teamLevel = { 0: RANK_2, 1: RANK_2 } // 双方各自级牌（0=我方, 1=对方）
    this.activeTeam = 0 // 当前进攻方（本局按其级牌打）
    this.atA = null // 当前正在打 A 且已头游待过 A 的队伍
    this.round = 0
    this.winner = null // 整盘胜者队伍
    this.log = []
    this.phase = 'idle'
    this.started = false
    this._seed = (opts && opts.seed) || 42
  }

  logLine(msg) {
    this.log.push(msg)
  }

  // 开始新的一局（发牌 + 贡牌转移 + 首出者）
  newRound() {
    this.round++
    // 本局级牌 = 当前进攻方的级牌
    this.level = this.teamLevel[this.activeTeam]
    // 每局换一个洗牌种子（同一盘内多局不能重复同一副牌）
    const deck = shuffle(newDeck(), this._seed * 31 + this.round * 7919)
    this.hands = []
    for (let i = 0; i < 4; i++) this.hands.push(deck.slice(i * 27, (i + 1) * 27))
    this.outOrder = [] // 出完牌的顺序
    this.outCount = { 0: 0, 1: 0, 2: 0, 3: 0 }
    this.played = {} // 已出牌统计 rank -> count
    this.table = {} // 当前一轮各家出的牌
    this.passCount = 0
    this.finished = false
    this.lastMover = null // 最后一个实际出牌的人
    this.lastPlay = null // 最后一个实际出的牌型
    // 非首局：进贡 / 还贡（发牌后进行）
    if (this.round > 1 && this.opts.withGong && this.winner === null && this.lastFullOrder) {
      this._doGongAfterDeal()
    }
    this.curPlayer = this._decideFirstPlayer()
    this.phase = 'playing'
    this.leadPlayer = this.curPlayer
    this.logLine(`—— 第 ${this.round} 局 · 打 ${RANK_TEXT[this.level]} ——`)
    this.logLine(`${this._name(this.curPlayer)} 先出`)
  }

  _decideFirstPlayer() {
    // 首局：持红桃2（逢人配）者先出；多人持有则取红桃2张数最多者，平分随机
    if (this.round === 1) {
      let best = []
      let bestN = -1
      for (let i = 0; i < 4; i++) {
        const n = this.hands[i].filter((c) => isWild(c, this.level)).length
        if (n > bestN) { bestN = n; best = [i] } else if (n === bestN) best.push(i)
      }
      return best[Math.floor(Math.random() * best.length)]
    }
    // 非首局：进贡还贡后由头游先出
    return this.lastFullOrder ? this.lastFullOrder[0] : 0
  }

  _name(i) {
    return ['东', '南', '西', '北'][i] // 座位代号
  }

  _sortHand(hand) {
    return hand.slice().sort((a, b) => effRank(b.rank, this.level) - effRank(a.rank, this.level) || b.suit.localeCompare(a.suit))
  }

  // 玩家出牌；cards 为空数组表示过牌
  play(playerIdx, cards) {
    if (this.phase !== 'playing' || this.finished) return { ok: false, reason: '牌局未在进行' }
    if (playerIdx !== this.curPlayer) return { ok: false, reason: `还没轮到 ${this._name(playerIdx)}` }

    if (cards.length === 0) {
      if (this.lastPlay === null) return { ok: false, reason: '首出不能过牌' }
      this.passCount++
      this.table[playerIdx] = []
      this.logLine(`${this._name(playerIdx)} 过牌`)
      this._advance()
      return { ok: true, moved: false }
    }

    const d = detect(cards, this.level)
    if (!d) return { ok: false, reason: '非法牌型' }
    if (this.lastPlay && !canBeat(this.lastPlay, d)) return { ok: false, reason: '压不过上家' }
    // 校验牌在手牌中（配牌可被具体化：wild 标记的牌匹配手中的逢人配）
    const pool = this.hands[playerIdx].slice()
    for (const c of cards) {
      let idx = pool.findIndex((p) => p.rank === c.rank && p.suit === c.suit)
      if (idx < 0 && c.wild) {
        idx = pool.findIndex((p) => isWild(p, this.level))
      }
      if (idx < 0) return { ok: false, reason: `没有这张牌：${cardText(c)}` }
      pool.splice(idx, 1)
    }
    // 执行
    const consume = (c) => {
      this.played[c.rank] = (this.played[c.rank] || 0) + 1
      let idx = this.hands[playerIdx].findIndex((p) => p.rank === c.rank && p.suit === c.suit)
      if (idx < 0 && c.wild) {
        // 候选中的配牌被具体化为目标 rank/花色：匹配手牌里的逢人配（红桃级牌）
        idx = this.hands[playerIdx].findIndex((p) => isWild(p, this.level))
      }
      if (idx >= 0) this.hands[playerIdx].splice(idx, 1)
    }
    for (const c of cards) consume(c)
    this.table[playerIdx] = cards
    this.lastPlay = d
    this.lastMover = playerIdx
    this.passCount = 0
    this.outCount[playerIdx] += cards.length
    this.logLine(`${this._name(playerIdx)} 出 ${cardsText(cards)}`)
    if (this.hands[playerIdx].length === 0) {
      this.outOrder.push(playerIdx)
      this.logLine(`★ ${this._name(playerIdx)} 出完（第 ${this.outOrder.length} 个）`)
    }
    this._advance()
    return { ok: true, moved: true }
  }

  _advance() {
    if (this.finished) return
    // 3 人出完即本局结束（第 4 人自动为末游；头游方获胜）
    if (this.outOrder.length >= 3) {
      this.finished = true
      this.phase = 'roundEnd'
      this._settle()
      return
    }
    // 一圈结束：除出牌者外，所有仍在场玩家都过牌
    const active = [0, 1, 2, 3].filter((i) => this.hands[i].length > 0).length
    if (this.passCount >= active - 1) {
      // 出牌权回到 lastMover；若其已出完 → 接风
      if (this.hands[this.lastMover].length === 0) {
        // 接风：队友（可配置）
        let receiver
        if (this.opts.jieFeng === 'teammate') {
          receiver = [0, 1, 2, 3].find((i) => TEAM(i) === TEAM(this.lastMover) && i !== this.lastMover && this.hands[i].length > 0)
        } else {
          receiver = NEXT(this.lastMover)
        }
        if (receiver === undefined) receiver = [0, 1, 2, 3].find((i) => this.hands[i].length > 0)
        this.curPlayer = receiver
        this.logLine(`${this._name(this.lastMover)} 接风 → ${this._name(receiver)} 出牌`)
      } else {
        this.curPlayer = this.lastMover
        this.logLine(`一圈无人压，${this._name(this.lastMover)} 继续出牌`)
      }
      this.lastPlay = null
      this.passCount = 0
      this.table = {}
      return
    }
    // 轮到下一个仍在场的玩家
    let next = NEXT(this.curPlayer)
    let guard = 0
    while (this.hands[next].length === 0 && guard < 4) {
      next = NEXT(next)
      guard++
    }
    this.curPlayer = next
  }

  // 结算一局：确定名次 + 升级 + 过A判定 + 记录名次（贡牌在下一局发牌后执行）
  _settle() {
    // 名次：outOrder 是出完顺序，剩下的 1 人自动为末游
    const order = this.outOrder.slice()
    const rest = [0, 1, 2, 3].filter((i) => !order.includes(i))
    const fullOrder = order.concat(rest) // [头游, 二游, 三游, 末游]
    const head = fullOrder[0]
    const second = fullOrder[1]
    const third = fullOrder[2]
    const last = fullOrder[3]
    const headTeam = TEAM(head) // 头游方必胜
    const secondIsMate = TEAM(second) === headTeam
    this.lastFullOrder = fullOrder // 供下一局贡牌使用
    this.logLine(`本局名次：${fullOrder.map((i) => this._name(i)).join(' > ')}`)

    // 升级：头游+二游(队友)升3级；头游+三游升2级；头游+末游升1级
    const up = secondIsMate ? 3 : TEAM(third) === headTeam ? 2 : 1
    const lvBeforeTeam = this.teamLevel[headTeam]
    this._levelUp(headTeam, up)
    const lvAfterTeam = this.teamLevel[headTeam]
    if (lvBeforeTeam === RANK_A) {
      // 本局头游方正在打 A（按自己的级牌判定）
      const mate = [0, 1, 2, 3].find((i) => TEAM(i) === headTeam && i !== head)
      if (mate !== last) {
        this.winner = headTeam
        this.phase = 'gameOver'
        this.logLine(`🏆 ${headTeam === 0 ? '我方' : '对方'} 过 A 获胜，整盘结束！`)
        return
      }
      this.logLine('打 A 未过（队友末游），重打 A')
    } else if (lvAfterTeam === RANK_A) {
      this.atA = headTeam
      this.logLine(`${headTeam === 0 ? '我方' : '对方'} 升至 A，下一局起打 A`)
    }
    // atA 始终等于当前处于 A 的队伍（双方可能都在 A）
    this.phase = 'idle' // 等待新局
  }

  _levelUp(team, up) {
    // 按牌点序列步进：2→3→4→…→K→A（rseq：2=1 … A=13），封顶 A
    const cur = this.teamLevel[team] != null ? this.teamLevel[team] : this.level
    const seq = Math.min(13, rseq(cur) + up)
    const next = rseqBack(seq)
    this.teamLevel[team] = next
    this.activeTeam = team // 升级方成为进攻方，下一局按它的级牌打
    this.level = next
    this.logLine(`${team === 0 ? '我方' : '对方'} 升 ${up} 级 → 打 ${RANK_TEXT[next]}`)
  }

  // 进贡 / 还贡（在下一局发牌后执行）
  _doGongAfterDeal() {
    const fullOrder = this.lastFullOrder
    const head = fullOrder[0]
    const losers = fullOrder.slice(3) // 末游；双下时两人
    const gongInfo = { head, entries: [], returns: [] }
    for (const loser of losers) {
      const hand = this.hands[loser]
      // 抗贡：手中有两张大王
      const bigJokers = hand.filter((c) => c.rank === BIG_JOKER).length
      if (bigJokers >= 2) {
        this.logLine(`${this._name(loser)} 持双大王，抗贡`)
        continue
      }
      // 进贡最大牌（不含逢人配）
      const candidates = hand.filter((c) => !isWild(c, this.level))
      if (!candidates.length) continue
      let maxCard = candidates[0]
      for (const c of candidates) if (effRank(c.rank, this.level) > effRank(maxCard.rank, this.level)) maxCard = c
      const idx = hand.indexOf(maxCard)
      hand.splice(idx, 1)
      this.hands[head].push(maxCard)
      gongInfo.entries.push({ from: loser, card: maxCard })
      this.logLine(`${this._name(loser)} 进贡 ${cardText(maxCard)} 给 ${this._name(head)}`)
    }
    // 头游还贡（每个进贡者还一张；可配置 ≤10 限制）
    for (const e of gongInfo.entries) {
      const hand = this.hands[head]
      let pool = hand.filter((c) => !isWild(c, this.level))
      if (this.opts.gongReturn === 'le10') pool = pool.filter((c) => effRank(c.rank, this.level) <= 10)
      if (!pool.length) pool = hand.filter((c) => !isWild(c, this.level))
      if (!pool.length) continue
      let minCard = pool[0]
      for (const c of pool) if (effRank(c.rank, this.level) < effRank(minCard.rank, this.level)) minCard = c
      const idx = hand.indexOf(minCard)
      hand.splice(idx, 1)
      this.hands[e.from].push(minCard)
      gongInfo.returns.push({ to: e.from, card: minCard })
      this.logLine(`${this._name(head)} 还贡 ${cardText(minCard)} 给 ${this._name(e.from)}`)
    }
    // 还贡后，头游先出
    this.gongInfo = gongInfo
    this.logLine(`${this._name(head)} 先出`)
  }

  // 供 UI 展示的牌局摘要
  snapshot() {
    return {
      level: this.level,
      atA: this.atA,
      teamLevel: { 0: this.teamLevel[0], 1: this.teamLevel[1] },
      activeTeam: this.activeTeam,
      round: this.round,
      hands: this.hands.map((h) => this._sortHand(h)),
      outCount: this.outCount,
      table: this.table,
      curPlayer: this.curPlayer,
      lastPlay: this.lastPlay,
      outOrder: this.outOrder,
      winner: this.winner,
      phase: this.phase,
      gongInfo: this.gongInfo,
    }
  }
}

// ----------------------------------------------------------------------------
// 规则基线 agent
// ----------------------------------------------------------------------------
// 评分启发式（1.0）：
// - 自由出牌：先出小牌、散牌；尽量不拆已成组合；炸弹保留（除非能借此走完）
// - 压牌：不压队友（除非出完即胜）；压对手用最小的牌；炸弹仅在关键时刻使用
// - 记牌：统计已出的牌，判断自己手里的牌是否当前该点数的最大张
function ruleAgentDecide(game, playerIdx) {
  const level = game.level
  const hand = game.hands[playerIdx]
  const prev = game.lastPlay
  const cands = genCandidates(hand, level, prev)
  const handSize = hand.length
  const mateIdx = [0, 1, 2, 3].find((i) => TEAM(i) === TEAM(playerIdx) && i !== playerIdx)
  const prevIsMate = game.lastMover === mateIdx

  // 队友出的牌：不压（除非自己出完即赢或队友已无法接风）
  if (prev && prevIsMate) {
    const winNow = cands.find((c) => c.cards.length === handSize)
    if (winNow) return { cards: winNow.cards, reason: `队友出的牌不压，但 ${cardsText(winNow.cards)} 可一次走完` }
    return { cards: [], reason: '队友出牌，不压' }
  }

  const remaining = { 2: 8, 3: 8, 4: 8, 5: 8, 6: 8, 7: 8, 8: 8, 9: 8, 10: 8, 11: 8, 12: 8, 13: 8, 14: 8, 15: 8, 16: 2, 17: 2 }
  for (const r in game.played) remaining[r] -= game.played[r]
  const isTopSingle = (eff) => {
    // 单张牌力最大（不含王时）: eff 15 级牌最高
    if (eff === 17) return true
    if (eff === 16) return remaining[17] === 0
    if (eff === 15) return remaining[16] === 0 && remaining[17] === 0
    // 某点数：比它大的点数都已出完
    for (let e = eff + 1; e <= 15; e++) {
      const r = e === 15 ? level : e
      if (remaining[r] > 0) return false
    }
    return remaining[16] === 0 && remaining[17] === 0
  }

  // 评分
  const scored = cands.map((c) => {
    let score = 0
    const isBomb = bombClass(c.type, c.size) >= 0
    const leadAll = c.cards.length === handSize // 出完即走
    if (leadAll) score += 5000
    if (isBomb) {
      score -= 60 + c.size * 5 // 炸弹保留，越大越不舍得
      if (game.outCount[playerIdx] === 0 && c.size >= 6) score -= 20
      // 关键时刻：对手只剩 1-2 张且手牌 ≤ 8
      const opps = [0, 1, 2, 3].filter((i) => TEAM(i) !== TEAM(playerIdx))
      const minOppLeft = Math.min(...opps.map((i) => game.hands[i].length))
      if (minOppLeft <= 2 && handSize <= 8) score += 300
    }
    // 自由出牌倾向
    if (!prev) {
      if (c.type === 'single') score += 100 - c.eff * 2 // 小单优先
      else if (c.type === 'pair') score += 80 - c.eff
      else if (c.type === 'triple') score += 70 - c.eff
      else if (c.type === 'triple_pair') score += 60 - c.eff
      else if (c.type === 'straight') score += 50 - c.eff
      else if (c.type === 'straight_pair') score += 45 - c.eff
      else if (c.type === 'plane') score += 40 - c.eff
      // 单张是大牌（没人要得起）也保留一下
      if (c.type === 'single' && isTopSingle(c.eff) && handSize > 3) score -= 30
    } else {
      // 压牌：用最小代价压
      score += 200
      score -= c.eff * 3
      if (isBomb) score -= 400 // 压牌时更不舍得炸
      // 出完即走
      if (c.cards.length === handSize) score += 5000
    }
    return { cand: c, score }
  })

  scored.sort((a, b) => b.score - a.score)
  if (!scored.length) {
    // 没有候选：必须过
    return { cards: [], reason: prev ? '压不过，过牌' : '无牌可出' }
  }
  const best = scored[0]
  let reason
  if (best.cand.type === 'single') reason = `出单张 ${cardText(best.cand.cards[0])}`
  else if (best.cand.type === 'bomb') reason = `出炸弹 ${cardsText(best.cand.cards)}`
  else if (best.cand.type === 'straight_flush') reason = `出同花顺 ${cardsText(best.cand.cards)}`
  else if (best.cand.type === 'four_joker') reason = `出四大天王`
  else reason = `出${best.cand.cards.length}张（${cardsText(best.cand.cards)}）`
  return { cards: best.cand.cards, reason }
}

// ----------------------------------------------------------------------------
// 自测（面板内运行，验证引擎正确性）
// ----------------------------------------------------------------------------
function runSelfTests() {
  const results = []
  const check = (name, cond, detail) => results.push({ name, pass: !!cond, detail: cond ? '' : detail || '' })

  // --- 牌型识别 ---
  const L5 = 5
  check('单张', detect([{ suit: 'S', rank: 7 }], L5) && detect([{ suit: 'S', rank: 7 }], L5).type === 'single')
  check('对子', detect([{ suit: 'S', rank: 7 }, { suit: 'H', rank: 7 }], L5).type === 'pair')
  check('三张', detect([{ suit: 'S', rank: 7 }, { suit: 'H', rank: 7 }, { suit: 'C', rank: 7 }], L5).type === 'triple')
  check('三带二', detect([{ suit: 'S', rank: 7 }, { suit: 'H', rank: 7 }, { suit: 'C', rank: 7 }, { suit: 'S', rank: 10 }, { suit: 'H', rank: 10 }], L5).type === 'triple_pair')
  check('无三带一', !detect([{ suit: 'S', rank: 7 }, { suit: 'H', rank: 7 }, { suit: 'C', rank: 7 }, { suit: 'S', rank: 10 }], L5))
  check('顺子 3-7', detect([{ suit: 'S', rank: 3 }, { suit: 'H', rank: 4 }, { suit: 'C', rank: 5 }, { suit: 'S', rank: 6 }, { suit: 'H', rank: 7 }], L5).type === 'straight')
  check('A2345 合法（打5时）', detect([{ suit: 'S', rank: 14 }, { suit: 'H', rank: 15 }, { suit: 'C', rank: 3 }, { suit: 'S', rank: 4 }, { suit: 'H', rank: 5 }], L5).type === 'straight')
  check('打2时 2 不入顺', !detect([{ suit: 'S', rank: 14 }, { suit: 'H', rank: 15 }, { suit: 'C', rank: 3 }, { suit: 'S', rank: 4 }, { suit: 'H', rank: 5 }], RANK_2))
  check('同花顺', detect([{ suit: 'S', rank: 3 }, { suit: 'S', rank: 4 }, { suit: 'S', rank: 5 }, { suit: 'S', rank: 6 }, { suit: 'S', rank: 7 }], L5).type === 'straight_flush')
  check('4张炸弹', detect([{ suit: 'S', rank: 7 }, { suit: 'H', rank: 7 }, { suit: 'C', rank: 7 }, { suit: 'D', rank: 7 }], L5).type === 'bomb')
  check('连对', detect([{ suit: 'S', rank: 3 }, { suit: 'H', rank: 3 }, { suit: 'S', rank: 4 }, { suit: 'H', rank: 4 }, { suit: 'S', rank: 5 }, { suit: 'H', rank: 5 }], L5).type === 'straight_pair')
  check('钢板', detect([{ suit: 'S', rank: 3 }, { suit: 'H', rank: 3 }, { suit: 'C', rank: 3 }, { suit: 'S', rank: 4 }, { suit: 'H', rank: 4 }, { suit: 'C', rank: 4 }], L5).type === 'plane')
  check('四大天王', detect([{ suit: 'J', rank: 16 }, { suit: 'J', rank: 16 }, { suit: 'J', rank: 17 }, { suit: 'J', rank: 17 }], L5).type === 'four_joker')
  check('配牌补对子', detect([{ suit: 'H', rank: 5 }, { suit: 'S', rank: 9 }], L5).type === 'pair')
  check('配牌补顺子', detect([{ suit: 'H', rank: 5 }, { suit: 'S', rank: 3 }, { suit: 'H', rank: 4 }, { suit: 'S', rank: 6 }, { suit: 'H', rank: 7 }], L5).type === 'straight')
  check('配牌单张按级牌算', detect([{ suit: 'H', rank: 5 }], L5).eff === 15)
  check('配牌压单张A', canBeat({ type: 'single', eff: 14, size: 1 }, detect([{ suit: 'H', rank: 5 }], L5)))

  // --- 大小比较 ---
  const T = (type, eff, size) => ({ type, eff, size })
  check('单压单', canBeat(T('single', 8, 1), T('single', 10, 1)))
  check('单不压对', !canBeat(T('single', 10, 1), T('pair', 8, 2)))
  check('级牌大于A', canBeat(T('single', 14, 1), T('single', 15, 1)))
  check('4炸压普通', canBeat(T('straight', 10, 5), T('bomb', 7, 4)))
  check('同花顺压5炸', canBeat(T('bomb', 10, 5), T('straight_flush', 10, 5)))
  check('6炸压同花顺', canBeat(T('straight_flush', 14, 5), T('bomb', 3, 6)))
  check('天王压一切', canBeat(T('bomb', 3, 8), T('four_joker', 99, 4)))
  check('5炸压4炸', canBeat(T('bomb', 13, 4), T('bomb', 3, 5)))
  check('同花顺比点数', canBeat(T('straight_flush', 9, 5), T('straight_flush', 10, 5)))
  check('4炸压不过同花顺', !canBeat(T('straight_flush', 3, 5), T('bomb', 14, 4)))

  // --- 候选生成 ---
  const hand1 = [
    { suit: 'S', rank: 3 }, { suit: 'H', rank: 3 }, { suit: 'C', rank: 4 }, { suit: 'D', rank: 4 },
    { suit: 'S', rank: 7 }, { suit: 'H', rank: 9 }, { suit: 'C', rank: 9 }, { suit: 'D', rank: 9 }, { suit: 'S', rank: 13 },
  ]
  const cands1 = genCandidates(hand1, L5, null)
  check('候选含单张', cands1.some((c) => c.type === 'single'))
  check('候选含对子', cands1.some((c) => c.type === 'pair'))
  check('候选含三带二', cands1.some((c) => c.type === 'triple_pair'))
  const candsBeat = genCandidates(hand1, L5, { type: 'single', eff: 8, size: 1 })
  check('压单张候选', candsBeat.some((c) => c.type === 'single' && c.eff > 8))
  check('压牌不含更小单', !candsBeat.some((c) => c.type === 'single' && c.eff <= 8))

  // --- 发牌数量 ---
  check('牌堆 108 张（两副牌）', newDeck().length === 108, `实际 ${newDeck().length} 张`)
  const gDeal = new Game({ seed: 7 })
  gDeal.newRound()
  check('每人发 27 张', gDeal.hands.every((h) => h.length === 27), `实际 ${gDeal.hands.map((h) => h.length).join('/')} 张`)
  check('红桃2配牌在牌堆中', newDeck().filter((c) => isWild(c, RANK_2)).length === 2, `实际 ${newDeck().filter((c) => isWild(c, RANK_2)).length} 张`)

  // --- 整局模拟（规则 agent 自打，每 seed 打到一盘结束或 10 局）---
  let simFail = null
  for (let seed = 1; seed <= 8; seed++) {
    const g = new Game({ seed, seat: 0 })
    g.newRound()
    let guard = 0
    let rounds = 0
    while (!g.winner && rounds < 10 && guard < 20000) {
      if (g.phase === 'playing') {
        const move = ruleAgentDecide(g, g.curPlayer)
        const res = g.play(g.curPlayer, move.cards)
        if (!res.ok) { simFail = `seed ${seed} 第 ${guard} 步：${res.reason}（agent 想出 ${cardsText(move.cards)}）`; break }
      } else if (g.phase === 'idle') {
        g.newRound()
        rounds++
      }
      guard++
    }
    if (simFail) break
    // 判定：流程必须零错误；升级系统必须工作（不能 10 局还在打 2）；
    // 升到 A 后反复重打 A 属正常（规则 agent 强度有限，非引擎 bug）
    if (!g.winner && rounds >= 10 && g.level === RANK_2) {
      simFail = `seed ${seed} 打 10 局仍在打 2（升级系统异常）`
      break
    }
  }
  check('8 盘模拟无错误', !simFail, simFail)

  // --- 升级计分 ---
  const g2 = new Game({ seed: 1 })
  g2.round = 2
  g2.hands = [[], [], [], []]
  g2._levelUp(0, 3)
  check('升3级到5', g2.teamLevel[0] === 5, `lv=${g2.teamLevel[0]}`)
  g2._levelUp(0, 2)
  check('再升2级到7', g2.teamLevel[0] === 7, `lv=${g2.teamLevel[0]}`)
  // 对方级牌独立：升我方不影响对方
  check('对方级牌独立', g2.teamLevel[1] === RANK_2, `lv1=${g2.teamLevel[1]}`)
  g2.teamLevel[0] = RANK_A
  g2.atA = 0
  g2._levelUp(0, 1)
  check('到A封顶', g2.teamLevel[0] === RANK_A, `lv=${g2.teamLevel[0]}`)
  // 新局级牌 = 进攻方级牌
  g2.activeTeam = 1
  g2.teamLevel[1] = 9
  g2.newRound()
  check('新局按进攻方级牌', g2.level === 9, `level=${g2.level}`)

  const pass = results.filter((r) => r.pass).length
  return { results, pass, total: results.length }
}

// ----------------------------------------------------------------------------
// 面板 UI
// ----------------------------------------------------------------------------
const { React } = globalThis.__THETHING_PANEL__
const h = React.createElement

const SUIT_CHAR = { S: '♠', H: '♥', C: '♣', D: '♦' }

// ----------------------------------------------------------------------------
// 图标库（内联 SVG，来自 Tabler Icons，MIT 许可，24×24 viewBox）
// ----------------------------------------------------------------------------
// 彩色卡通图标（Fluent Emoji Flat / Microsoft / MIT）——内联 SVG 内容，32×32
const ICONS = {
  joker: '<g fill="none"><path fill="#b4acbc" d="M6.5 1A2.5 2.5 0 0 0 4 3.5v25A2.5 2.5 0 0 0 6.5 31h19a2.5 2.5 0 0 0 2.5-2.5v-25A2.5 2.5 0 0 0 25.5 1z"/><path fill="#f3eef8" d="M5 3.5A1.5 1.5 0 0 1 6.5 2h19A1.5 1.5 0 0 1 27 3.5v25a1.5 1.5 0 0 1-1.5 1.5h-19A1.5 1.5 0 0 1 5 28.5z"/><path fill="#8d65c5" d="m21.77 21.092l-2.812-2.512v-.028l-.021.01L17.192 17l-1.216 2.672l-1.269-2.653l-1.713 1.58h-.021v.029l-2.76 2.549c-.211.197-.275.48-.148.734c.116.244.391.389.698.389H13l.004 2.038c.01.272.21.508.496.611a.78.78 0 0 0 .805-.15L16 23.5l1.678 1.299c.222.188.54.254.825.141c.275-.104.497-.358.497-.63V22.3h2.263c.306-.01.57-.239.687-.493c.106-.235.042-.517-.18-.715"/><path fill="#fbb8ab" d="M16 22c-2.204 0-4-1.642-4-3.657V15h8v3.343C20 20.368 18.215 22 16 22"/><path fill="#26eafc" fill-rule="evenodd" d="M22.549 13.902a1.25 1.25 0 1 0 .963-.88L22.35 11.97c-2.279-2.048-6.224-.634-6.224 2.226V16L20 17v-2.73c0-.792 1.007-1.267 1.75-.835z" clip-rule="evenodd"/><path fill="#f8312f" fill-rule="evenodd" d="M9.468 13.967A1.253 1.253 0 0 1 8.25 15.5a1.25 1.25 0 1 1 .328-2.456l1.188-1.075C12.048 9.92 16 11.335 16 14.195V16l-4 1v-2.73c0-.792-.877-1.267-1.622-.835z" clip-rule="evenodd"/><path fill="#fcd53f" fill-rule="evenodd" d="M16.736 9.74a1.25 1.25 0 1 0-1.471 0L13.743 16h4.514z" clip-rule="evenodd"/><path fill="#8d65c5" d="M20 16.44c-.656-.846-2.193-1.44-3.99-1.44c-1.817 0-3.365.613-4.01 1.477V18c.645-.864 2.194-1.56 4.01-1.56c1.796 0 3.334.678 3.99 1.523z"/><path fill="#bb1d80" d="M16 21.25c.827 0 1.5-.56 1.5-1.25h-3c0 .69.673 1.25 1.5 1.25"/></g>',
  sunglasses: '<g fill="none"><path fill="#ffb02e" d="M15.999 29.998c9.334 0 13.999-6.268 13.999-14c0-7.73-4.665-13.998-14-13.998C6.665 2 2 8.268 2 15.999s4.664 13.999 13.999 13.999"/><path fill="#402a32" d="M11.84 18.457a1 1 0 0 0-1.688 1.073l.001.002l.002.003l.004.006l.009.013a2 2 0 0 0 .097.137c.06.08.147.185.26.306c.226.241.563.546 1.03.845C12.5 21.446 13.937 22 16 22s3.5-.554 4.445-1.158a5.4 5.4 0 0 0 1.03-.845a4 4 0 0 0 .357-.443l.01-.013l.003-.006l.001-.002l.001-.001v-.002a1 1 0 0 0-1.686-1.073l-.018.024a2 2 0 0 1-.126.147a3.4 3.4 0 0 1-.65.53c-.62.396-1.682.842-3.367.842s-2.748-.446-3.367-.842a3.4 3.4 0 0 1-.65-.53a2 2 0 0 1-.144-.171"/><path fill="#321b41" d="M11 5H5a4 4 0 0 0-4 4v.674a7 7 0 0 0 3.87 6.26l.935.469a5.8 5.8 0 0 0 4.52.267C13.111 15.675 15 13.025 15 10.067V9a4 4 0 0 0-4-4m9.5 0h7A3.5 3.5 0 0 1 31 8.5v1.174a7 7 0 0 1-3.87 6.26l-.935.469a5.8 5.8 0 0 1-4.52.267C18.889 15.675 17 13.025 17 10.067V8.5A3.5 3.5 0 0 1 20.5 5"/><path fill="#8d65c5" d="M14 6.354A4 4 0 0 0 11 5H5a4 4 0 0 0-4 4v.674a7 7 0 0 0 3.87 6.26l.935.469a5.8 5.8 0 0 0 4.52.267C13.111 15.675 15 13.025 15 10.067V10a1 1 0 1 1 2 0v.067c0 2.958 1.889 5.608 4.675 6.603a5.8 5.8 0 0 0 4.52-.267l.936-.468A7 7 0 0 0 31 9.674V8.5A3.5 3.5 0 0 0 27.5 5h-7c-1.124 0-2.124.53-2.765 1.354V6.35l-.05.05c-.191.197-.582.596-.945.599h-1.744c-.364-.003-.754-.402-.946-.599L14 6.35zM11 6a3 3 0 0 1 3 3v1.067c0 2.53-1.618 4.806-4.011 5.66a4.8 4.8 0 0 1-3.736-.219l-.936-.468A6 6 0 0 1 2 9.674V9a3 3 0 0 1 3-3zm7 2.5A2.5 2.5 0 0 1 20.5 6h7A2.5 2.5 0 0 1 30 8.5v1.174a6 6 0 0 1-3.317 5.366l-.936.468a4.78 4.78 0 0 1-3.736.22C19.618 14.873 18 12.598 18 10.067z"/><path fill="#fff" d="M12.39 10.268c.585-.586.427-1.694-.354-2.475s-1.89-.94-2.475-.354s-.428 1.694.353 2.475s1.89.94 2.475.354m16.001 0c.585-.586.427-1.694-.354-2.475c-.782-.781-1.89-.94-2.475-.354s-.428 1.694.353 2.475s1.89.94 2.475.354"/></g>',
  fox: '<g fill="none"><path fill="#ff822d" d="M17.558 5.98A12 12 0 0 0 16.86 8h-2.58c-.17-.69-.41-1.386-.715-2.057l-3.534-.92l-3.466.913a10.9 10.9 0 0 0-.985 4.484v7.77c0 .45-.36.81-.81.81H2.63c-.41 0-.71.4-.6.8q.174.616.402 1.209l13.153 4.846l13.144-4.847q.227-.592.401-1.208c.11-.4-.19-.8-.61-.8h-2.14c-.45 0-.81-.36-.81-.81v-7.77a10.9 10.9 0 0 0-.962-4.428l-3.567-.969z"/><path fill="#ff6723" d="M10.19 3.98a8.64 8.64 0 0 1 2.64 4.4a10 10 0 0 0-5.76 4.36V10.4c0-2.47 1.06-4.79 2.87-6.42c.07-.06.18-.06.25 0m13.88 6.44v2.31a10 10 0 0 0-5.77-4.35a8.6 8.6 0 0 1 2.63-4.39c.07-.06.18-.06.25 0a8.57 8.57 0 0 1 2.89 6.43"/><path fill="#ffdea7" d="M28.73 20.99h-6.46c-1.75 0-3.46.55-4.88 1.57l-1.81 1.29l-1.81-1.29a8.37 8.37 0 0 0-4.88-1.57H2.42C4.43 26.26 9.53 30 15.5 30h.14c5.98-.01 11.08-3.75 13.09-9.01"/><path fill="#212121" d="M13.58 5.95c-.65-1.43-1.6-2.75-2.79-3.71c-.2-.16-.45-.24-.7-.24s-.5.08-.7.24c-1.21.97-2.18 2.26-2.83 3.71zm8.18-3.71c-.2-.16-.45-.24-.7-.24s-.5.08-.7.24c-1.2.97-2.16 2.31-2.81 3.76h7.07c-.66-1.47-1.63-2.78-2.86-3.76M11 18a1 1 0 1 1 2 0v1a1 1 0 1 1-2 0zm7 0a1 1 0 1 1 2 0v1a1 1 0 1 1-2 0zm-2.42 7.63c.54.82 1.48 1.37 2.54 1.37c.27 0 .49-.22.49-.5s-.22-.5-.5-.5c-1.12 0-2.04-.91-2.04-2.04a.5.5 0 0 0-.052-.226a1 1 0 0 0 .172-.134l1.13-1.13a.865.865 0 0 0-.61-1.48h-2.26c-.78 0-1.17.93-.62 1.48l1.13 1.13q.076.075.165.13a.5.5 0 0 0-.055.23c0 1.12-.91 2.04-2.04 2.04c-.28 0-.5.22-.5.5s.22.5.5.5c1.06 0 2-.55 2.55-1.37"/></g>',
  panda: '<g fill="none"><path fill="#433b6b" d="M3.463 12.795a4.5 4.5 0 1 1 6.64-6.027A14.4 14.4 0 0 1 16.029 5.5c2.11 0 4.116.453 5.925 1.267a4.5 4.5 0 1 1 6.642 6.027a14.56 14.56 0 0 1 1.933 7.276c0 4.049-1.65 6.7-4.345 8.308c-2.651 1.581-6.261 2.122-10.155 2.122s-7.504-.54-10.155-2.122c-2.695-1.608-4.345-4.26-4.345-8.308c0-2.649.704-5.134 1.935-7.275"/><path fill="#f4f4f4" d="M2.528 20.07c0-7.495 6.048-13.57 13.5-13.57s13.5 6.066 13.5 13.57c0 3.721-1.485 6.034-3.858 7.45c-2.416 1.44-5.806 1.98-9.642 1.98s-7.226-.54-9.643-1.98c-2.372-1.416-3.857-3.729-3.857-7.45"/><path fill="#635994" d="M7.825 18.937a3.64 3.64 0 0 0 5.14 0a3.64 3.64 0 0 0 0-5.14c-1.418-1.418-3.086-.781-4.504.636s-2.054 3.086-.636 4.504m16.405 0c1.418-1.418.782-3.086-.636-4.504c-1.417-1.417-3.085-2.054-4.503-.636a3.64 3.64 0 0 0 0 5.14a3.64 3.64 0 0 0 5.14 0"/><path fill="#1c1c1c" d="M11.028 16a1 1 0 1 1 2 0v1a1 1 0 1 1-2 0zm8 0a1 1 0 1 1 2 0v1a1 1 0 1 1-2 0zm-3.475 4.82l-1.013-.834a.714.714 0 0 1 .453-1.264h2.074a.713.713 0 0 1 .453 1.264l-1.014.833a.75.75 0 0 1-.953 0M16.028 22a.5.5 0 0 1 .487.389c.085.337.196.745.427 1.073c.213.302.527.538 1.086.538c.654 0 1-.534 1-1a.5.5 0 1 1 1 0c0 .868-.655 2-2 2c-.925 0-1.528-.43-1.903-.962a3 3 0 0 1-.097-.148q-.045.076-.097.148c-.375.532-.978.962-1.903.962c-1.346 0-2-1.132-2-2a.5.5 0 1 1 1 0c0 .466.345 1 1 1c.559 0 .873-.236 1.085-.538c.231-.328.343-.736.427-1.073a.5.5 0 0 1 .312-.357a.5.5 0 0 1 .176-.032"/></g>',
  tiger: '<g fill="none"><path fill="#ff822d" d="m27.75 12.372l-1.78-2.08A3.9 3.9 0 0 0 28 6.702c-.09-2.01-1.74-3.64-3.75-3.7a3.9 3.9 0 0 0-3.6 2.14a10 10 0 0 0-2.782-.967l-1.864.86l-1.872-.86a10 10 0 0 0-2.782.967a3.88 3.88 0 0 0-3.6-2.14c-2.01.07-3.66 1.69-3.75 3.7a3.91 3.91 0 0 0 2.02 3.59l-1.77 2.08a9.3 9.3 0 0 0-1.898 3.585l1.757 2.539l-1.924 1.585l2.236 2.912l-2.06 1.126a4.69 4.69 0 0 0 4.329 2.883h18.62c1.95 0 3.621-1.19 4.329-2.883L28.5 22.5l1.281-2.395L29 18.5l.662-2.528a9.4 9.4 0 0 0-1.912-3.6"/><path fill="#ff6723" d="m8.2 7.742l-1.17 1.37a2.4 2.4 0 0 1-1.53-2.23c0-1.31 1.07-2.38 2.38-2.38c.98 0 1.83.6 2.18 1.46c-.69.51-1.32 1.11-1.86 1.78m16.76 1.36l-1.17-1.37a10 10 0 0 0-1.87-1.78c.36-.85 1.21-1.45 2.19-1.45c1.31 0 2.38 1.07 2.38 2.38c0 1.01-.63 1.88-1.53 2.22"/><path fill="#e1d8ec" d="M16 30.002c-3.87 0-7-3.13-7-7v-2h14v2c0 3.87-3.13 7-7 7"/><path fill="#f3eef8" d="M20 18.002h-8c-1.66 0-3 1.34-3 3s1.34 3 3 3h1.5a3 3 0 0 0 2.5-1.34a3 3 0 0 0 2.5 1.34H20c1.66 0 3-1.34 3-3s-1.34-3-3-3"/><path fill="#cdc4d6" d="m8.08 17.572l3.46 2c.24.14.32.44.18.68s-.44.32-.68.18l-3.46-2a.493.493 0 0 1-.18-.68c.14-.24.44-.32.68-.18m2.95 4l-3.46 2c-.23.14-.32.44-.18.68s.44.32.68.18l3.46-2c.24-.14.32-.44.18-.68a.493.493 0 0 0-.68-.18m9.43-2l3.46-2c.24-.14.54-.06.68.18s.06.54-.18.68l-3.46 2c-.24.14-.54.06-.68-.18a.493.493 0 0 1 .18-.68m.51 2l3.46 2c.23.14.32.44.18.68s-.44.32-.68.18l-3.46-2a.493.493 0 0 1-.18-.68c.14-.24.44-.32.68-.18"/><path fill="#212121" d="M17.89 4.182a10 10 0 0 0-1.89-.18q-.975 0-1.89.18l1.17 1.25c.39.41 1.04.41 1.42 0zm.96 3.32h-5.7c-.38 0-.54.47-.25.71l2.7 2.16c.24.19.57.19.8 0l2.7-2.16c.29-.24.13-.71-.25-.71M6.7 22.892l-4.13-2.75h3.75c.67 0 .94-.87.38-1.25l-4.35-2.93c-.23.8-.35 1.65-.35 2.5v3.85c0 .65.13 1.26.37 1.82h3.95c.67 0 .94-.87.38-1.24m22.93 1.24c.24-.56.37-1.17.37-1.82v-3.85c0-.85-.12-1.69-.34-2.5l-4.36 2.92c-.56.37-.3 1.25.38 1.25h3.75l-4.13 2.75c-.56.37-.3 1.25.38 1.25zM12 14a1 1 0 0 0-1 1v1a1 1 0 1 0 2 0v-1a1 1 0 0 0-1-1m8 0a1 1 0 0 0-1 1v1a1 1 0 1 0 2 0v-1a1 1 0 0 0-1-1m-6.12 5.812l1.38 1.38c.41.41 1.08.41 1.5 0l1.38-1.38c.67-.67.19-1.81-.75-1.81h-2.75c-.96 0-1.43 1.14-.76 1.81"/></g>',
  again: '<g fill="none"><path fill="#00a6ed" d="M2 6a4 4 0 0 1 4-4h20a4 4 0 0 1 4 4v20a4 4 0 0 1-4 4H6a4 4 0 0 1-4-4z"/><path fill="#fff" d="m25.865 10.218l-3.4-3.108c-.238-.24-.654-.062-.665.28v1.27a.36.36 0 0 1-.363.364h-9.865C8.505 9.033 6 11.507 6 14.563v3.151a.36.36 0 0 0 .603.27l2.245-2.058a.33.33 0 0 0 .115-.25v-1.102a2.62 2.62 0 0 1 2.62-2.62l9.864.031c.198 0 .364.167.364.364v1.268c0 .343.405.53.655.291l3.399-3.118a.374.374 0 0 0 0-.572M6.135 21.771l3.4 3.108c.238.24.654.063.665-.28V23.33a.36.36 0 0 1 .363-.363h9.865c3.067-.01 5.572-2.485 5.572-5.541v-3.113a.36.36 0 0 0-.603-.27L23.152 16.1a.33.33 0 0 0-.115.25v1.066a2.62 2.62 0 0 1-2.62 2.62l-9.864-.032a.37.37 0 0 1-.364-.364v-1.268c0-.343-.405-.53-.655-.291l-3.399 3.118a.375.375 0 0 0 0 .572"/></g>',
  dice: '<g fill="none"><path fill="#f3eef8" d="M13.883 2.451L4.494 6.504C3.532 6.934 3 8.024 3 9.127v13.041c0 1.514.546 2.81 1.857 3.39l9.286 4.044a4.53 4.53 0 0 0 3.714 0l9.286-5.047c1.31-.582 1.857-.873 1.857-2.387V9.127c0-1.103-.43-2.192-1.393-2.623l-9.49-4.053a5.2 5.2 0 0 0-4.234 0"/><path fill="#b4acbc" d="M4.857 25.559C3.547 24.977 3 23.682 3 22.168h26c0 1.514-.546 1.87-1.857 2.452l-9.286 4.981a4.53 4.53 0 0 1-3.714 0z"/><path fill="#b4acbc" d="M3 9.234a1.5 1.5 0 0 1 2.117-1.367l9.118 4.119A3 3 0 0 1 16 14.72v13.395a1.5 1.5 0 0 1-2.102 1.374l-9.701-4.254A2 2 0 0 1 3 23.404z"/><path fill="#e1d8ec" d="M29 9.254a1.5 1.5 0 0 0-2.117-1.367l-9.118 4.118A3 3 0 0 0 16 14.74v13.396a1.5 1.5 0 0 0 2.102 1.373l9.701-4.253A2 2 0 0 0 29 23.423z"/><path fill="#433b6b" d="M6.685 15.996c.82-.065 1.407-1.018 1.303-2.119c-.103-1.109-.854-1.946-1.673-1.873c-.82.066-1.407 1.019-1.303 2.12c.103 1.1.854 1.938 1.673 1.872m20.303-1.873c.104-1.1-.483-2.054-1.302-2.12c-.82-.065-1.57.773-1.674 1.873s.483 2.054 1.302 2.12c.82.073 1.57-.764 1.674-1.873m-13 9.754c.104 1.1-.483 2.054-1.303 2.12c-.82.065-1.57-.773-1.673-1.873c-.104-1.101.483-2.054 1.303-2.12c.82-.073 1.57.764 1.673 1.873m8.698-6.873c.82.065 1.406 1.018 1.302 2.119c-.103 1.109-.854 1.946-1.674 1.872c-.82-.065-1.406-1.018-1.302-2.119c.103-1.1.854-1.938 1.674-1.872m-1.698 7.119c.104-1.1-.483-2.054-1.302-2.12c-.82-.065-1.57.773-1.674 1.873s.483 2.054 1.302 2.12c.82.073 1.57-.764 1.674-1.873"/><path fill="#f8312f" d="M16 7.5c1.657 0 3-.448 3-1s-1.343-1-3-1s-3 .448-3 1s1.343 1 3 1"/></g>',
  pause: '<g fill="none"><path fill="#00a6ed" d="M2 6a4 4 0 0 1 4-4h20a4 4 0 0 1 4 4v20a4 4 0 0 1-4 4H6a4 4 0 0 1-4-4z"/><path fill="#fff" d="M12 9a1 1 0 0 0-1 1v12a1 1 0 0 0 1 1h2a1 1 0 0 0 1-1V10a1 1 0 0 0-1-1zm6 0a1 1 0 0 0-1 1v12a1 1 0 0 0 1 1h2a1 1 0 0 0 1-1V10a1 1 0 0 0-1-1z"/></g>',
  play: '<g fill="none"><path fill="#00a6ed" d="M2 6a4 4 0 0 1 4-4h20a4 4 0 0 1 4 4v20a4 4 0 0 1-4 4H6a4 4 0 0 1-4-4z"/><path fill="#fff" d="M23.5 15.134a1 1 0 0 1 0 1.732l-12 6.928a1 1 0 0 1-1.5-.866V9.072a1 1 0 0 1 1.5-.866z"/></g>',
  robot: '<g fill="none"><path fill="#f8312f" d="M5 3.5a1.5 1.5 0 0 1-1 1.415V12l2.16 5.487L4 23c-1.1 0-2-.9-2-1.998v-7.004a2 2 0 0 1 1-1.728V4.915A1.5 1.5 0 1 1 5 3.5m25.05.05c0 .681-.44 1.26-1.05 1.468V12.2c.597.347 1 .994 1 1.73v7.01c0 1.1-.9 2-2 2l-2.94-5.68L28 11.93V5.018a1.55 1.55 0 1 1 2.05-1.468"/><path fill="#ffb02e" d="M11 4.5A1.5 1.5 0 0 1 12.5 3h7a1.5 1.5 0 0 1 .43 2.938c-.277.082-.57.104-.847.186l-3.053.904l-3.12-.908c-.272-.08-.56-.1-.832-.18A1.5 1.5 0 0 1 11 4.5"/><path fill="#cdc4d6" d="M22.05 30H9.95C6.66 30 4 27.34 4 24.05V12.03C4 8.7 6.7 6 10.03 6h11.95C25.3 6 28 8.7 28 12.03v12.03c0 3.28-2.66 5.94-5.95 5.94"/><path fill="#212121" d="M9.247 18.5h13.506c2.33 0 4.247-1.919 4.247-4.25A4.257 4.257 0 0 0 22.753 10H9.247A4.257 4.257 0 0 0 5 14.25a4.257 4.257 0 0 0 4.247 4.25m4.225 7.5h5.056C19.34 26 20 25.326 20 24.5s-.66-1.5-1.472-1.5h-5.056C12.66 23 12 23.674 12 24.5s.66 1.5 1.472 1.5"/><path fill="#00a6ed" d="M10.25 12C9.56 12 9 12.56 9 13.25v2.5a1.25 1.25 0 1 0 2.5 0v-2.5c0-.69-.56-1.25-1.25-1.25m11.5 0c-.69 0-1.25.56-1.25 1.25v2.5a1.25 1.25 0 1 0 2.5 0v-2.5c0-.69-.56-1.25-1.25-1.25"/></g>',
  clipboard: '<g fill="none"><path fill="#e19747" d="M5 4.5A1.5 1.5 0 0 1 6.5 3h19A1.5 1.5 0 0 1 27 4.5v24a1.5 1.5 0 0 1-1.5 1.5h-19A1.5 1.5 0 0 1 5 28.5z"/><path fill="#f3eef8" d="M25 6a1 1 0 0 0-1-1H8a1 1 0 0 0-1 1v21a1 1 0 0 0 1 1h10.586c.147 0 .29-.032.421-.093l.321-.783l.632-4.086l4.457-.783l.49-.247a1 1 0 0 0 .093-.422z"/><path fill="#cdc4d6" d="M24.91 22H20a1 1 0 0 0-1 1v4.91a1 1 0 0 0 .293-.203l5.414-5.414A1 1 0 0 0 24.91 22"/><path fill="#9b9b9b" d="M18 4a2 2 0 1 0-4 0h-1a2 2 0 0 0-2 2v1.5a.5.5 0 0 0 .5.5h9a.5.5 0 0 0 .5-.5V6a2 2 0 0 0-2-2zm-1 0a1 1 0 1 1-2 0a1 1 0 0 1 2 0m-8 8.5a.5.5 0 0 1 .5-.5h13a.5.5 0 0 1 0 1h-13a.5.5 0 0 1-.5-.5m0 3a.5.5 0 0 1 .5-.5h13a.5.5 0 0 1 0 1h-13a.5.5 0 0 1-.5-.5m.5 2.5a.5.5 0 0 0 0 1h13a.5.5 0 0 0 0-1zM9 21.5a.5.5 0 0 1 .5-.5h8a.5.5 0 0 1 0 1h-8a.5.5 0 0 1-.5-.5"/></g>',
  gear: '<g fill="none"><path fill="#b4acbc" d="M12.847 3.834A2 2 0 0 1 14.84 2h2.32a2 2 0 0 1 1.993 1.834l.235 2.825a.5.5 0 0 0 .821.34l2.164-1.831a2 2 0 0 1 2.706.112l1.64 1.64a2 2 0 0 1 .113 2.707l-1.83 2.163a.5.5 0 0 0 .34.822l2.824.235A2 2 0 0 1 30 14.84v2.32a2 2 0 0 1-1.834 1.993l-2.825.235a.5.5 0 0 0-.34.821l1.831 2.164a2 2 0 0 1-.112 2.706l-1.64 1.64a2 2 0 0 1-2.707.113l-2.164-1.83a.5.5 0 0 0-.82.34l-.236 2.824A2 2 0 0 1 17.16 30h-2.32a2 2 0 0 1-1.993-1.834l-.235-2.825a.5.5 0 0 0-.822-.34l-2.163 1.831a2 2 0 0 1-2.706-.112l-1.64-1.64a2 2 0 0 1-.113-2.707l1.83-2.164a.5.5 0 0 0-.34-.82l-2.824-.236A2 2 0 0 1 2 17.16v-2.32a2 2 0 0 1 1.834-1.993l2.825-.235a.5.5 0 0 0 .34-.822L5.168 9.628A2 2 0 0 1 5.28 6.92l1.64-1.64a2 2 0 0 1 2.707-.113l2.163 1.83a.5.5 0 0 0 .822-.34zM21 16a5 5 0 1 0-10 0a5 5 0 0 0 10 0"/><path fill="#998ea4" d="M24 16a8 8 0 1 1-16 0a8 8 0 0 1 16 0m-3.5 0a4.5 4.5 0 1 0-9 0a4.5 4.5 0 0 0 9 0"/><path fill="#cdc4d6" d="M10.5 16a5.5 5.5 0 1 1 11 0a5.5 5.5 0 0 1-11 0M21 16a5 5 0 1 0-10 0a5 5 0 0 0 10 0"/></g>',
  sudden: '<g fill="none"><path fill="#f8312f" d="M9.4 11.236L6.025 2.341c-.088-.233.181-.437.382-.29l7.9 5.806c.107.08.26.06.343-.046l2.963-3.724a.25.25 0 0 1 .444.132l.416 4.493a.25.25 0 0 0 .308.22l7.97-1.938a.25.25 0 0 1 .242.412l-4.927 5.37a.25.25 0 0 0 .055.382l7.344 4.456a.25.25 0 0 1-.104.463l-8.555.891a.25.25 0 0 0-.213.325l1.398 4.386a.25.25 0 0 1-.39.275l-3.842-2.908a.25.25 0 0 0-.382.104l-3.57 8.703a.25.25 0 0 1-.476-.042L11.054 19.2a.25.25 0 0 0-.303-.192l-7.433 1.783c-.245.058-.413-.243-.234-.421l5.145-5.102a.25.25 0 0 0-.084-.41l-3.97-1.572a.25.25 0 0 1 .032-.475l5.02-1.244a.25.25 0 0 0 .173-.332"/><path fill="#fcd53f" d="m12.276 15.226l-1.2 1.213a.25.25 0 0 0 .22.422l2.056-.367a.25.25 0 0 1 .29.205l.69 4.092c.046.264.413.296.502.043l1.296-3.665a.25.25 0 0 1 .396-.108l1.064.888a.25.25 0 0 0 .41-.192v-1.486a.25.25 0 0 1 .27-.249l4.512.37c.228.019.303-.3.09-.385l-4.712-1.893a.25.25 0 0 1-.116-.37l.889-1.34a.25.25 0 0 0-.217-.389l-1.475.047a.25.25 0 0 1-.257-.233l-.177-2.672c-.017-.25-.349-.323-.469-.104l-1.197 2.189a.25.25 0 0 1-.373.077l-2.349-1.835a.25.25 0 0 0-.393.268l.893 2.976a.25.25 0 0 1-.199.319l-2.05.341a.25.25 0 0 0-.088.461l1.645.987a.25.25 0 0 1 .049.39"/></g>',
  bullseye: '<g fill="none"><path fill="#f4f4f4" d="M14 28.292c5.684 0 10.292-4.608 10.292-10.292S19.684 7.708 14 7.708S3.708 12.316 3.708 18S8.316 28.292 14 28.292"/><path fill="#f8312f" d="M26 18c0-6.627-5.373-12-12-12S2 11.373 2 18s5.373 12 12 12s12-5.373 12-12m-3 0a9 9 0 1 1-18 0a9 9 0 0 1 18 0m-9 6a6 6 0 1 1 0-12a6 6 0 0 1 0 12m3-6a3 3 0 1 0-6 0a3 3 0 0 0 6 0"/><path fill="#9b9b9b" d="M14.25 17.742a.864.864 0 0 0 1.232 0l4.26-4.254a.86.86 0 0 0 0-1.23a.864.864 0 0 0-1.232 0l-4.26 4.254a.88.88 0 0 0 0 1.23"/><path fill="#46a4fb" d="m19.658 10.093l-.45-1.59c-.54-1.9-.01-3.95 1.39-5.34l.89-.89a.906.906 0 0 1 1.52.39L24 6zM22 12.33l1.572.458c1.878.55 3.904.01 5.278-1.416l.88-.906c.494-.5.277-1.356-.385-1.55L26 8z"/><path fill="#50e2ff" d="M15.85 16.152a2.892 2.892 0 0 0 4.307-.24l5.424-6.798a1.92 1.92 0 0 0-2.698-2.696l-6.802 5.42a2.904 2.904 0 0 0-.231 4.314"/><path fill="#46a4fb" d="M21.258 10.742a.86.86 0 0 0 1.23 0l4.254-4.254a.86.86 0 0 0 0-1.23a.86.86 0 0 0-1.23 0l-4.254 4.254a.86.86 0 0 0 0 1.23"/></g>',
  crown: '<g fill="none"><path fill="#00a6ed" fill-rule="evenodd" d="M6.94 23.5a1.58 1.58 0 1 1-3.16 0a1.58 1.58 0 0 1 3.16 0m21.26 0a1.58 1.58 0 1 1-3.16 0a1.58 1.58 0 0 1 3.16 0" clip-rule="evenodd"/><path fill="#e19747" fill-rule="evenodd" d="m10.25 13.27l3.18 4.27l-6.59.76l2.12-4.89c-.51-.2-.87-.7-.87-1.28c0-.76.62-1.38 1.38-1.38a1.383 1.383 0 0 1 .78 2.52m12.76.14l2.12 4.89l-6.59-.76l3.18-4.27c-.36-.25-.6-.67-.6-1.14c0-.76.62-1.38 1.38-1.38s1.38.62 1.38 1.38c0 .58-.36 1.08-.87 1.28" clip-rule="evenodd"/><path fill="#ffb02e" d="M29.98 13.09c0-.76-.62-1.38-1.38-1.38s-1.38.62-1.38 1.38c0 .28.09.55.23.76c-.22 0-.44.05-.65.19l-3.93 2.54c-.52.33-1.2.21-1.57-.29l-4.37-5.93a.7.7 0 0 0-.11-.13a1.721 1.721 0 1 0-1.66 0c-.04.04-.08.08-.11.13l-4.37 5.93c-.36.5-1.05.62-1.57.29l-3.93-2.54c-.21-.14-.43-.19-.65-.19c.15-.22.23-.48.23-.76c0-.76-.62-1.38-1.38-1.38S2 12.33 2 13.09s.62 1.38 1.38 1.38c.05 0 .1 0 .14-.01c-.13.23-.18.5-.12.79L6 28.22c.19.93 1.01 1.6 1.96 1.6h16.06c.95 0 1.77-.67 1.96-1.6l2.6-12.97c.06-.29 0-.57-.12-.79c.05 0 .1.01.14.01c.76 0 1.38-.62 1.38-1.38"/><path fill="#00a6ed" d="M15.99 26a2.5 2.5 0 1 0 0-5a2.5 2.5 0 0 0 0 5"/><path fill="#f8312f" fill-rule="evenodd" d="M11 23.5a1.5 1.5 0 1 1-3 0a1.5 1.5 0 0 1 3 0m13 0a1.5 1.5 0 1 1-3 0a1.5 1.5 0 0 1 3 0" clip-rule="evenodd"/></g>',
  star: '<path fill="#fcd53f" d="m18.7 4.627l2.247 4.31a2.27 2.27 0 0 0 1.686 1.189l4.746.65c2.538.35 3.522 3.479 1.645 5.219l-3.25 2.999a2.23 2.23 0 0 0-.683 2.04l.793 4.398c.441 2.45-2.108 4.36-4.345 3.24l-4.536-2.25a2.28 2.28 0 0 0-2.006 0l-4.536 2.25c-2.238 1.11-4.786-.79-4.345-3.24l.793-4.399c.14-.75-.12-1.52-.682-2.04l-3.251-2.998c-1.877-1.73-.893-4.87 1.645-5.22l4.746-.65a2.23 2.23 0 0 0 1.686-1.189l2.248-4.309c1.144-2.17 4.264-2.17 5.398 0"/>',
  gem: '<g fill="none"><path fill="#00a6ed" d="M24.21 7.9H7.79a.54.54 0 0 0-.42.21L2.15 15a.52.52 0 0 0 0 .67L15.59 29.9a.52.52 0 0 0 .76 0l13.44-14.23a.52.52 0 0 0 0-.67l-5.16-6.89a.54.54 0 0 0-.42-.21"/><path fill="#1c5cd7" d="M15.594 29.902c.156.166.333.176.402.16l.017-.097V13.996H2.91c-.2.266-.632.837-.754.996c-.152.2-.254.418 0 .688z"/><path fill="#0084ce" d="M15.996 7.9H7.79a.54.54 0 0 0-.42.21l-4.837 6.385c-.202.259-.406.712.501.712c3.37.002 6.156.009 8.106.009c1.046-1.566 2.724-4.077 4.856-7.316"/><path fill="#aeddff" d="m16 30.059l-4.86-14.83h9.72z"/><path fill="#26eafc" d="M24.047 7.9h-8.031v7.298h13.883a.6.6 0 0 0-.1-.197c-.094-.134-4.983-6.642-5.1-6.806s-.328-.295-.652-.295"/><path fill="#b4f6fc" d="m16 7.9l2.43 3.67l2.43 3.66h-9.72l2.43-3.66z"/></g>',
  sparkles: '<path fill="#f9c23c" d="M10.52 7.052a1.17 1.17 0 0 1-.639-.636L8.93 4.257c-.178-.343-.69-.343-.858 0l-.952 2.16a1.28 1.28 0 0 1-.638.635l-1.214.524a.462.462 0 0 0 0 .838l1.214.524c.293.121.523.353.638.636l.952 2.169c.178.343.69.343.858 0l.952-2.17c.126-.282.356-.504.638-.635l1.214-.524a.462.462 0 0 0 0-.838zm15.054 6.503a3.73 3.73 0 0 1-1.922-1.977L20.79 4.81a1.432 1.432 0 0 0-2.58 0l-2.863 6.768a3.8 3.8 0 0 1-1.921 1.977l-3.622 1.64c-1.072.53-1.072 2.08 0 2.61l3.622 1.64a3.74 3.74 0 0 1 1.922 1.977l2.862 6.768a1.432 1.432 0 0 0 2.58 0l2.863-6.768a3.8 3.8 0 0 1 1.921-1.977l3.622-1.64c1.072-.53 1.072-2.08 0-2.61zM8.281 20.33c.16.392.454.696.822.872l1.55.725a.646.646 0 0 1 0 1.146l-1.55.725c-.368.176-.661.49-.822.872l-1.228 2.977a.61.61 0 0 1-1.106 0L4.72 24.67a1.66 1.66 0 0 0-.822-.872l-1.55-.725a.646.646 0 0 1 0-1.146l1.55-.725c.368-.176.661-.49.822-.872l1.228-2.977a.61.61 0 0 1 1.106 0z"/>',
  trophy: '<g fill="none"><path fill="#d3883e" d="M10.52 7.521a3.435 3.435 0 0 0-4.213-2.369a2 2 0 0 0-.163.046c-2.493.831-2.691 4.214-.455 5.45l4.97 2.75a.866.866 0 1 0 .838-1.516l-4.97-2.75c-.982-.543-.823-1.956.16-2.288l.005-.002l.07-.018c.899-.25 1.834.27 2.093 1.175a.866.866 0 1 0 1.666-.478m11.939.478a1.7 1.7 0 0 1 2.118-1.168l.045.011l.007.002c.981.332 1.14 1.745.158 2.288l-4.97 2.75a.866.866 0 1 0 .84 1.516l4.97-2.75c2.235-1.236 2.037-4.619-.456-5.45a2 2 0 0 0-.164-.046a3.435 3.435 0 0 0-4.213 2.37a.866.866 0 1 0 1.666.477m-5.133 9.511v-4.22h-3.34v4.22c0 .74-.33 1.45-.9 1.92l-1.92 1.6h8.98l-1.92-1.6a2.51 2.51 0 0 1-.9-1.92"/><path fill="#ffb02e" d="M15.658 16.54a6.97 6.97 0 0 1-6.97-6.97V2.71c0-.39.32-.71.71-.71h12.53c.39 0 .71.32.71.71v6.86c0 3.85-3.12 6.97-6.98 6.97"/><path fill="#6d4534" d="M22.792 21.03H8.197c-.77 0-1.423.51-1.571 1.22l-1.614 7.09c-.073.33.19.64.549.64h19.878c.359 0 .622-.31.549-.64l-1.614-7.09c-.158-.71-.812-1.22-1.582-1.22"/><path fill="#ffb02e" d="M18.383 23.96h-5.766a.625.625 0 0 0-.613.64v1.81c0 .35.268.64.613.64h5.766c.335 0 .613-.28.613-.64V24.6c0-.35-.268-.64-.613-.64"/></g>',
}

// 四家头像：按真实座位索引（0 我 / 1 下家 / 2 对家 / 3 上家）
const AVATARS = { 0: 'sunglasses', 1: 'fox', 2: 'panda', 3: 'tiger' }

// 彩色图标组件：直接把 Fluent Emoji 的 SVG 内容注入（viewBox 32×32）
function Icon({ name, size = 16, className }) {
  const body = ICONS[name]
  if (!body) return null
  return h('svg', {
    viewBox: '0 0 32 32',
    width: size,
    height: size,
    className: className || '',
    'aria-hidden': true,
    dangerouslySetInnerHTML: { __html: body },
  })
}

// 牌面组件：左上角标 + 中央大花色 + 右下角标（旋转 180°）
function Card({ card, level, selected, dim, onClick, small, style }) {
  const isWildCard = isWild(card, level)
  const isJoker = card.rank >= SMALL_JOKER
  const isLevel = !isJoker && card.rank === level
  const cls = ['gd-card']
  if (selected) cls.push('gd-card-sel')
  if (dim) cls.push('gd-card-dim')
  if (isWildCard) cls.push('gd-card-wild')
  if (isJoker) cls.push(card.rank === BIG_JOKER ? 'gd-card-joker-big' : 'gd-card-joker-small')
  if (isLevel) cls.push('gd-card-level')
  if (small) cls.push('gd-card-small')
  const red = card.suit === 'H' || card.suit === 'D' || isJoker
  const corner = isJoker ? '' : RANK_TEXT[card.rank] + SUIT_CHAR[card.suit]
  const center = isJoker ? (card.rank === BIG_JOKER ? '🃏' : '🃏') : SUIT_CHAR[card.suit]
  return h(
    'div',
    { className: cls.join(' '), onClick: onClick, style: Object.assign({}, style, red ? { color: '#d64541' } : null) },
    isJoker
      ? h(
          'div',
          { className: 'gd-card-joker-inner' },
          h('span', { className: 'gd-joker-label' }, 'JOKER'),
          h(Icon, { name: 'joker', size: small ? 26 : 40 }),
        )
      : h('div', { className: 'gd-card-corner' }, corner),
    isJoker ? null : h('div', { className: 'gd-card-center' }, center),
    isJoker ? null : h('div', { className: 'gd-card-corner gd-card-corner-br' }, corner),
    isLevel && !isWildCard ? h('span', { className: 'gd-level-tag' }, '级') : null,
    isWildCard ? h('span', { className: 'gd-wild-tag' }, '配') : null,
  )
}

// 把当前局面序列化为文本，通过 host.askAgent 发给 Agent 咨询（LLM 关键决策）
function buildSituationText(game) {
  const snap = game.snapshot()
  const lines = []
  lines.push('【掼蛋局面】')
  lines.push(`级牌：打${RANK_TEXT[game.level]}（逢人配=红桃${RANK_TEXT[game.level]}×2）`)
  lines.push(`第 ${snap.round} 局 · 当前轮到：${game._name(game.curPlayer)}${game.curPlayer === 0 ? '（我）' : ''}`)
  lines.push('我方队友：对家；座位顺序：我(0) → 下家(1) → 对家(2) → 上家(3)')
  const t = game.table
  const shown = [1, 2, 3].filter((i) => t[i] && t[i].length).map((i) => `${game._name(i)}：${cardsText(t[i])}`)
  if (shown.length) {
    lines.push('本轮各家已出：' + shown.join('；'))
    if (game.lastPlay) lines.push(`最后牌型（需要压过它）：${cardsText(t[game.lastMover] || [])}`)
  } else {
    lines.push('本轮无人出牌，我自由出牌')
  }
  lines.push(`各家剩余：我 ${snap.hands[0].length} 张 / 下家 ${snap.hands[1].length} 张 / 对家 ${snap.hands[2].length} 张 / 上家 ${snap.hands[3].length} 张`)
  lines.push(`我的手牌：${cardsText(snap.hands[0])}`)
  const out = []
  for (let r = 3; r <= 15; r++) {
    const n = game.played[r] || 0
    if (n > 0) out.push(`${RANK_TEXT[r]}×${n}`)
  }
  if (game.played[16]) out.push(`小王×${game.played[16]}`)
  if (game.played[17]) out.push(`大王×${game.played[17]}`)
  lines.push('已出牌统计：' + (out.length ? out.join(' ') : '无'))
  lines.push('请回复固定格式：【掼蛋建议】出牌：<牌面列表，空格分隔，如 9♦ 9♥；决定过牌写 过>；理由：<一段分析>')
  return lines.join('\n')
}

function GuandanPanel({ host }) {
  const [game, setGame] = React.useState(null)
  // 引擎原地修改 game 实例，用 tick 强制重渲染（不能 setGame({...game})——浅拷贝会丢原型方法导致崩溃）
  const [tick, setTick] = React.useState(0)
  const refresh = () => setTick((t) => t + 1)
  const [selected, setSelected] = React.useState([])
  const [speed, setSpeed] = React.useState(1200)
  const [speedOpen, setSpeedOpen] = React.useState(false)
  const [autoPlay, setAutoPlay] = React.useState(true)
  const [autoAll, setAutoAll] = React.useState(false) // 全自动模式：AI 连玩家座位也自动打
  const [status, setStatus] = React.useState('')

  const seat = 0 // 玩家坐在 0 号位

  const startNew = () => {
    const g = new Game({ seed: Math.floor(Math.random() * 100000), seat, withGong: true })
    g.newRound()
    setGame(g)
    setSelected([])
    setAutoPlay(true) // 新局默认恢复 AI 自动打
    setStatus(`第 ${g.round} 局开始，打 ${RANK_TEXT[g.level]}`)
  }

  // 手动出牌
  const doPlay = (cards) => {
    if (!game) return
    const res = game.play(game.curPlayer, cards)
    setSelected([])
    setStatus(res.ok ? '' : res.reason)
    // 出牌后若轮到 AI 家，恢复自动继续
    if (res.ok && game.phase === 'playing' && game.curPlayer !== seat) setAutoPlay(true)
    refresh()
  }

  const doPass = () => {
    if (!game) return
    const res = game.play(game.curPlayer, [])
    setStatus(res.ok ? '' : res.reason)
    if (res.ok && game.phase === 'playing' && game.curPlayer !== seat) setAutoPlay(true)
    refresh()
  }

  // AI 自动走一步（用规则 agent），把决策理由记入日志；全自动模式下玩家座位也由 AI 打
  const aiStep = () => {
    if (!game || game.phase !== 'playing') return false
    if (game.curPlayer === seat && !autoAll) {
      // 轮到玩家（我）且非全自动：暂停 AI，等手动出牌
      setAutoPlay(false)
      setStatus('轮到你了，请手动出牌（可点 🤖 咨询 Agent 要建议）')
      refresh()
      return false
    }
    const player = game.curPlayer // 出牌人（play 后 curPlayer 会轮转，必须先用变量记住）
    const move = ruleAgentDecide(game, player)
    const res = game.play(player, move.cards)
    if (res.ok && move.reason) game.logLine(`🤖 ${game._name(player)} 思考：${move.reason}`)
    setStatus(res.ok ? '' : res.reason)
    refresh()
    return res.ok
  }

  // 把当前局面发给 Agent 咨询（LLM 关键决策）；失败时翻译宿主 reason 并给出兜底方案
  const askAgent = async () => {
    if (!game) return
    try {
      const text = buildSituationText(game)
      setStatus('已把局面发给 Agent，等待回复…')
      const res = await host.askAgent(text)
      if (res && res.ok) {
        setStatus('✅ 已投递给 Agent，去左侧对话区看回复（格式：【掼蛋建议】出牌：…；理由：…）')
        return
      }
      // 失败：翻译宿主返回的 reason，给出明确指引
      const reason = (res && res.reason) || 'unknown'
      const msg = (res && res.message) || JSON.stringify(res)
      const guide = {
        unavailable: '⚠️ 未打通：' + msg + ' → 请确认左侧已打开一个对话（新建或进入已有对话）且面板归属当前对话；若当前对话正在等我回复/等你输入，可先回复完再点咨询',
        busy: '⏳ 对话正忙：' + msg + ' → 等左侧对话空闲（AI 回复完或你先发条消息）后再点一次',
        invalid: '⚠️ 内容无效：' + msg,
      }
      setStatus(guide[reason] || ('⚠️ 投递失败：' + msg + '（reason=' + reason + '）'))
      // 兜底：把局面文本放窗口上，用户可手动复制到对话区
      window.__lastSituation = text
    } catch (e) {
      setStatus('❌ askAgent 异常：' + (e && e.message ? e.message : String(e)))
    }
  }

  // 复制当前局面文本（兜底通道：手动粘贴到对话区咨询）
  const copySituation = async () => {
    if (!game) return
    const text = buildSituationText(game)
    try {
      await navigator.clipboard.writeText(text)
      setStatus('📋 局面已复制到剪贴板，粘贴到左侧对话区即可咨询')
    } catch (e) {
      window.__lastSituation = text
      setStatus('复制失败，请从面板日志下方的「局面文本」手动复制（已生成在 window.__lastSituation）')
    }
  }

  // 循环自动打：依赖 tick/game 变化时重建 timer
  React.useEffect(() => {
    if (!game) return
    // 全自动模式：一局结束自动开下一局，整盘结束自动重开
    if (autoAll && game.phase === 'idle') {
      const t = setTimeout(() => {
        game.newRound()
        refresh()
      }, speed)
      return () => clearTimeout(t)
    }
    if (autoAll && game.phase === 'gameOver') {
      const t = setTimeout(() => {
        startNew()
      }, speed * 2)
      return () => clearTimeout(t)
    }
    if (autoPlay && game.phase === 'playing') {
      const t = setTimeout(() => {
        if (game.phase === 'playing') aiStep()
      }, speed)
      return () => clearTimeout(t)
    }
    if (game.phase === 'idle' || game.phase === 'gameOver') setAutoPlay(false)
  }, [autoPlay, autoAll, speed, tick, game])

  // 选牌：用【手牌索引】标记选中（两副牌存在同花色同点数重复牌，按 rank+suit 去重会漏选）
  const toggleCard = (i) => {
    if (selected.includes(i)) setSelected(selected.filter((x) => x !== i))
    else setSelected([...selected, i])
  }

  const snap = game ? game.snapshot() : null
  const mySorted = snap ? snap.hands[seat] : []
  // 选中的牌（按索引从排序后的手牌取；_sortHand 排序稳定，索引在渲染间一致）
  const selectedCards = selected.map((i) => mySorted[i]).filter(Boolean)
  const selectedDetect = selectedCards.length ? detect(selectedCards, game ? game.level : RANK_2) : null
  const playLabel = selectedDetect
    ? '出牌（' + { single: '单张', pair: '对子', triple: '三张', triple_pair: '三带二', straight: '顺子', straight_pair: '连对', plane: '钢板', bomb: '炸弹', straight_flush: '同花顺', four_joker: '四大天王' }[selectedDetect.type] + '）'
    : selectedCards.length > 0
      ? `出牌（${selectedCards.length} 张）`
      : '出牌'

  // 布局：四座环绕（我底 / 对家顶(正对面) / 上家左 / 下家右）
  // 出牌顺序 我→下家→对家→上家 = 视觉顺时针 底→右→顶→左
  const seatName = { 0: '我', 1: '下家', 2: '对家', 3: '上家' }
  const SPEED_PRESETS = [
    { v: 3000, label: '慢' },
    { v: 1200, label: '中' },
    { v: 500, label: '快' },
    { v: 200, label: '极快' },
  ]
  const speedLabel = speed >= 2000 ? '慢' : speed >= 800 ? '中' : speed >= 400 ? '快' : '极快'
  const topIdx = (seat + 2) % 4 // 对家（正对面）
  const leftIdx = (seat + 3) % 4 // 上家（逆时针前一位）
  const rightIdx = (seat + 1) % 4 // 下家（顺时针后一位）
  const myCards = snap ? snap.hands[seat] : []
  // 手牌叠放：牌数越多叠得越密（负 margin 由牌数决定）
  const nHand = myCards.length
  const overlap = nHand > 22 ? 34 : nHand > 14 ? 26 : nHand > 8 ? 18 : 10

  // 玩家信息块（对手）
  const oppBlock = (i, posCls) => {
    const active = snap.curPlayer === i
    const done = snap.outOrder.includes(i)
    return h(
      'div',
      { key: i, className: 'gd-player gd-player-' + posCls + ' gd-p' + i + (active ? ' gd-active' : '') + (done ? ' gd-done' : '') },
      h('div', { className: 'gd-player-head' },
        h('div', { className: 'gd-player-name' }, seatName[i] + (done ? ' ✓' : '')),
        h('div', { className: 'gd-player-cnt' }, `${snap.hands[i].length} 张`),
      ),
      h('div', { className: 'gd-player-avatar' }, h(Icon, { name: AVATARS[i] || 'sunglasses', size: 30 })),
    )
  }

  // 中央出牌槽（四方位）
  const playSlot = (i, slotCls) => {
    const cards = snap.table[i] || []
    const active = snap.curPlayer === i
    return h(
      'div',
      { key: i, className: 'gd-slot gd-slot-' + slotCls + (active ? ' gd-slot-active' : '') + (cards.length === 0 ? ' gd-slot-empty' : '') },
      cards.length
        ? cards.map((c, j) => h(Card, { key: j, card: c, level: snap.level, small: true }))
        : h('span', { className: 'gd-slot-hint' }, active ? '轮到 TA' : ''),
    )
  }

  return h(
    'div',
    { className: 'gd-root' },
    // 顶部控制条（分组：牌局控制 | 速度 | 咨询 | 调试）
    h(
      'div',
      { className: 'gd-topbar' },
      h(
        'div',
        { className: 'gd-tb-group' },
        h('button', { className: 'gd-btn gd-btn-primary', onClick: startNew, title: '开新的一局' }, h(Icon, { name: 'again', size: 17 }), '新局'),
        h('button', { className: 'gd-btn' + (autoAll ? ' gd-btn-on' : ''), onClick: () => { if (!autoAll) setAutoPlay(true); setAutoAll(!autoAll) }, disabled: !game, title: autoAll ? '切回手动模式' : 'AI 连你的座位一起打' }, h(Icon, { name: 'dice', size: 17 }), autoAll ? '全自动' : '手动'),
        h('button', { className: 'gd-btn', onClick: () => setAutoPlay(!autoPlay), disabled: !game || autoAll, title: autoPlay ? '暂停 AI' : '继续 AI' }, h(Icon, { name: autoPlay ? 'pause' : 'play', size: 17 }), autoPlay ? '暂停' : '继续'),
      ),
      h(
        'div',
        { className: 'gd-tb-group gd-tb-tools' },
        h('button', { className: 'gd-btn gd-btn-llm gd-btn-icon', onClick: askAgent, disabled: !game || game.phase !== 'playing', title: '把局面发给左侧对话区的 Agent 咨询' }, h(Icon, { name: 'robot', size: 17 })),
        h('button', { className: 'gd-btn gd-btn-icon', onClick: copySituation, disabled: !game, title: '复制局面文本到剪贴板' }, h(Icon, { name: 'clipboard', size: 17 })),
        h(
          'div',
          { className: 'gd-speed-wrap' },
          h(
            'button',
            {
              className: 'gd-btn gd-btn-icon' + (speedOpen ? ' gd-btn-on' : ''),
              onClick: () => setSpeedOpen(!speedOpen),
              title: `出牌速度：${speedLabel}`,
            },
            h(Icon, { name: 'gear', size: 17 }),
          ),
          speedOpen
            ? h(
                'div',
                { className: 'gd-speed-pop' },
                h('div', { className: 'gd-speed-title' }, '出牌速度'),
                h(
                  'div',
                  { className: 'gd-speed-presets' },
                  SPEED_PRESETS.map((p) =>
                    h(
                      'button',
                      { key: p.v, className: 'gd-speed-chip' + (speed === p.v ? ' gd-speed-chip-on' : ''), onClick: () => { setSpeed(p.v); setSpeedOpen(false) } },
                      p.label,
                    ),
                  ),
                ),
                h('input', {
                  type: 'range',
                  min: 200,
                  max: 3000,
                  step: 100,
                  value: speed,
                  onChange: (e) => setSpeed(Number(e.target.value)),
                  className: 'gd-speed-range',
                }),
                h('div', { className: 'gd-speed-val' }, `${speed} ms / 手`),
              )
            : null,
        ),
      ),
    ),
    status ? h('div', { className: 'gd-status' }, status) : null,
    // 桌面
    snap
      ? h(
          'div',
          { className: 'gd-table' },
          // 双方级牌记分板
          h(
            'div',
            { className: 'gd-score' },
            h(
              'div',
              { className: 'gd-score-card gd-score-mine' + (snap.activeTeam === 0 ? ' gd-score-on' : '') },
              h('div', { className: 'gd-score-tag' }, '我方', snap.activeTeam === 0 ? h('span', { className: 'gd-score-attack' }, '主攻') : null),
              h('div', { className: 'gd-score-lv' }, RANK_TEXT[snap.teamLevel[0]]),
              h('div', { className: 'gd-score-sub' }, snap.teamLevel[0] === RANK_A ? '打 A' : '级牌'),
            ),
            h(
              'div',
              { className: 'gd-score-mid' },
              h('div', { className: 'gd-score-round' }, `第 ${snap.round} 局`),
              h('div', { className: 'gd-score-vs' }, 'VS'),
            ),
            h(
              'div',
              { className: 'gd-score-card gd-score-theirs' + (snap.activeTeam === 1 ? ' gd-score-on' : '') },
              h('div', { className: 'gd-score-tag' }, '对方', snap.activeTeam === 1 ? h('span', { className: 'gd-score-attack' }, '主攻') : null),
              h('div', { className: 'gd-score-lv' }, RANK_TEXT[snap.teamLevel[1]]),
              h('div', { className: 'gd-score-sub' }, snap.teamLevel[1] === RANK_A ? '打 A' : '级牌'),
            ),
          ),
          snap.outOrder.length
            ? h('div', { className: 'gd-out' }, '出完 ' + snap.outOrder.map((i) => seatName[i]).join('→'))
            : null,
          snap.winner !== null
            ? h('div', { className: 'gd-banner' }, `🏆 ${snap.winner === 0 ? '我方' : '对方'} 过 A 获胜，整盘结束！`)
            : null,
          // 牌桌主体：上家顶 / 对家左+中央+下家右 / 我底
          h(
            'div',
            { className: 'gd-board' },
            oppBlock(topIdx, 'top'),
            h(
              'div',
              { className: 'gd-board-mid' },
              oppBlock(leftIdx, 'left'),
              h(
                'div',
                { className: 'gd-play-zone' },
                playSlot(topIdx, 'top'),
                playSlot(leftIdx, 'left'),
                playSlot(rightIdx, 'right'),
                playSlot(seat, 'bottom'),
              ),
              oppBlock(rightIdx, 'right'),
            ),
            h(
              'div',
              { className: 'gd-my' },
              h(
                'div',
                { className: 'gd-hand' },
                myCards.map((c, i) =>
                  h(Card, {
                    key: i,
                    card: c,
                    level: snap.level,
                    selected: selected.includes(i),
                    onClick: () => toggleCard(i),
                    style: i > 0 ? { marginLeft: -overlap } : undefined,
                  }),
                ),
              ),
            ),
          ),
          // 操作栏
          h(
            'div',
            { className: 'gd-actions' },
            h('button', { className: 'gd-btn gd-btn-main', onClick: () => doPlay(selectedCards), disabled: !game || game.phase !== 'playing' || selectedCards.length === 0 }, playLabel),
            h('button', { className: 'gd-btn gd-btn-pass', onClick: doPass, disabled: !game || game.phase !== 'playing' }, '过牌'),
            h('button', { className: 'gd-btn', onClick: () => { const g2 = game; if (g2.phase === 'gameOver') { startNew() } else if (g2.phase === 'idle') { g2.newRound(); refresh(); setAutoPlay(true) } }, disabled: !game || (game.phase !== 'idle' && game.phase !== 'gameOver') }, snap && snap.winner !== null ? '重新开始' : '下一局'),
          ),
        )
      : h('div', { className: 'gd-empty' }, '点击「新局」开始'),
  )
}

globalThis.__THETHING_PANEL__.define({
  guandan: (host) => () => h(GuandanPanel, { host }),
})
