// 坦克大战面板 —— 无 import / 无 JSX，define 在顶层同步调用。
// 结构：常量 → 地图生成 → 碰撞工具 → Engine（状态机 + 更新）→ 渲染 → React 面板

const { React } = globalThis.__THETHING_PANEL__
const h = React.createElement

/* ============================ 常量 ============================ */

const TILE = 32
const COLS = 13
const ROWS = 13
const W = COLS * TILE
const H = ROWS * TILE

const T = { EMPTY: 0, BRICK: 1, STEEL: 2, WATER: 3, GRASS: 4, BASE: 5, BASE_DEAD: 6, HARD: 7 }

const DIR_VEC = {
  up: { x: 0, y: -1 },
  right: { x: 1, y: 0 },
  down: { x: 0, y: 1 },
  left: { x: -1, y: 0 },
}
const DIR_ANGLE = { up: -Math.PI / 2, right: 0, down: Math.PI / 2, left: Math.PI }
const DIR_LIST = ['up', 'right', 'down', 'left']

const TANK_SIZE = 28
const BASE_COL = 6
const BASE_ROW = ROWS - 1
const PLAYER_SPAWN = { col: 4, row: ROWS - 1 }
const ENEMY_SPAWNS = [
  { col: 0, row: 0 },
  { col: 6, row: 0 },
  { col: COLS - 1, row: 0 },
]

// 基地护圈：两层加固砖（每层需 3 发打穿）。
// → 基地不是无敌的，敌人凿穿两层护圈就能进来，但给了玩家反应时间（约 6 发）
const BASE_WALL = [
  { col: BASE_COL - 1, row: BASE_ROW },
  { col: BASE_COL + 1, row: BASE_ROW },
  { col: BASE_COL - 1, row: BASE_ROW - 1 },
  { col: BASE_COL, row: BASE_ROW - 1 },
  { col: BASE_COL + 1, row: BASE_ROW - 1 },
  { col: BASE_COL - 1, row: BASE_ROW - 2 },
  { col: BASE_COL, row: BASE_ROW - 2 },
  { col: BASE_COL + 1, row: BASE_ROW - 2 },
]
const HARD_BRICK_HP = 3

/* ============================ 小工具 ============================ */

function clamp(v, lo, hi) {
  return v < lo ? lo : v > hi ? hi : v
}

function rand(min, max) {
  return min + Math.random() * (max - min)
}

function choice(list) {
  return list[Math.floor(Math.random() * list.length)]
}

function rectsOverlap(a, b) {
  return a.x < b.x + b.w && a.x + a.w > b.x && a.y < b.y + b.h && a.y + a.h > b.y
}

function centerOf(entity) {
  return { x: entity.x + entity.size / 2, y: entity.y + entity.size / 2 }
}

/* ============================ 地图生成 ============================ */

// 地图生成："走廊 + 街区"结构。
// 偶数行/偶数列恒为空 → 整张地图的走廊网格天然全连通，出怪点/基地/玩家出生点都落在网格上。
// 只在奇数行+奇数列的交叉块里铺砖/钢/水/草，再随机长出少量 1x2 砖块（每次放置后做连通性验证，断了就回滚）。
function buildMap(level) {
  const tiles = new Array(COLS * ROWS).fill(T.EMPTY)
  const set = function (col, row, v) {
    if (col < 0 || row < 0 || col >= COLS || row >= ROWS) return
    tiles[row * COLS + col] = v
  }

  // 1. 街区内容：奇数行 x 奇数列
  const brickRate = 0.46 + Math.min(level, 8) * 0.02
  const steelRate = 0.1 + Math.min(level, 8) * 0.012
  const waterRate = level >= 2 ? 0.07 : 0
  const grassRate = 0.12

  for (let row = 1; row < ROWS - 1; row += 2) {
    for (let col = 1; col < COLS - 1; col += 2) {
      const r = Math.random()
      let v = T.EMPTY
      if (r < brickRate) v = T.BRICK
      else if (r < brickRate + steelRate) v = T.STEEL
      else if (r < brickRate + steelRate + waterRate) v = T.WATER
      else if (r < brickRate + steelRate + waterRate + grassRate) v = T.GRASS
      set(col, row, v)
    }
  }

  // 2. 基地 + 加固砖护圈
  set(BASE_COL, BASE_ROW, T.BASE)
  for (let i = 0; i < BASE_WALL.length; i += 1) {
    set(BASE_WALL[i].col, BASE_WALL[i].row, T.HARD)
  }

  // 3. 少量延伸砖块，让地图看起来不那么规整（带连通性回滚）
  const keys = KEY_CELLS
  const attempts = 10 + Math.min(level, 6) * 2
  for (let i = 0; i < attempts; i += 1) {
    const col = Math.floor(rand(0, COLS))
    const row = Math.floor(rand(0, ROWS))
    if (tiles[row * COLS + col] !== T.EMPTY) continue
    if (col % 2 === 0 && row % 2 === 0) continue // 保护走廊十字口
    let protectedCell = false
    for (let k = 0; k < keys.length; k += 1) {
      if (keys[k].col === col && keys[k].row === row) protectedCell = true
    }
    if (protectedCell) continue
    const prev = tiles[row * COLS + col]
    set(col, row, T.BRICK)
    if (!mapConnected(tiles)) set(col, row, prev)
  }

  // 4. 兜底：万一仍然不通（理论上不会发生），退回纯走廊地图
  if (!mapConnected(tiles)) {
    for (let row = 1; row < ROWS - 1; row += 2) {
      for (let col = 1; col < COLS - 1; col += 2) {
        if (tiles[row * COLS + col] === T.STEEL) tiles[row * COLS + col] = T.BRICK
      }
    }
  }

  return tiles
}

// 必须保持可达的关键格子：三个出怪点、基地正上方、玩家出生点周围
const KEY_CELLS = [
  { col: 0, row: 0 },
  { col: 6, row: 0 },
  { col: COLS - 1, row: 0 },
  { col: 6, row: ROWS - 5 },
  { col: 4, row: ROWS - 1 },
  { col: 8, row: ROWS - 1 },
]

// 从玩家出生点 BFS，验证所有关键格子可达
function mapConnected(tiles) {
  const start = PLAYER_SPAWN.row * COLS + PLAYER_SPAWN.col
  if (blocksTank(tiles[start])) return false
  const seen = new Uint8Array(COLS * ROWS)
  const queue = [start]
  seen[start] = 1
  let head = 0
  while (head < queue.length) {
    const cur = queue[head]
    head += 1
    const col = cur % COLS
    const row = Math.floor(cur / COLS)
    const nb = [
      [col + 1, row],
      [col - 1, row],
      [col, row + 1],
      [col, row - 1],
    ]
    for (let i = 0; i < nb.length; i += 1) {
      const nc = nb[i][0]
      const nr = nb[i][1]
      if (nc < 0 || nr < 0 || nc >= COLS || nr >= ROWS) continue
      const id = nr * COLS + nc
      if (seen[id]) continue
      if (blocksTank(tiles[id])) continue
      seen[id] = 1
      queue.push(id)
    }
  }
  for (let i = 0; i < KEY_CELLS.length; i += 1) {
    const k = KEY_CELLS[i]
    if (!seen[k.row * COLS + k.col]) return false
  }
  return true
}

// 坦克可通行？砖/钢/水/基地都挡（草不挡）
function blocksTank(tile) {
  return tile === T.BRICK || tile === T.STEEL || tile === T.WATER || tile === T.BASE || tile === T.BASE_DEAD || tile === T.HARD
}

// 子弹可通行？只有砖/钢/基地/加固砖挡（水、草可穿）
function blocksBullet(tile) {
  return tile === T.BRICK || tile === T.STEEL || tile === T.BASE || tile === T.HARD
}

// 矩形是否压住任何阻挡格
function hitsTiles(tiles, rect, pred) {
  const c0 = Math.floor(rect.x / TILE)
  const c1 = Math.floor((rect.x + rect.w - 0.001) / TILE)
  const r0 = Math.floor(rect.y / TILE)
  const r1 = Math.floor((rect.y + rect.h - 0.001) / TILE)
  for (let row = r0; row <= r1; row += 1) {
    for (let col = c0; col <= c1; col += 1) {
      if (col < 0 || row < 0 || col >= COLS || row >= ROWS) return true // 出界当墙
      if (pred(tiles[row * COLS + col])) return true
    }
  }
  return false
}

/* ============================ 引擎 ============================ */

const PLAYER_TOTAL_LIVES = 3
const ENEMIES_PER_LEVEL = 10
const MAX_ENEMIES_ALIVE = 3

// 难度曲线：前期轻松熟悉，后期压力明显
function levelProfile(level) {
  const lv = Math.max(1, level)
  return {
    // 同时在场上限：1-2 关 3 辆，3-5 关 4 辆，6 关起 5 辆
    maxAlive: lv <= 2 ? 3 : lv <= 5 ? 4 : 5,
    // 每关总数缓增
    total: ENEMIES_PER_LEVEL + Math.floor((lv - 1) / 3),
    // 出怪间隔：越后期越快
    spawnGap: [Math.max(0.7, 1.5 - lv * 0.05), Math.max(1.3, 2.6 - lv * 0.07)],
    // 敌人子弹速度加成 / 开火频率加成
    bulletSpeedBonus: Math.min(lv, 12) * 10,
    fireRateScale: Math.max(0.55, 1 - (lv - 1) * 0.035),
  }
}

function createEngine() {
  const engine = {
    tiles: buildMap(1),
    player: null,
    enemies: [],
    bullets: [],
    effects: [],
    powerups: [],
    level: 1,
    profile: levelProfile(1),
    score: 0,
    lives: PLAYER_TOTAL_LIVES,
    enemiesLeft: ENEMIES_PER_LEVEL,
    spawnTimer: 0,
    spawnCursor: 0,
    status: 'ready', // ready | playing | paused | over | cleared | win
    message: '',
    shake: 0,
    hardHp: {},
  }

  engine.player = makePlayer(engine)

  /* ---------- 初始化 ---------- */

  engine.startLevel = function (level) {
    engine.level = level
    engine.profile = levelProfile(level)
    engine.tiles = buildMap(level)
    engine.hardHp = {}
    engine.bullets = []
    engine.effects = []
    engine.powerups = []
    engine.enemies = []
    engine.enemiesLeft = engine.profile.total
    engine.spawnTimer = 0.4
    engine.spawnCursor = 0
    engine.player = makePlayer(engine)
    engine.status = 'playing'
    engine.message = ''
  }

  engine.restart = function () {
    engine.score = 0
    engine.lives = PLAYER_TOTAL_LIVES
    engine.startLevel(1)
  }

  /* ---------- 生成对象 ---------- */

  engine.spawnEnemy = function () {
    const spawn = ENEMY_SPAWNS[engine.spawnCursor % ENEMY_SPAWNS.length]
    engine.spawnCursor += 1
    const size = TANK_SIZE
    const x = spawn.col * TILE + (TILE - size) / 2
    const y = spawn.row * TILE + (TILE - size) / 2
    const box = { x: x, y: y, w: size, h: size }
    if (hitsTiles(engine.tiles, box, blocksTank)) return false
    for (let i = 0; i < engine.enemies.length; i += 1) {
      const e = engine.enemies[i]
      if (rectsOverlap(box, { x: e.x, y: e.y, w: e.size, h: e.size })) return false
    }
    if (rectsOverlap(box, { x: engine.player.x, y: engine.player.y, w: engine.player.size, h: engine.player.size })) {
      return false
    }

    const level = engine.level
    const roll = Math.random()
    let kind = 'normal'
    // 关卡越高，特殊车型出现越多
    const fastFrom = Math.max(0.66, 0.9 - level * 0.01)
    const powerFrom = Math.max(0.5, 0.78 - level * 0.012)
    const armorFrom = Math.max(0.42, 0.7 - level * 0.014)
    if (roll > fastFrom) kind = 'fast'
    else if (roll > powerFrom) kind = 'power'
    else if (roll > armorFrom) kind = 'armor'

    const profile = {
      normal: { speed: 46, hp: 1, cooldown: 1.5, points: 100, color: '#c9d4e0' },
      fast: { speed: 82, hp: 1, cooldown: 1.6, points: 150, color: '#8ee6a0' },
      power: { speed: 42, hp: 1, cooldown: 0.85, points: 200, color: '#ffd166' },
      armor: { speed: 36, hp: 3, cooldown: 1.4, points: 300, color: '#f4978e' },
    }[kind]

    engine.enemies.push({
      id: 'e' + Math.random().toString(36).slice(2, 9),
      side: 'enemy',
      kind: kind,
      x: x,
      y: y,
      size: size,
      dir: 'down',
      speed: profile.speed + Math.min(level, 8) * 3,
      hp: profile.hp,
      maxHp: profile.hp,
      cooldown: rand(0.3, 1.2),
      fireRate: profile.cooldown * (engine.profile ? engine.profile.fireRateScale : 1),
      points: profile.points,
      color: profile.color,
      thinkTimer: 0,
      moving: true,
      bornTimer: 0.5,
    })
    return true
  }

  engine.fire = function (tank, fromPlayer) {
    const vec = DIR_VEC[tank.dir]
    const c = centerOf(tank)
    const bullet = {
      x: c.x - 3 + vec.x * (tank.size / 2),
      y: c.y - 3 + vec.y * (tank.size / 2),
      w: 6,
      h: 6,
      dir: tank.dir,
      speed: fromPlayer ? 320 : 200 + (engine.profile ? engine.profile.bulletSpeedBonus : 0),
      side: fromPlayer ? 'player' : 'enemy',
      dead: false,
    }
    engine.bullets.push(bullet)
  }

  /* ---------- 移动 ---------- */

  function moveTank(engine, tank, nx, ny) {
    const size = tank.size
    const box = { x: nx, y: ny, w: size, h: size }
    if (nx < 0 || ny < 0 || nx + size > W || ny + size > H) return false
    if (hitsTiles(engine.tiles, box, blocksTank)) return false

    const others = engine.enemies.concat([engine.player])
    for (let i = 0; i < others.length; i += 1) {
      const o = others[i]
      if (!o || o === tank) continue
      if (rectsOverlap(box, { x: o.x, y: o.y, w: o.size, h: o.size })) return false
    }
    tank.x = nx
    tank.y = ny
    return true
  }

  // 沿指定方向尝试移动，被挡住时对齐网格（帮助 AI 和玩家拐弯）
  function stepTank(engine, tank, dir, dt) {
    tank.dir = dir
    const vec = DIR_VEC[dir]
    const dist = tank.speed * dt
    let moved = false
    const tries = [1, 0.5, 0.25]
    for (let i = 0; i < tries.length; i += 1) {
      const d = dist * tries[i]
      if (moveTank(engine, tank, tank.x + vec.x * d, tank.y + vec.y * d)) {
        moved = true
        break
      }
    }
    return moved
  }

  // 轻微吸附到格线，让坦克能顺利进窄道（吸附后仍不能插进墙里）
  function snapTank(tank, axis) {
    const ox = tank.x
    const oy = tank.y
    if (axis === 'x') {
      const target = Math.round(tank.x / TILE) * TILE + (TILE - tank.size) / 2
      tank.x += clamp(target - tank.x, -6, 6)
      const box = { x: tank.x, y: tank.y, w: tank.size, h: tank.size }
      if (tank.x < 0 || tank.x + tank.size > W || hitsTiles(engine.tiles, box, blocksTank)) {
        tank.x = ox
        tank.y = oy
      }
    } else {
      const target = Math.round(tank.y / TILE) * TILE + (TILE - tank.size) / 2
      tank.y += clamp(target - tank.y, -6, 6)
      const box = { x: tank.x, y: tank.y, w: tank.size, h: tank.size }
      if (tank.y < 0 || tank.y + tank.size > H || hitsTiles(engine.tiles, box, blocksTank)) {
        tank.x = ox
        tank.y = oy
      }
    }
  }

  /* ---------- 玩家 ---------- */

  function makePlayer(engine) {
    const size = TANK_SIZE
    return {
      side: 'player',
      x: PLAYER_SPAWN.col * TILE + (TILE - size) / 2,
      y: PLAYER_SPAWN.row * TILE + (TILE - size) / 2,
      size: size,
      dir: 'up',
      speed: 104,
      cooldown: 0,
      fireRate: 0.32,
      maxBullets: 1,
      shield: 0,
      invincible: 2.5,
      alive: true,
    }
  }

  engine.updatePlayer = function (input, dt) {
    const p = engine.player
    if (!p || !p.alive) return
    if (p.cooldown > 0) p.cooldown = Math.max(0, p.cooldown - dt)
    if (p.invincible > 0) p.invincible = Math.max(0, p.invincible - dt)

    if (input.pausePressed) return

    let dir = null
    if (input.up) dir = 'up'
    else if (input.down) dir = 'down'
    else if (input.left) dir = 'left'
    else if (input.right) dir = 'right'

    if (dir) {
      const moved = stepTank(engine, p, dir, dt)
      if (!moved) {
        if (dir === 'up' || dir === 'down') snapTank(p, 'x')
        else snapTank(p, 'y')
        stepTank(engine, p, dir, dt)
      }
    }

    if (input.fire && p.cooldown <= 0) {
      const mine = engine.bullets.filter(function (b) {
        return b.side === 'player' && !b.dead
      }).length
      if (mine < p.maxBullets) {
        engine.fire(p, true)
        p.cooldown = p.fireRate
      }
    }
  }

  /* ---------- 敌方 AI ---------- */

  engine.updateEnemies = function (dt) {
    for (let i = 0; i < engine.enemies.length; i += 1) {
      const e = engine.enemies[i]
      if (e.bornTimer > 0) {
        e.bornTimer = Math.max(0, e.bornTimer - dt)
        continue
      }
      e.cooldown = Math.max(0, e.cooldown - dt)
      e.thinkTimer -= dt

      // 定时换向：偏向基地/玩家方向，制造压迫感
      if (e.thinkTimer <= 0) {
        e.thinkTimer = rand(0.5, 1.4)
        const target = engine.player && engine.player.alive ? engine.player : { x: BASE_COL * TILE, y: BASE_ROW * TILE }
        const dx = target.x - e.x
        const dy = target.y - e.y
        const prefer = []
        if (Math.abs(dx) > Math.abs(dy)) {
          prefer.push(dx > 0 ? 'right' : 'left', dy > 0 ? 'down' : 'up')
        } else {
          prefer.push(dy > 0 ? 'down' : 'up', dx > 0 ? 'right' : 'left')
        }
        const roll = Math.random()
        if (roll < 0.62) e.dir = prefer[0]
        else if (roll < 0.82) e.dir = prefer[1]
        else e.dir = choice(DIR_LIST)
      }

      // 撞墙则立刻换向，避免贴墙抖动
      const moved = stepTank(engine, e, e.dir, dt)
      if (!moved) {
        if (e.dir === 'up' || e.dir === 'down') snapTank(e, 'x')
        else snapTank(e, 'y')
        if (!stepTank(engine, e, e.dir, dt)) {
          e.dir = choice(DIR_LIST)
          e.thinkTimer = rand(0.2, 0.6)
        }
      }

      // 开火：正对玩家/基地、或随机触发
      if (e.cooldown <= 0) {
        const vec = DIR_VEC[e.dir]
        const c = centerOf(e)
        let aim = false
        const targets = []
        if (engine.player && engine.player.alive) targets.push(centerOf(engine.player))
        targets.push({ x: BASE_COL * TILE + TILE / 2, y: BASE_ROW * TILE + TILE / 2 })
        for (let t = 0; t < targets.length; t += 1) {
          const tg = targets[t]
          const along = (tg.x - c.x) * vec.x + (tg.y - c.y) * vec.y
          const side = Math.abs((tg.x - c.x) * vec.y - (tg.y - c.y) * vec.x)
          if (along > 0 && side < TILE * 0.7) aim = true
        }
        if (aim || Math.random() < 0.28) {
          engine.fire(e, false)
          e.cooldown = e.fireRate * rand(0.8, 1.3)
        }
      }
    }
  }

  /* ---------- 子弹 ---------- */

  engine.updateBullets = function (dt) {
    for (let i = 0; i < engine.bullets.length; i += 1) {
      const b = engine.bullets[i]
      if (b.dead) continue
      const vec = DIR_VEC[b.dir]
      const dist = b.speed * dt
      const steps = Math.max(1, Math.ceil(dist / 6))
      const per = dist / steps

      for (let s = 0; s < steps && !b.dead; s += 1) {
        b.x += vec.x * per
        b.y += vec.y * per

        // 出界
        if (b.x < -b.w || b.y < -b.h || b.x > W || b.y > H) {
          b.dead = true
          engine.effects.push({ x: b.x, y: b.y, t: 0.18, type: 'spark' })
          break
        }

        // 撞地形
        const c0 = Math.floor(b.x / TILE)
        const c1 = Math.floor((b.x + b.w - 0.001) / TILE)
        const r0 = Math.floor(b.y / TILE)
        const r1 = Math.floor((b.y + b.h - 0.001) / TILE)
        let hitTerrain = false
        for (let row = r0; row <= r1 && !hitTerrain; row += 1) {
          for (let col = c0; col <= c1 && !hitTerrain; col += 1) {
            if (col < 0 || row < 0 || col >= COLS || row >= ROWS) continue
            const idx = row * COLS + col
            const tile = engine.tiles[idx]
            if (!blocksBullet(tile)) continue
            hitTerrain = true
            if (tile === T.BRICK) {
              engine.tiles[idx] = T.EMPTY
              // 顺带打掉旁边一格砖，手感更爽
              const neighbor = b.dir === 'up' || b.dir === 'down' ? { col: col + 1, row: row } : { col: col, row: row + 1 }
              if (neighbor.col >= 0 && neighbor.row >= 0 && neighbor.col < COLS && neighbor.row < ROWS) {
                const nIdx = neighbor.row * COLS + neighbor.col
                if (engine.tiles[nIdx] === T.BRICK) engine.tiles[nIdx] = T.EMPTY
              }
            } else if (tile === T.HARD) {
              // 加固砖：多次击中才碎，每击一次变暗
              const hp = (engine.hardHp[idx] || HARD_BRICK_HP) - 1
              if (hp <= 0) {
                engine.tiles[idx] = T.EMPTY
                delete engine.hardHp[idx]
              } else {
                engine.hardHp[idx] = hp
              }
            } else if (tile === T.BASE) {
              engine.tiles[idx] = T.BASE_DEAD
              engine.status = 'over'
              engine.message = '基地被摧毁'
              engine.shake = 0.6
            }
            engine.effects.push({ x: b.x, y: b.y, t: 0.2, type: 'spark' })
            b.dead = true
          }
        }
        if (b.dead) break

        // 撞子弹
        for (let j = 0; j < engine.bullets.length; j += 1) {
          const o = engine.bullets[j]
          if (o === b || o.dead || o.side === b.side) continue
          if (rectsOverlap({ x: b.x, y: b.y, w: b.w, h: b.h }, { x: o.x, y: o.y, w: o.w, h: o.h })) {
            b.dead = true
            o.dead = true
            engine.effects.push({ x: b.x, y: b.y, t: 0.2, type: 'spark' })
            break
          }
        }
        if (b.dead) break

        // 撞坦克
        const targets = []
        if (b.side === 'player') {
          for (let k = 0; k < engine.enemies.length; k += 1) targets.push(engine.enemies[k])
        } else if (engine.player && engine.player.alive) {
          targets.push(engine.player)
        }
        for (let k = 0; k < targets.length; k += 1) {
          const t = targets[k]
          if (rectsOverlap({ x: b.x, y: b.y, w: b.w, h: b.h }, { x: t.x, y: t.y, w: t.size, h: t.size })) {
            b.dead = true
            engine.effects.push({ x: b.x, y: b.y, t: 0.25, type: 'hit' })
            if (t.side === 'player') {
              if (t.invincible > 0) {
                // 无敌期：直接挡掉
              } else if (t.shield > 0) {
                t.shield -= 1
                t.invincible = 1.2
              } else {
                engine.playerHit()
              }
            } else {
              t.hp -= 1
              if (t.hp <= 0) {
                t.dead = true
                engine.score += t.points
                engine.effects.push({ x: t.x + t.size / 2, y: t.y + t.size / 2, t: 0.45, type: 'boom' })
                if (Math.random() < 0.18) engine.dropPowerup(t.x, t.y)
              }
            }
            break
          }
        }
      }
    }
    engine.bullets = engine.bullets.filter(function (b) {
      return !b.dead
    })
    engine.enemies = engine.enemies.filter(function (e) {
      return !e.dead
    })
  }

  engine.playerHit = function () {
    const p = engine.player
    p.alive = false
    engine.shake = 0.5
    engine.effects.push({ x: p.x + p.size / 2, y: p.y + p.size / 2, t: 0.5, type: 'boom' })
    engine.lives -= 1
    if (engine.lives <= 0) {
      engine.lives = 0
      engine.status = 'over'
      engine.message = '全部坦克被击毁'
      return
    }
    // 复活
    engine.respawnTimer = 1.1
  }

  engine.updateRespawn = function (dt) {
    if (engine.player && engine.player.alive) return
    if (engine.status !== 'playing') return
    engine.respawnTimer = (engine.respawnTimer || 0) - dt
    if (engine.respawnTimer > 0) return
    const fresh = makePlayer(engine)
    fresh.invincible = 2.2
    engine.player = fresh
  }

  /* ---------- 道具 ---------- */

  engine.dropPowerup = function (x, y) {
    const kind = choice(['shield', 'rapid', 'life', 'star'])
    engine.powerups.push({ x: x, y: y, kind: kind, t: 12 })
  }

  engine.updatePowerups = function (dt) {
    const p = engine.player
    for (let i = engine.powerups.length - 1; i >= 0; i -= 1) {
      const pw = engine.powerups[i]
      pw.t -= dt
      if (pw.t <= 0) {
        engine.powerups.splice(i, 1)
        continue
      }
      if (
        p &&
        p.alive &&
        rectsOverlap({ x: pw.x, y: pw.y, w: 22, h: 22 }, { x: p.x, y: p.y, w: p.size, h: p.size })
      ) {
        if (pw.kind === 'shield') p.shield = 3
        else if (pw.kind === 'rapid') {
          p.fireRate = Math.max(0.14, p.fireRate * 0.7)
          p.maxBullets = Math.min(3, p.maxBullets + 1)
        } else if (pw.kind === 'life') engine.lives += 1
        else if (pw.kind === 'star') engine.score += 200
        engine.score += 50
        engine.powerups.splice(i, 1)
        engine.effects.push({ x: pw.x + 11, y: pw.y + 11, t: 0.3, type: 'spark' })
      }
    }
  }

  /* ---------- 主循环 ---------- */

  engine.update = function (input, dt) {
    if (engine.shake > 0) engine.shake = Math.max(0, engine.shake - dt)
    for (let i = engine.effects.length - 1; i >= 0; i -= 1) {
      engine.effects[i].t -= dt
      if (engine.effects[i].t <= 0) engine.effects.splice(i, 1)
    }
    if (engine.status !== 'playing') return

    engine.updatePlayer(input, dt)
    engine.updateEnemies(dt)
    engine.updateBullets(dt)
    engine.updatePowerups(dt)
    engine.updateRespawn(dt)

    // 出怪
    const maxAlive = engine.profile ? engine.profile.maxAlive : MAX_ENEMIES_ALIVE
    if (engine.enemies.length < maxAlive && engine.enemiesLeft > 0) {
      engine.spawnTimer -= dt
      if (engine.spawnTimer <= 0) {
        if (engine.spawnEnemy()) {
          engine.enemiesLeft -= 1
          const gap = engine.profile ? engine.profile.spawnGap : [1.4, 2.6]
          engine.spawnTimer = rand(gap[0], gap[1])
        } else {
          engine.spawnTimer = 0.35
        }
      }
    }

    // 过关判定
    if (engine.enemiesLeft <= 0 && engine.enemies.length === 0 && engine.status === 'playing') {
      engine.status = 'cleared'
      engine.message = '第 ' + engine.level + ' 关通过'
      engine.score += engine.level * 200
    }
  }

  return engine
}

/* ============================ 渲染 ============================ */

function drawTile(ctx, tile, x, y, dmg) {
  if (tile === T.BRICK) {
    ctx.fillStyle = '#8d4a32'
    ctx.fillRect(x, y, TILE, TILE)
    ctx.fillStyle = '#b9694a'
    for (let r = 0; r < 4; r += 1) {
      for (let c = 0; c < 2; c += 1) {
        const ox = c * 16 + (r % 2 ? 8 : 0)
        ctx.fillRect(x + ox + 1, y + r * 8 + 1, 14, 6)
      }
    }
  } else if (tile === T.STEEL) {
    ctx.fillStyle = '#7f8c9b'
    ctx.fillRect(x, y, TILE, TILE)
    ctx.fillStyle = '#cfd8e3'
    ctx.fillRect(x + 3, y + 3, 11, 11)
    ctx.fillRect(x + 18, y + 18, 11, 11)
    ctx.fillStyle = '#5d6976'
    ctx.fillRect(x + 18, y + 3, 11, 11)
    ctx.fillRect(x + 3, y + 18, 11, 11)
  } else if (tile === T.WATER) {
    ctx.fillStyle = '#1c4f7a'
    ctx.fillRect(x, y, TILE, TILE)
    ctx.strokeStyle = 'rgba(120,200,255,0.55)'
    ctx.lineWidth = 2
    for (let i = 0; i < 3; i += 1) {
      ctx.beginPath()
      ctx.moveTo(x + 4, y + 7 + i * 9)
      ctx.quadraticCurveTo(x + 10, y + 2 + i * 9, x + 16, y + 7 + i * 9)
      ctx.quadraticCurveTo(x + 22, y + 12 + i * 9, x + 28, y + 7 + i * 9)
      ctx.stroke()
    }
  } else if (tile === T.GRASS) {
    ctx.fillStyle = '#1f5f36'
    ctx.fillRect(x, y, TILE, TILE)
    ctx.fillStyle = '#2e8b4d'
    for (let i = 0; i < 5; i += 1) {
      ctx.fillRect(x + 3 + i * 6, y + 6 + ((i * 7) % 18), 3, 9)
    }
  } else if (tile === T.HARD) {
    // 加固砖：金属包边 + 裂纹，dmg 越大越暗越多裂
    const d = typeof dmg === 'number' ? dmg : 0
    const shade = ['#9a7b4f', '#7c6340', '#5d4a30'][Math.min(d, 2)]
    ctx.fillStyle = shade
    ctx.fillRect(x, y, TILE, TILE)
    ctx.fillStyle = 'rgba(255,235,190,0.28)'
    ctx.fillRect(x + 2, y + 2, TILE - 4, 3)
    ctx.fillRect(x + 2, y + 2, 3, TILE - 4)
    ctx.fillStyle = 'rgba(0,0,0,0.28)'
    ctx.fillRect(x + 2, y + TILE - 5, TILE - 4, 3)
    ctx.fillRect(x + TILE - 5, y + 2, 3, TILE - 4)
    ctx.strokeStyle = 'rgba(30,20,10,0.65)'
    ctx.lineWidth = 1.5
    ctx.beginPath()
    ctx.moveTo(x + 8, y + 6)
    ctx.lineTo(x + 14, y + 15)
    ctx.lineTo(x + 10, y + 26)
    ctx.stroke()
    if (d >= 1) {
      ctx.beginPath()
      ctx.moveTo(x + 25, y + 5)
      ctx.lineTo(x + 19, y + 16)
      ctx.lineTo(x + 24, y + 27)
      ctx.stroke()
    }
    if (d >= 2) {
      ctx.beginPath()
      ctx.moveTo(x + 4, y + 16)
      ctx.lineTo(x + 16, y + 12)
      ctx.lineTo(x + 28, y + 18)
      ctx.stroke()
    }
  } else if (tile === T.BASE || tile === T.BASE_DEAD) {
    const dead = tile === T.BASE_DEAD
    ctx.fillStyle = dead ? '#4a3b3b' : '#f2c14e'
    ctx.fillRect(x + 2, y + 2, TILE - 4, TILE - 4)
    ctx.fillStyle = dead ? '#2a2222' : '#7a5a10'
    ctx.beginPath()
    ctx.moveTo(x + 16, y + 7)
    ctx.lineTo(x + 25, y + 24)
    ctx.lineTo(x + 7, y + 24)
    ctx.closePath()
    ctx.fill()
    if (!dead) {
      ctx.fillStyle = '#fff6d0'
      ctx.beginPath()
      ctx.arc(x + 16, y + 17, 3, 0, Math.PI * 2)
      ctx.fill()
    }
  }
}

function drawTank(ctx, tank, time) {
  const x = tank.x
  const y = tank.y
  const s = tank.size
  const cx = tank.x + s / 2
  const cy = tank.y + s / 2

  ctx.save()
  ctx.translate(cx, cy)
  ctx.rotate(DIR_ANGLE[tank.dir])
  ctx.translate(-cx, -cy)

  // 出生闪烁
  if (tank.bornTimer > 0) {
    ctx.globalAlpha = 0.4 + 0.6 * Math.abs(Math.sin(time * 12))
  }

  const base = tank.side === 'player' ? '#f6d365' : tank.color
  ctx.fillStyle = 'rgba(0,0,0,0.35)'
  ctx.fillRect(x + 2, y + 3, s, s)

  // 履带
  ctx.fillStyle = tank.side === 'player' ? '#8a6a1a' : '#4a5560'
  ctx.fillRect(x, y + 2, 5, s - 4)
  ctx.fillRect(x + s - 5, y + 2, 5, s - 4)
  // 车体
  ctx.fillStyle = base
  ctx.fillRect(x + 5, y + 5, s - 10, s - 10)
  // 炮塔
  ctx.fillStyle = tank.side === 'player' ? '#ffe9a8' : '#e9eef5'
  ctx.beginPath()
  ctx.arc(cx, cy, 5, 0, Math.PI * 2)
  ctx.fill()
  // 炮管
  ctx.fillStyle = tank.hp > 1 ? '#ffb4a2' : '#2b3138'
  ctx.fillRect(cx - 2, y - 3, 4, s / 2 + 3)

  // 装甲坦克耐久格
  if (tank.side === 'enemy' && tank.maxHp > 1) {
    ctx.fillStyle = 'rgba(0,0,0,0.5)'
    ctx.fillRect(x + 4, y + s - 6, s - 8, 3)
    ctx.fillStyle = '#7ee787'
    ctx.fillRect(x + 4, y + s - 6, ((s - 8) * tank.hp) / tank.maxHp, 3)
  }
  ctx.restore()

  // 无敌护盾
  if (tank.invincible > 0) {
    ctx.strokeStyle = 'rgba(120,220,255,' + (0.4 + 0.5 * Math.abs(Math.sin(time * 10))) + ')'
    ctx.lineWidth = 2
    ctx.strokeRect(x - 2, y - 2, s + 4, s + 4)
  }
}

function drawPowerup(ctx, pw, time) {
  const colors = { shield: '#68d8ff', rapid: '#ffb703', life: '#90e07a', star: '#ffd6ff' }
  const labels = { shield: '盾', rapid: '速', life: '命', star: '★' }
  const pulse = 1 + 0.08 * Math.sin(time * 6)
  ctx.save()
  ctx.translate(pw.x + 11, pw.y + 11)
  ctx.scale(pulse, pulse)
  ctx.fillStyle = colors[pw.kind]
  ctx.fillRect(-10, -10, 20, 20)
  ctx.fillStyle = '#1b1f24'
  ctx.font = 'bold 13px system-ui, sans-serif'
  ctx.textAlign = 'center'
  ctx.textBaseline = 'middle'
  ctx.fillText(labels[pw.kind], 0, 1)
  ctx.restore()
}

function renderGame(ctx, engine, time, opts) {
  const shakeX = engine.shake > 0 ? rand(-3, 3) * engine.shake : 0
  const shakeY = engine.shake > 0 ? rand(-3, 3) * engine.shake : 0

  ctx.save()
  ctx.clearRect(0, 0, W, H)
  ctx.translate(shakeX, shakeY)

  // 地面
  ctx.fillStyle = '#14181f'
  ctx.fillRect(0, 0, W, H)
  ctx.strokeStyle = 'rgba(255,255,255,0.035)'
  ctx.lineWidth = 1
  for (let i = 0; i <= COLS; i += 1) {
    ctx.beginPath()
    ctx.moveTo(i * TILE, 0)
    ctx.lineTo(i * TILE, H)
    ctx.stroke()
  }
  for (let i = 0; i <= ROWS; i += 1) {
    ctx.beginPath()
    ctx.moveTo(0, i * TILE)
    ctx.lineTo(W, i * TILE)
    ctx.stroke()
  }

  // 地形（草最后画，压住坦克）
  const grass = []
  for (let row = 0; row < ROWS; row += 1) {
    for (let col = 0; col < COLS; col += 1) {
      const tile = engine.tiles[row * COLS + col]
      if (tile === T.EMPTY) continue
      if (tile === T.GRASS) {
        grass.push({ tile: tile, x: col * TILE, y: row * TILE })
        continue
      }
      const dmg = tile === T.HARD ? HARD_BRICK_HP - ((engine.hardHp && engine.hardHp[row * COLS + col]) || HARD_BRICK_HP) : 0
      drawTile(ctx, tile, col * TILE, row * TILE, dmg)
    }
  }

  // 道具
  for (let i = 0; i < engine.powerups.length; i += 1) drawPowerup(ctx, engine.powerups[i], time)

  // 坦克
  for (let i = 0; i < engine.enemies.length; i += 1) drawTank(ctx, engine.enemies[i], time)
  if (engine.player && engine.player.alive) drawTank(ctx, engine.player, time)

  // 子弹
  for (let i = 0; i < engine.bullets.length; i += 1) {
    const b = engine.bullets[i]
    ctx.fillStyle = b.side === 'player' ? '#fff3b0' : '#ff8a80'
    ctx.fillRect(b.x, b.y, b.w, b.h)
    ctx.globalAlpha = 0.35
    ctx.fillRect(b.x - 2, b.y - 2, b.w + 4, b.h + 4)
    ctx.globalAlpha = 1
  }

  // 草覆盖
  for (let i = 0; i < grass.length; i += 1) {
    ctx.globalAlpha = 0.82
    drawTile(ctx, grass[i].tile, grass[i].x, grass[i].y)
    ctx.globalAlpha = 1
  }

  // 特效
  for (let i = 0; i < engine.effects.length; i += 1) {
    const fx = engine.effects[i]
    const k = clamp(fx.t / 0.45, 0, 1)
    if (fx.type === 'boom') {
      ctx.fillStyle = 'rgba(255,170,60,' + k + ')'
      ctx.beginPath()
      ctx.arc(fx.x, fx.y, 26 * (1.15 - k) + 4, 0, Math.PI * 2)
      ctx.fill()
      ctx.fillStyle = 'rgba(255,255,220,' + k * 0.9 + ')'
      ctx.beginPath()
      ctx.arc(fx.x, fx.y, 12 * (1.15 - k) + 2, 0, Math.PI * 2)
      ctx.fill()
    } else if (fx.type === 'hit') {
      ctx.strokeStyle = 'rgba(255,255,200,' + k + ')'
      ctx.lineWidth = 3
      ctx.beginPath()
      ctx.arc(fx.x, fx.y, 14 * (1.2 - k), 0, Math.PI * 2)
      ctx.stroke()
    } else {
      ctx.fillStyle = 'rgba(255,220,150,' + k + ')'
      ctx.fillRect(fx.x - 8 * (1.1 - k), fx.y - 1, 16 * (1.1 - k), 2)
      ctx.fillRect(fx.x - 1, fx.y - 8 * (1.1 - k), 2, 16 * (1.1 - k))
    }
  }

  // 状态遮罩
  if (opts && opts.overlay) {
    ctx.fillStyle = 'rgba(8,10,14,0.72)'
    ctx.fillRect(0, 0, W, H)
    ctx.fillStyle = '#ffffff'
    ctx.textAlign = 'center'
    ctx.textBaseline = 'middle'
    ctx.font = 'bold 26px system-ui, sans-serif'
    ctx.fillText(opts.overlay.title, W / 2, H / 2 - 34)
    if (opts.overlay.subtitle) {
      ctx.font = '14px system-ui, sans-serif'
      ctx.fillStyle = 'rgba(255,255,255,0.8)'
      ctx.fillText(opts.overlay.subtitle, W / 2, H / 2 + 2)
    }
    if (opts.overlay.hint) {
      ctx.font = '13px system-ui, sans-serif'
      ctx.fillStyle = 'rgba(255,220,120,0.95)'
      ctx.fillText(opts.overlay.hint, W / 2, H / 2 + 32)
    }
  }

  ctx.restore()
}

/* ============================ 音效 ============================ */

function createSfx() {
  let ctx = null
  let enabled = true
  return {
    setEnabled: function (v) {
      enabled = v
    },
    isEnabled: function () {
      return enabled
    },
    play: function (kind) {
      if (!enabled) return
      try {
        if (!ctx) {
          const AC = globalThis.AudioContext || globalThis.webkitAudioContext
          if (!AC) return
          ctx = new AC()
        }
        if (ctx.state === 'suspended') ctx.resume()
        const now = ctx.currentTime
        const osc = ctx.createOscillator()
        const gain = ctx.createGain()
        osc.connect(gain)
        gain.connect(ctx.destination)
        const cfg = {
          shoot: { type: 'square', from: 520, to: 180, dur: 0.07, vol: 0.05 },
          boom: { type: 'sawtooth', from: 180, to: 40, dur: 0.26, vol: 0.09 },
          hit: { type: 'triangle', from: 300, to: 120, dur: 0.1, vol: 0.05 },
          pickup: { type: 'sine', from: 620, to: 980, dur: 0.14, vol: 0.06 },
          level: { type: 'sine', from: 440, to: 880, dur: 0.3, vol: 0.07 },
        }[kind] || { type: 'sine', from: 400, to: 400, dur: 0.05, vol: 0.04 }
        osc.type = cfg.type
        osc.frequency.setValueAtTime(cfg.from, now)
        osc.frequency.exponentialRampToValueAtTime(Math.max(20, cfg.to), now + cfg.dur)
        gain.gain.setValueAtTime(cfg.vol, now)
        gain.gain.exponentialRampToValueAtTime(0.001, now + cfg.dur)
        osc.start(now)
        osc.stop(now + cfg.dur + 0.02)
      } catch (err) {
        // 音频不可用时静默失败，不影响游戏
      }
    },
  }
}

/* ============================ React 面板 ============================ */

const KEYS = {
  ArrowUp: 'up',
  ArrowDown: 'down',
  ArrowLeft: 'left',
  ArrowRight: 'right',
  w: 'up',
  s: 'down',
  a: 'left',
  d: 'right',
  W: 'up',
  S: 'down',
  A: 'left',
  D: 'right',
}

function TankBattle({ host }) {
  const canvasRef = React.useRef(null)
  const engineRef = React.useRef(null)
  const inputRef = React.useRef({ up: false, down: false, left: false, right: false, fire: false })
  const sfxRef = React.useRef(null)
  const rafRef = React.useRef(0)
  const [hud, setHud] = React.useState({ score: 0, lives: 3, level: 1, left: ENEMIES_PER_LEVEL, status: 'ready', message: '', levelTotal: ENEMIES_PER_LEVEL })
  const [sound, setSound] = React.useState(true)
  const [best, setBest] = React.useState(0)
  const [askNote, setAskNote] = React.useState('')
  const [askStatus, setAskStatus] = React.useState('')

  const hostRef = React.useRef(host)
  hostRef.current = host

  if (!engineRef.current) engineRef.current = createEngine()
  if (!sfxRef.current) sfxRef.current = createSfx()

  // 最高分：localStorage 容错读写
  React.useEffect(function () {
    try {
      const v = globalThis.localStorage && globalThis.localStorage.getItem('tank-battle-best')
      if (v) setBest(Number(v) || 0)
    } catch (err) {}
  }, [])

  const saveBest = function (score) {
    setBest(function (prev) {
      if (score <= prev) return prev
      try {
        globalThis.localStorage && globalThis.localStorage.setItem('tank-battle-best', String(score))
      } catch (err) {}
      return score
    })
  }

  const pushHud = function () {
    const e = engineRef.current
    const next = {
      score: e.score,
      lives: e.lives,
      level: e.level,
      left: e.enemiesLeft + e.enemies.length,
      status: e.status,
      message: e.message,
      levelTotal: e.profile ? e.profile.total : ENEMIES_PER_LEVEL,
    }
    // 值没变就不 setState，避免 8 次/秒的无谓重渲染
    setHud(function (prev) {
      if (
        prev.score === next.score &&
        prev.lives === next.lives &&
        prev.level === next.level &&
        prev.left === next.left &&
        prev.status === next.status &&
        prev.message === next.message &&
        prev.levelTotal === next.levelTotal
      ) {
        return prev
      }
      return next
    })
  }

  // 开始 / 重开
  const startGame = function () {
    engineRef.current.restart()
    pushHud()
  }

  const nextLevel = function () {
    const e = engineRef.current
    saveBest(e.score)
    e.startLevel(e.level + 1)
    pushHud()
  }

  // 事件追踪上一帧分数做音效
  const prevRef = React.useRef({ score: 0, lives: 3, status: 'ready', enemies: 0, powerups: 0 })

  React.useEffect(
    function () {
      const e = engineRef.current
      const canvas = canvasRef.current
      if (!canvas) return
      const dpr = Math.min(2, globalThis.devicePixelRatio || 1)
      canvas.width = W * dpr
      canvas.height = H * dpr
      const ctx = canvas.getContext('2d')
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0)

      let last = performance.now()
      let acc = 0
      let time = 0

      const loop = function (now) {
        const raw = (now - last) / 1000
        last = now
        const dt = Math.min(0.05, raw)
        time += dt

        const eng = engineRef.current
        const input = Object.assign({}, inputRef.current)
        if (eng.status === 'playing') {
          acc += dt
          // 固定步长积分，保证不同刷新率手感一致
          let guard = 0
          while (acc >= 0.0166 && guard < 5) {
            eng.update(input, 0.0166)
            acc -= 0.0166
            guard += 1
          }
        } else {
          // 暂停/结束时仍推进特效
          for (let i = eng.effects.length - 1; i >= 0; i -= 1) {
            eng.effects[i].t -= dt
            if (eng.effects[i].t <= 0) eng.effects.splice(i, 1)
          }
          if (eng.shake > 0) eng.shake = Math.max(0, eng.shake - dt)
          acc = 0
        }

        // 音效检测：击杀/得分、掉命、过关、拾取道具
        const prev = prevRef.current
        if (eng.lives < prev.lives) sfxRef.current.play('boom')
        else if (eng.powerups.length < prev.powerups) sfxRef.current.play('pickup')
        else if (eng.score > prev.score) sfxRef.current.play('hit')
        if (eng.status === 'cleared' && prev.status === 'playing') sfxRef.current.play('level')
        if (eng.status === 'over' && prev.status !== 'over') sfxRef.current.play('boom')
        prevRef.current = {
          score: eng.score,
          lives: eng.lives,
          status: eng.status,
          enemies: eng.enemies.length,
          powerups: eng.powerups.length,
        }

        const overlay = (function () {
          if (eng.status === 'ready') {
            return { title: '坦克大战', subtitle: '方向键 / WASD 移动，空格或 J 开火', hint: '按 Enter 或点「开始」' }
          }
          if (eng.status === 'paused') return { title: '已暂停', subtitle: '按 P 或 Esc 继续', hint: '' }
          if (eng.status === 'cleared') {
            return { title: '第 ' + eng.level + ' 关通过', subtitle: '得分 ' + eng.score, hint: '按 Enter 进入下一关' }
          }
          if (eng.status === 'over') {
            return { title: '游戏结束', subtitle: eng.message + ' · 得分 ' + eng.score, hint: '按 Enter 重新开始' }
          }
          return null
        })()

        renderGame(ctx, eng, time, { overlay: overlay })
        rafRef.current = requestAnimationFrame(loop)
      }
      rafRef.current = requestAnimationFrame(loop)
      return function () {
        cancelAnimationFrame(rafRef.current)
        // 切走面板时冻结战局，回来不会"凭空"被扣命
        const eng = engineRef.current
        if (eng && eng.status === 'playing') eng.status = 'paused'
      }
    },
    [],
  )

  // HUD 轮询（避免每帧 setState）
  React.useEffect(function () {
    const id = setInterval(function () {
      pushHud()
    }, 120)
    return function () {
      clearInterval(id)
    }
  }, [])

  // 键盘
  React.useEffect(
    function () {
      const onKeyDown = function (ev) {
        // 在输入框里打字时不接管按键
        const tag = ev.target && ev.target.tagName
        if (tag === 'INPUT' || tag === 'TEXTAREA') return
        const e = engineRef.current
        const key = ev.key
        if (KEYS[key]) {
          inputRef.current[KEYS[key]] = true
          ev.preventDefault()
          return
        }
        if (key === ' ' || key === 'j' || key === 'J') {
          if (e.status === 'playing') sfxRef.current.play('shoot')
          inputRef.current.fire = true
          ev.preventDefault()
          return
        }
        if (key === 'p' || key === 'P' || key === 'Escape') {
          ev.preventDefault()
          if (e.status === 'playing') {
            e.status = 'paused'
          } else if (e.status === 'paused') {
            e.status = 'playing'
          }
          pushHud()
          return
        }
        if (key === 'Enter') {
          ev.preventDefault()
          if (e.status === 'ready' || e.status === 'over') startGame()
          else if (e.status === 'cleared') nextLevel()
          else if (e.status === 'paused') {
            e.status = 'playing'
            pushHud()
          }
        }
      }
      const onKeyUp = function (ev) {
        const tag = ev.target && ev.target.tagName
        if (tag === 'INPUT' || tag === 'TEXTAREA') return
        const key = ev.key
        if (KEYS[key]) {
          inputRef.current[KEYS[key]] = false
          ev.preventDefault()
          return
        }
        if (key === ' ' || key === 'j' || key === 'J') {
          inputRef.current.fire = false
          ev.preventDefault()
        }
      }
      const onBlur = function () {
        inputRef.current = { up: false, down: false, left: false, right: false, fire: false }
      }
      globalThis.addEventListener('keydown', onKeyDown)
      globalThis.addEventListener('keyup', onKeyUp)
      globalThis.addEventListener('blur', onBlur)
      return function () {
        globalThis.removeEventListener('keydown', onKeyDown)
        globalThis.removeEventListener('keyup', onKeyUp)
        globalThis.removeEventListener('blur', onBlur)
      }
    },
    [],
  )

  // 结束/过关时写入最高分
  React.useEffect(
    function () {
      if (hud.status === 'over' || hud.status === 'cleared') saveBest(hud.score)
    },
    [hud.status],
  )

  const togglePause = function () {
    const e = engineRef.current
    if (e.status === 'playing') {
      e.status = 'paused'
    } else if (e.status === 'paused') {
      e.status = 'playing'
    }
    pushHud()
  }

  const toggleSound = function () {
    const next = !sound
    setSound(next)
    sfxRef.current.setEnabled(next)
  }

  const ask = async function () {
    const text = askNote.trim()
    if (!text) return
    const host = hostRef.current
    if (!host || !host.askAgent) {
      setAskStatus('当前环境不支持转交')
      return
    }
    setAskStatus('发送中…')
    const res = await host.askAgent(text)
    setAskStatus(res.ok ? '已交给 Agent，去对话区看回复' : res.message || res.reason || '发送失败')
    if (res.ok) setAskNote('')
  }

  // 触屏方向键
  const bindHold = function (dir) {
    return {
      onPointerDown: function (ev) {
        ev.preventDefault()
        inputRef.current[dir] = true
      },
      onPointerUp: function (ev) {
        ev.preventDefault()
        inputRef.current[dir] = false
      },
      onPointerLeave: function () {
        inputRef.current[dir] = false
      },
    }
  }

  const statusLabel = {
    ready: '待开始',
    playing: '战斗中',
    paused: '已暂停',
    cleared: '通关',
    over: '结束',
  }[hud.status] || ''

  return h(
    'div',
    { className: 'tb-root' },
    h(
      'div',
      { className: 'tb-head' },
      h('h2', { className: 'tb-title' }, '坦克大战'),
      h('span', { className: 'tb-status tb-status-' + hud.status }, statusLabel),
    ),

    h(
      'div',
      { className: 'tb-hud' },
      h('span', { className: 'tb-hud-item' }, h('b', null, String(hud.score)), ' 分'),
      h('span', { className: 'tb-hud-item' }, '第 ', h('b', null, String(hud.level)), ' 关'),
      h('span', { className: 'tb-hud-item' }, '剩余 ', h('b', null, String(Math.max(0, hud.left))), ' / ', String(hud.levelTotal || ENEMIES_PER_LEVEL)),
      h('span', { className: 'tb-hud-item' }, '命 ', h('b', null, String(Math.max(0, hud.lives)))),
      h('span', { className: 'tb-hud-item tb-hud-best' }, '最高 ', h('b', null, String(best))),
    ),

    h(
      'div',
      { className: 'tb-stage' },
      h('canvas', {
        ref: canvasRef,
        className: 'tb-canvas',
        width: W,
        height: H,
        style: { width: '100%', aspectRatio: String(COLS) + ' / ' + String(ROWS) },
      }),
    ),

    h(
      'div',
      { className: 'tb-actions' },
      h(
        'button',
        {
          type: 'button',
          className: 'tb-btn tb-btn-primary',
          onClick: function () {
            if (engineRef.current.status === 'cleared') nextLevel()
            else startGame()
          },
        },
        hud.status === 'ready' ? '开始' : hud.status === 'cleared' ? '下一关' : '重新开始',
      ),
      h(
        'button',
        {
          type: 'button',
          className: 'tb-btn',
          onClick: togglePause,
          disabled: hud.status !== 'playing' && hud.status !== 'paused',
        },
        hud.status === 'paused' ? '继续' : '暂停',
      ),
      h('button', { type: 'button', className: 'tb-btn', onClick: toggleSound }, sound ? '音效 开' : '音效 关'),
    ),

    // 触屏控制（窄屏可玩）
    h(
      'div',
      { className: 'tb-pad' },
      h('button', Object.assign({ type: 'button', className: 'tb-pad-btn tb-pad-up' }, bindHold('up')), '▲'),
      h('button', Object.assign({ type: 'button', className: 'tb-pad-btn tb-pad-left' }, bindHold('left')), '◀'),
      h(
        'button',
        Object.assign({ type: 'button', className: 'tb-pad-btn tb-pad-fire' }, {
          onPointerDown: function (ev) {
            ev.preventDefault()
            inputRef.current.fire = true
          },
          onPointerUp: function (ev) {
            ev.preventDefault()
            inputRef.current.fire = false
          },
          onPointerLeave: function () {
            inputRef.current.fire = false
          },
        }),
        '⦿',
      ),
      h('button', Object.assign({ type: 'button', className: 'tb-pad-btn tb-pad-right' }, bindHold('right')), '▶'),
      h('button', Object.assign({ type: 'button', className: 'tb-pad-btn tb-pad-down' }, bindHold('down')), '▼'),
    ),

    h(
      'p',
      { className: 'tb-tip' },
      '方向键 / WASD 移动 · 空格或 J 开火 · P 暂停 · Enter 开始/下一关。保住底部金色基地，打光本关全部敌方坦克即过关；金色砖是加固砖，要打 3 发才碎。',
    ),

    h(
      'div',
      { className: 'tb-ask' },
      h('input', {
        className: 'tb-input',
        value: askNote,
        placeholder: '例如：这关太难了，帮我分析一下地图和打法',
        onChange: function (ev) {
          setAskNote(ev.target.value)
        },
      }),
      h(
        'button',
        { type: 'button', className: 'tb-btn', disabled: !askNote.trim(), onClick: ask },
        '问 Agent',
      ),
    ),
    askStatus ? h('p', { className: 'tb-ask-status' }, askStatus) : null,
  )
}

globalThis.__THETHING_PANEL__.define({
  'tank-battle': function (host) {
    return function () {
      return h(TankBattle, { host: host })
    }
  },
})
