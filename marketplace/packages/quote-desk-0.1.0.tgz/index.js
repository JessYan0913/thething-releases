// 询价工作台面板 —— 无 import / 无 JSX，define 在顶层同步调用。
// 宿主注入 globalThis.__THETHING_PANEL__ = { React, ReactDOM, ui, define }
// 数据真实来源是插件目录 data/items.json + data/quotes.jsonl，
// 面板只通过 host.rpc 读写、host.watch 轮询，不自己存业务数据。

const { React } = globalThis.__THETHING_PANEL__
const h = React.createElement
const { useState, useEffect, useMemo, useRef, useCallback } = React

const PLATFORM_LABEL = { taobao: '淘宝', pdd: '拼多多', '1688': '1688', other: '其他' }
const PLATFORM_ORDER = ['taobao', 'pdd', '1688']
const BLOCK_LABEL = {
  login: '需要登录',
  captcha: '验证码 / 滑块',
  risk: '风控拦截',
  empty: '搜不到结果',
  timeout: '加载超时',
  other: '其他阻塞',
}

// 采购单价常在小数点后 3-4 位（0.0172 元/根），固定两位会把不同报价显示成同一个数
function decimalsFor(n) {
  const a = Math.abs(n)
  if (a >= 1) return 2
  if (a >= 0.1) return 3
  if (a >= 0.01) return 4
  if (a > 0) return 6
  return 2
}

function money(n) {
  if (n === null || n === undefined || !Number.isFinite(n)) return '—'
  return `¥${n.toFixed(decimalsFor(n))}`
}

function num(n) {
  if (n === null || n === undefined || !Number.isFinite(n)) return ''
  return n.toFixed(decimalsFor(n))
}

function pct(n) {
  if (n === null || n === undefined || !Number.isFinite(n)) return ''
  const s = n > 0 ? '+' : ''
  return `${s}${n.toFixed(1)}%`
}

function shortTime(iso) {
  if (!iso) return '—'
  const d = new Date(iso)
  if (Number.isNaN(d.getTime())) return iso
  const p = (x) => String(x).padStart(2, '0')
  return `${p(d.getMonth() + 1)}-${p(d.getDate())} ${p(d.getHours())}:${p(d.getMinutes())}`
}

function searchUrl(platform, kw) {
  const q = encodeURIComponent(kw || '')
  if (platform === 'taobao') return `https://s.taobao.com/search?q=${q}`
  if (platform === 'pdd') return `https://mobile.yangkeduo.com/search_result.html?search_key=${q}`
  if (platform === '1688') return `https://s.1688.com/selloffer/offer_search.htm?keywords=${q}`
  return ''
}

function itemKeyword(item) {
  return (item.keywords || '').trim() || [item.name, item.spec].filter(Boolean).join(' ')
}

function emptyItem() {
  return {
    id: `it-${Date.now().toString(36)}${Math.random().toString(36).slice(2, 5)}`,
    name: '',
    spec: '',
    qty: null,
    unit: '件',
    keywords: '',
    targetPrice: null,
    urls: { taobao: '', pdd: '', '1688': '' },
    platforms: ['taobao', 'pdd'],
    note: '',
    status: 'todo',
  }
}

const QUOTE_FIELDS_DOC = `字段契约（一行一条 JSON，追加即可，不要改已有行）：
{"kind":"quote","batchId":"<批次号>","itemId":"<商品 id>","itemName":"<商品名>","platform":"taobao|pdd|1688","shop":"<店铺名>","title":"<商品标题原文>","spec":"<规格>","quantityText":"<页面上写的规格数量，如 1000根/包>","priceText":"<页面上原样的价格文本>","unitPrice":<数字，这一份的实付价，元>,"packQty":<数字，一份里有多少个采购单位，如 1000根/包 填 1000；一份就是一件时填 1>,"packUnit":"<采购单位，如 根>,"moq":<数字，起订量，没有就 null>,"moqText":"<起订量原文>","shipping":<数字，运费金额，包邮填 0，未知填 null>,"shippingText":"<运费原文>","sales":"<销量，如 月销 3000+>","url":"<商品详情页 URL>","note":"<需要人看的情况，如 价格区间、阶梯价>","capturedAt":"<ISO 时间>"}
遇到登录墙 / 验证码 / 风控拦截时，不要硬闯，改追加一条阻塞记录：
{"kind":"block","batchId":"<批次号>","platform":"taobao","reason":"login|captcha|risk|empty|timeout|other","url":"<触发页面 URL>","message":"<页面上看到的情况一句话>","itemId":"<卡在哪条商品>","capturedAt":"<ISO 时间>"}`

// 拼任务单：把"要采什么、写到哪、写成什么样、卡住怎么办"一次性说清楚，
// 让 Agent 不需要追问就能直接开干。
function buildTaskSheet({ batchId, items, platforms, quotesPath, mode }) {
  const lines = []
  lines.push(`【询价任务单】批次 ${batchId}`)
  lines.push('')
  lines.push(
    mode === 'resume'
      ? '接着上批未完成的部分继续询价，用内建浏览器（browser_* 工具）逐个采集，不要问我要不要开始，直接做。'
      : '用内建浏览器（browser_* 工具）逐个采集下列商品的真实报价，不要问我要不要开始，直接做。',
  )
  lines.push('')
  lines.push('## 写入方式')
  lines.push(`每采集到一条，立刻用 bash 追加到文件（不要攒到最后一次性写）：`)
  lines.push(`  echo '<一行JSON>' >> "${quotesPath}"`)
  lines.push('单引号里的 JSON 必须是一整行、合法 JSON；商品名等字段里的单引号请用 JSON 转义或改成全角。')
  lines.push('')
  lines.push(QUOTE_FIELDS_DOC)
  lines.push('')
  lines.push('## 采集要求')
  lines.push('- 每个商品在每个平台看前 3-5 个结果，挑销量/价格有代表性的 2-3 条，不要只抄第一条。')
  lines.push('- 只写页面上真实看到的东西；价格看不清、需要进详情页仍看不清的，unitPrice 填 null 并在 note 里说明。')
  lines.push('- 不要把"起售价"当成整件价格。页面按「1000根/包」「10个/件」卖时，unitPrice 记这一份的实付价，packQty 记一份里有多少个采购单位（1000根/包 → packQty:1000），否则没法换算比价。')
  lines.push('- 运费看详情页/下单页；只写"包邮"的记 shipping:0。')
  lines.push('- 淘系搜索页常要登录：遇到登录墙就写 block 记录（reason:"login"），然后停下来告诉我，我人工登录后你继续。')
  lines.push('- 拼多多/淘宝的验证码、滑块、访问过于频繁一律按 reason:"captcha" 或 "risk" 写 block 记录后停手，不要反复重试。')
  lines.push('')
  lines.push('## 本批商品')
  for (const item of items) {
    const plats = item.platforms && item.platforms.length ? item.platforms : platforms
    lines.push('')
    lines.push(`### ${item.name}${item.spec ? `（${item.spec}）` : ''}`)
    lines.push(`- itemId: ${item.id}`)
    if (item.qty) lines.push(`- 目标采购量: ${item.qty}${item.unit || '件'}`)
    if (item.targetPrice) lines.push(`- 目标价: ${money(item.targetPrice)}（超出这个价要在 note 里提示我）`)
    if (item.note) lines.push(`- 我的备注: ${item.note}`)
    const kw = itemKeyword(item)
    const wanted = plats.filter((p) => PLATFORM_ORDER.includes(p))
    lines.push(`- 搜索关键词: ${kw}`)
    for (const p of wanted) {
      const direct = item.urls && item.urls[p]
      const url = direct || searchUrl(p, kw)
      lines.push(`  - ${PLATFORM_LABEL[p] || p}: ${url}${direct ? '（我给的直达链接，优先用这个）' : ''}`)
    }
  }
  lines.push('')
  lines.push('## 收尾')
  lines.push('全部采完后回我一句汇总：每个商品采到几条、最低含运单价多少、有几条被登录墙/风控卡住。')
  lines.push('我这边面板会自动轮询文件实时长表，你不用管展示。')
  return lines.join('\n')
}

globalThis.__QDESK_BUILD_TASK__ = buildTaskSheet


// ---------- 小组件 ----------

function Badge({ children, tone }) {
  return h('span', { className: `qd-badge${tone ? ` qd-badge--${tone}` : ''}` }, children)
}

function Sparkline({ points, width = 84, height = 22 }) {
  if (!points || points.length < 2) return h('span', { className: 'qd-spark--flat' }, '—')
  const ps = points.map((p) => p.p)
  const min = Math.min(...ps)
  const max = Math.max(...ps)
  const span = max - min || 1
  const step = width / (points.length - 1)
  const coords = points.map((p, i) => [i * step, height - ((p.p - min) / span) * (height - 4) - 2])
  const d = coords.map(([x, y], i) => `${i === 0 ? 'M' : 'L'}${x.toFixed(1)},${y.toFixed(1)}`).join(' ')
  const last = coords[coords.length - 1]
  const first = ps[0]
  const rising = ps[ps.length - 1] > first
  return h(
    'svg',
    { className: 'qd-spark', width, height, viewBox: `0 0 ${width} ${height}` },
    h('path', { d, fill: 'none', stroke: rising ? '#d9534f' : '#2e9e6b', strokeWidth: 1.5 }),
    h('circle', { cx: last[0], cy: last[1], r: 1.8, fill: rising ? '#d9534f' : '#2e9e6b' }),
  )
}

function DeltaTag({ history }) {
  if (!history || history.delta === null || history.delta === undefined) {
    return h('span', { className: 'qd-delta qd-delta--none' }, history && history.count > 1 ? '持平/首采' : '首采')
  }
  const down = history.delta < 0
  return h(
    'span',
    { className: `qd-delta ${down ? 'qd-delta--down' : 'qd-delta--up'}`, title: `上次 ${money(history.prev)} → 本次 ${money(history.latest)}` },
    down ? '↓' : '↑',
    pct(history.deltaPct),
  )
}

function IconBtn({ onClick, title, children, danger }) {
  return h(
    'button',
    { type: 'button', className: `qd-iconbtn${danger ? ' qd-iconbtn--danger' : ''}`, onClick, title },
    children,
  )
}

// ---------- 清单编辑 ----------

function FieldInput({ value, onChange, placeholder, className, type }) {
  return h('input', {
    className: `qd-input${className ? ` ${className}` : ''}`,
    value: value === null || value === undefined ? '' : String(value),
    placeholder: placeholder || '',
    type: type || 'text',
    onChange: (e) => onChange(e.target.value),
  })
}

function PlatformToggles({ value, onChange }) {
  const active = Array.isArray(value) ? value : []
  return h(
    'span',
    { className: 'qd-plats' },
    PLATFORM_ORDER.map((p) => {
      const on = active.includes(p)
      return h(
        'button',
        {
          key: p,
          type: 'button',
          className: `qd-plat${on ? ' qd-plat--on' : ''}`,
          onClick: () => onChange(on ? active.filter((x) => x !== p) : [...active, p]),
        },
        PLATFORM_LABEL[p],
      )
    }),
  )
}

function ItemRow({ item, index, onChange, onRemove, onQuote, onClearQuotes, quoteCount }) {
  const set = (patch) => onChange({ ...item, ...patch })
  const setUrl = (p, v) => set({ urls: { ...(item.urls || {}), [p]: v } })
  const showUrls = (item.platforms || []).filter((p) => PLATFORM_ORDER.includes(p))
  return h(
    'div',
    { className: 'qd-item' },
    h(
      'div',
      { className: 'qd-item__main' },
      h('span', { className: 'qd-item__idx' }, String(index + 1)),
      h(FieldInput, {
        className: 'qd-item__name',
        value: item.name,
        placeholder: '商品名称（必填）',
        onChange: (v) => set({ name: v }),
      }),
      h(FieldInput, {
        className: 'qd-item__spec',
        value: item.spec,
        placeholder: '规格/型号',
        onChange: (v) => set({ spec: v }),
      }),
      h(
        'span',
        { className: 'qd-item__qty' },
        h(FieldInput, {
          value: item.qty,
          placeholder: '数量',
          onChange: (v) => set({ qty: v === '' ? null : Number(v.replace(/[^\d.]/g, '')) || null }),
        }),
        h(FieldInput, { value: item.unit, placeholder: '单位', onChange: (v) => set({ unit: v }) }),
      ),
      h(FieldInput, {
        className: 'qd-item__target',
        value: item.targetPrice,
        placeholder: '目标单价',
        onChange: (v) => set({ targetPrice: v === '' ? null : Number(v.replace(/[^\d.]/g, '')) || null }),
      }),
      h(PlatformToggles, { value: item.platforms, onChange: (v) => set({ platforms: v }) }),
      h(IconBtn, { title: '删除本条', danger: true, onClick: onRemove }, '✕'),
    ),
    h(
      'div',
      { className: 'qd-item__sub' },
      h(FieldInput, {
        className: 'qd-item__kw',
        value: item.keywords,
        placeholder: '搜索关键词（不填就用 名称+规格）',
        onChange: (v) => set({ keywords: v }),
      }),
      h(FieldInput, {
        className: 'qd-item__note',
        value: item.note,
        placeholder: '备注（如：必须白色、要开票、不要二手）',
        onChange: (v) => set({ note: v }),
      }),
    ),
    showUrls.length > 0 &&
      h(
        'div',
        { className: 'qd-item__urls' },
        showUrls.map((p) =>
          h(
            'span',
            { key: p, className: 'qd-item__url' },
            h('em', null, PLATFORM_LABEL[p]),
            h(FieldInput, {
              value: (item.urls || {})[p] || '',
              placeholder: '可选：直达商品/搜索链接',
              onChange: (v) => setUrl(p, v),
            }),
          ),
        ),
      ),
    h(
      'div',
      { className: 'qd-item__actions' },
      h(
        'button',
        { type: 'button', className: 'qd-btn qd-btn--ghost qd-btn--sm', onClick: onQuote },
        `询这一条${quoteCount ? `（已 ${quoteCount} 条）` : ''}`,
      ),
      quoteCount > 0 &&
        h(
          'button',
          { type: 'button', className: 'qd-btn qd-btn--ghost qd-btn--sm', onClick: onClearQuotes },
          '清空该条报价',
        ),
    ),
  )
}

// ---------- 报价对比表 ----------

function sortRows(rows, sortKey, sortDir) {
  const dir = sortDir === 'asc' ? 1 : -1
  const val = (r) => {
    if (sortKey === 'landed') return r.landedUnitPrice
    if (sortKey === 'unit') return r.unitPrice
    if (sortKey === 'moq') return r.moq
    if (sortKey === 'shipping') return r.shipping
    return r.capturedAt
  }
  return rows.slice().sort((a, b) => {
    const va = val(a)
    const vb = val(b)
    if (va === null || va === undefined) return 1
    if (vb === null || vb === undefined) return -1
    if (typeof va === 'number' && typeof vb === 'number') return (va - vb) * dir
    return String(va).localeCompare(String(vb)) * dir
  })
}

function QuoteRow({ row, item, isBest, history, onDelete }) {
  const overTarget = item && item.targetPrice && row.landedUnitPrice && row.landedUnitPrice > item.targetPrice
  const itemUnit = (item && item.unit) || '件'
  return h(
    'tr',
    { className: `qd-row${isBest ? ' qd-row--best' : ''}` },
    h(
      'td',
      { className: 'qd-cell-plat' },
      h('span', { className: `qd-chip qd-chip--${row.platform}` }, PLATFORM_LABEL[row.platform] || row.platform),
      isBest && h('span', { className: 'qd-chip qd-chip--best' }, '最低'),
    ),
    h(
      'td',
      { className: 'qd-cell-shop' },
      h('div', { className: 'qd-shop', title: row.shop }, row.shop || '—'),
      row.sales && h('div', { className: 'qd-sub' }, row.sales),
    ),
    h(
      'td',
      { className: 'qd-cell-title' },
      row.url
        ? h('a', { className: 'qd-link', href: row.url, target: '_blank', rel: 'noreferrer', title: row.title }, row.title || row.url)
        : h('span', { title: row.title }, row.title || '—'),
      (row.quantityText || row.spec) && h('div', { className: 'qd-sub' }, row.quantityText || row.spec),
      row.note && h('div', { className: 'qd-note' }, row.note),
    ),
    h(
      'td',
      { className: `qd-cell-price${overTarget ? ' qd-over' : ''}` },
      h('div', { className: 'qd-price' }, money(row.unitPrice)),
      row.packQty > 1 &&
        h(
          'div',
          { className: 'qd-sub', title: `1 份 = ${row.packQty}${row.packUnit || itemUnit}，已折算到采购单位` },
          `折算 ${money(row.unitPriceNormalized)}/${itemUnit}`,
        ),
      row.priceText && row.priceText !== money(row.unitPrice) && h('div', { className: 'qd-sub' }, row.priceText),
    ),
    h(
      'td',
      { className: 'qd-cell-num' },
      row.moq === null || row.moq === undefined ? h('span', { className: 'qd-sub' }, row.moqText || '—') : String(row.moq),
      row.moqText && row.moq !== null && row.moq !== undefined && h('div', { className: 'qd-sub' }, row.moqText),
    ),
    h(
      'td',
      { className: 'qd-cell-num' },
      row.shipping === null || row.shipping === undefined
        ? h('span', { className: 'qd-sub' }, row.shippingText || '—')
        : row.shipping === 0
          ? '包邮'
          : money(row.shipping),
    ),
    h(
      'td',
      { className: 'qd-cell-num qd-cell-landed' },
      h('strong', null, money(row.landedUnitPrice)),
      // 涨跌只标在该店铺最新一条上；历史行重复标同一个 delta 会让人误以为是每轮的变化
      history && history.latestId === row.id && h(DeltaTag, { history }),
    ),
    h(
      'td',
      { className: 'qd-cell-hist' },
      history && h(Sparkline, { points: history.points }),
      history && history.count > 1 && h('div', { className: 'qd-sub' }, `${history.count} 次 · ${money(history.low)}~${money(history.high)}`),
    ),
    h(
      'td',
      { className: 'qd-cell-time' },
      h('span', { className: 'qd-sub' }, shortTime(row.capturedAt)),
      h(IconBtn, { title: '删除这条报价', danger: true, onClick: () => onDelete(row.id) }, '✕'),
    ),
  )
}

function QuoteTable({ view, onDelete }) {
  const [sortKey, setSortKey] = useState('landed')
  const [sortDir, setSortDir] = useState('asc')
  const item = view.item
  const rows = view.rows || []
  const historyOf = (row) => view.history[`${row.platform}|${row.shop}|${row.url || row.title}`]
  const sorted = useMemo(() => sortRows(rows, sortKey, sortDir), [rows, sortKey, sortDir])
  const best = view.bestLandedUnitPrice

  const th = (key, label, cls) =>
    h(
      'th',
      {
        className: `qd-th${cls ? ` ${cls}` : ''}${sortKey === key ? ' qd-th--sorted' : ''}`,
        onClick: () => {
          if (sortKey === key) setSortDir(sortDir === 'asc' ? 'desc' : 'asc')
          else {
            setSortKey(key)
            setSortDir(key === 'capturedAt' ? 'desc' : 'asc')
          }
        },
        title: '点击排序',
      },
      label,
      sortKey === key ? (sortDir === 'asc' ? ' ↑' : ' ↓') : '',
    )

  if (!rows.length) return null

  return h(
    'div',
    { className: 'qd-tablewrap' },
    h(
      'table',
      { className: 'qd-table' },
      h(
        'thead',
        null,
        h(
          'tr',
          null,
          h('th', { className: 'qd-th' }, '平台'),
          h('th', { className: 'qd-th' }, '店铺'),
          h('th', { className: 'qd-th' }, '商品 / 规格'),
          th('unit', '单价', 'qd-th--num'),
          th('moq', '起订', 'qd-th--num'),
          th('shipping', '运费', 'qd-th--num'),
          th('landed', '含运单价', 'qd-th--num'),
          h('th', { className: 'qd-th' }, '价格走势'),
          th('capturedAt', '采集', 'qd-th--time'),
        ),
      ),
      h(
        'tbody',
        null,
        sorted.map((row) =>
          h(QuoteRow, {
            key: row.id,
            row,
            item,
            isBest: best !== null && row.landedUnitPrice !== null && Math.abs(row.landedUnitPrice - best) < 1e-9,
            history: historyOf(row),
            onDelete,
          }),
        ),
      ),
    ),
    item &&
      item.targetPrice &&
      h(
        'div',
        { className: 'qd-legend' },
        `目标价 ${money(item.targetPrice)} · 共 ${rows.length} 条报价 · 红色价格 = 高于目标价`,
      ),
  )
}

// ---------- 主面板 ----------

function BlockBar({ blocks, onResolve }) {
  if (!blocks || !blocks.length) return null
  return h(
    'div',
    { className: 'qd-blocks' },
    h('div', { className: 'qd-blocks__title' }, '⚠ 需要你人工处理（Agent 已停手）'),
    blocks.map((b) =>
      h(
        'div',
        { key: b.id, className: 'qd-block' },
        h('span', { className: `qd-chip qd-chip--${b.platform}` }, PLATFORM_LABEL[b.platform] || b.platform),
        h('span', { className: 'qd-block__reason' }, BLOCK_LABEL[b.reason] || b.reason || '阻塞'),
        h('span', { className: 'qd-block__msg', title: b.message }, b.message || ''),
        b.url &&
          h('a', { className: 'qd-link qd-block__url', href: b.url, target: '_blank', rel: 'noreferrer' }, '打开'),
        h(
          'button',
          { type: 'button', className: 'qd-btn qd-btn--ghost qd-btn--sm', onClick: () => onResolve(b.id) },
          '我已处理',
        ),
      ),
    ),
  )
}

function RunBar({ snapshot, platforms, setPlatforms, onStart, onResume, running, busy, lastFeed }) {
  const pending = (snapshot.items || []).map((v) => v.item).filter((it) => it.name && it.status !== 'done')
  const stats = snapshot.stats || {}
  return h(
    'div',
    { className: 'qd-runbar' },
    h(
      'div',
      { className: 'qd-runbar__left' },
      h('span', { className: 'qd-runbar__label' }, '默认平台'),
      h(PlatformToggles, { value: platforms, onChange: setPlatforms }),
      h('span', { className: 'qd-runbar__hint' }, `待询价 ${pending.length} 条 · 已采 ${stats.quoteCount || 0} 条`),
    ),
    h(
      'div',
      { className: 'qd-runbar__right' },
      h(
        'button',
        {
          type: 'button',
          className: 'qd-btn qd-btn--primary',
          disabled: busy || running || pending.length === 0,
          onClick: onStart,
          title: pending.length === 0 ? '清单里没有待询价商品' : '把本批任务单发给当前对话',
        },
        busy ? '发送中…' : running ? 'Agent 正在采集…' : `开始询价（${pending.length}）`,
      ),
      h(
        'button',
        { type: 'button', className: 'qd-btn qd-btn--ghost', disabled: busy || running, onClick: onResume },
        '催一下 / 继续',
      ),
    ),
    lastFeed && h('div', { className: 'qd-feed' }, lastFeed),
  )
}

function ItemSection({ view, onDeleteQuote, onClearQuotes, onQuoteOne }) {
  const [openHist, setOpenHist] = useState(false)
  const item = view.item
  const bestRow = view.rows.find(
    (r) => view.bestLandedUnitPrice !== null && r.landedUnitPrice !== null && Math.abs(r.landedUnitPrice - view.bestLandedUnitPrice) < 1e-9,
  )
  const histEntries = Object.entries(view.history || {})
  // 只要有一条链路被采过多次，就值得看历史（单店铺多轮询价同样有用）
  const hasHistory = histEntries.some(([, hist]) => hist && hist.count > 1)
  return h(
    'section',
    { className: 'qd-section' },
    h(
      'header',
      { className: 'qd-section__head' },
      h('h3', { className: 'qd-section__title' }, item.name || '(未命名商品)'),
      item.spec && h('span', { className: 'qd-section__spec' }, item.spec),
      item.qty && h('span', { className: 'qd-sub' }, `目标 ${item.qty}${item.unit || '件'}`),
      h(
        'span',
        { className: 'qd-section__spacer' },
      ),
      view.bestLandedUnitPrice !== null &&
        h(Badge, { tone: 'best' }, `最低含运 ${money(view.bestLandedUnitPrice)}${bestRow ? ` · ${bestRow.shop || PLATFORM_LABEL[bestRow.platform]}` : ''}`),
      h(Badge, null, `${view.quoteCount} 条`),
      view.lastCapturedAt && h('span', { className: 'qd-sub' }, `最后 ${shortTime(view.lastCapturedAt)}`),
      hasHistory &&
        h(
          'button',
          { type: 'button', className: 'qd-btn qd-btn--ghost qd-btn--sm', onClick: () => setOpenHist(!openHist) },
          openHist ? '收起历史' : `历史价格（${view.quoteCount} 次采集）`,
        ),
      h(
        'button',
        { type: 'button', className: 'qd-btn qd-btn--ghost qd-btn--sm', onClick: () => onQuoteOne(item) },
        '再询一次',
      ),
    ),
    openHist &&
      hasHistory &&
      h(
        'div',
        { className: 'qd-hist' },
        histEntries.map(([key, hist]) =>
          h(
            'div',
            { key, className: 'qd-hist__row' },
            h('span', { className: 'qd-hist__key', title: key }, key.split('|').slice(1).join(' / ') || key),
            h(Sparkline, { points: hist.points, width: 120, height: 26 }),
            h('span', { className: 'qd-hist__range' }, `${money(hist.low)} ~ ${money(hist.high)}`),
            h(DeltaTag, { history: hist }),
          ),
        ),
      ),
    h(QuoteTable, { view, onDelete: onDeleteQuote }),
    view.quoteCount > 0 &&
      h(
        'div',
        { className: 'qd-section__foot' },
        h(
          'button',
          { type: 'button', className: 'qd-btn qd-btn--ghost qd-btn--sm', onClick: () => onClearQuotes(item.id) },
          '清空该商品全部报价',
        ),
      ),
  )
}

// ---------- 主组件 ----------

function QuoteDesk({ host }) {
  const [snapshot, setSnapshot] = useState(null)
  const [error, setError] = useState(null)
  const [draft, setDraft] = useState(null) // 本地编辑中的清单（null = 跟随服务端）
  const [dirty, setDirty] = useState(false)
  const [platforms, setPlatforms] = useState(['taobao', 'pdd'])
  const [busy, setBusy] = useState(false)
  const [running, setRunning] = useState(false)
  const [feed, setFeed] = useState('')
  const [tab, setTab] = useState('list') // list | table
  const [showSettings, setShowSettings] = useState(false)
  const [quotesPath, setQuotesPath] = useState('')
  const lastCount = useRef(0)
  const runTimer = useRef(null)

  // 轮询快照：Agent 每写一行 quotes.jsonl，这里几秒内就能看到新行
  useEffect(() => {
    const handleWatch = host.watch(
      'snapshot',
      { maxQuotesPerItem: 80 },
      {
        intervalMs: 3000,
        onData: (snap) => {
          setSnapshot(snap)
          setError(null)
          if (snap.files && snap.files.quotes) setQuotesPath(snap.files.quotes)
          const total = (snap.stats && snap.stats.quoteCount) || 0
          if (total > lastCount.current && lastCount.current > 0) {
            setFeed(`+${total - lastCount.current} 条新报价 · ${new Date().toLocaleTimeString('zh-CN')}`)
          }
          lastCount.current = total
        },
        onError: (err) => setError(err instanceof Error ? err.message : String(err)),
      },
    )
    return () => handleWatch.cancel()
  }, [host])

  useEffect(() => {
    host.setTitle && host.setTitle('询价工作台')
  }, [host])

  const serverItems = useMemo(() => {
    if (!snapshot) return []
    return snapshot.items.map((v) => v.item)
  }, [snapshot])

  // 只在本地改过（dirty）时才用草稿；其余时刻跟随服务端，避免清单被盖住
  const items = dirty && draft !== null ? draft : serverItems

  const setItems = useCallback(
    (next) => {
      setDraft(next)
      setDirty(true)
      host.setDirty && host.setDirty(true)
    },
    [host],
  )

  const saveItems = useCallback(
    async (list) => {
      const target = list || items
      await host.rpc('saveItems', { items: target })
      setDirty(false)
      host.setDirty && host.setDirty(false)
      setDraft(null)
      // 存完立即拉一次，不用等下一轮轮询（3 秒的空白会让人以为没存上）
      try {
        const fresh = await host.rpc('snapshot', { maxQuotesPerItem: 80 })
        if (fresh) setSnapshot(fresh)
      } catch {}
    },
    [host, items],
  )

  const addItem = () => {
    setItems([...items, emptyItem()])
  }

  const removeItem = (idx) => {
    setItems(items.filter((_, i) => i !== idx))
  }

  const updateItem = (idx, next) => {
    setItems(items.map((it, i) => (i === idx ? next : it)))
  }

  // 发送任务单：把结构化任务写成一段可直接执行的中文指令，经 host.askAgent 递进当前对话
  const sendTask = useCallback(
    async (subset, mode) => {
      const list = (subset || items).filter((it) => it.name && it.name.trim())
      if (!list.length) {
        setFeed('清单里还没有填商品名称')
        return
      }
      setBusy(true)
      try {
        if (dirty) await saveItems(items)
        const batchId = `b${new Date().toISOString().slice(0, 10).replace(/-/g, '')}-${Date.now().toString(36).slice(-4)}`
        const text = buildTaskSheet({
          batchId,
          items: list,
          platforms,
          quotesPath: quotesPath || '(先点保存，让面板算出 quotes.jsonl 路径)',
          mode: mode || 'start',
        })
        const res = await host.askAgent(text)
        if (res && res.ok === false) {
          setFeed(`发送失败：${res.message || res.reason || '未知原因'}`)
        } else {
          setFeed(`任务单已递进对话（批次 ${batchId}，${list.length} 条商品）· 等待 Agent 采集`)
          setRunning(true)
          if (runTimer.current) clearTimeout(runTimer.current)
          runTimer.current = setTimeout(() => setRunning(false), 10 * 60 * 1000)
        }
      } catch (e) {
        setFeed(`发送异常：${e instanceof Error ? e.message : String(e)}`)
      } finally {
        setBusy(false)
      }
    },
    [items, platforms, quotesPath, dirty, saveItems],
  )

  const deleteQuote = useCallback(
    async (id) => {
      await host.rpc('deleteQuote', { id })
    },
    [host],
  )

  const clearQuotes = useCallback(
    async (itemId) => {
      await host.rpc('clearItemQuotes', { itemId })
    },
    [host],
  )

  const resolveBlock = useCallback(
    async (id) => {
      await host.rpc('resolveBlock', { id })
    },
    [host],
  )

  const downloadCsv = useCallback(async () => {
    try {
      const res = await host.rpc('exportCsv', {})
      const blob = new Blob([res.csv], { type: 'text/csv;charset=utf-8' })
      const url = URL.createObjectURL(blob)
      const a = document.createElement('a')
      a.href = url
      a.download = res.filename || 'quotes.csv'
      document.body.appendChild(a)
      a.click()
      document.body.removeChild(a)
      setTimeout(() => URL.revokeObjectURL(url), 2000)
      setFeed(`已导出 ${res.rowCount} 行到 ${res.filename}`)
    } catch (e) {
      setFeed(`导出失败：${e instanceof Error ? e.message : String(e)}`)
    }
  }, [host])

  const copyPath = useCallback(async () => {
    try {
      await navigator.clipboard.writeText(quotesPath)
      setFeed('quotes.jsonl 路径已复制')
    } catch {
      setFeed(quotesPath)
    }
  }, [quotesPath])

  const stats = (snapshot && snapshot.stats) || {}
  const blocks = (snapshot && snapshot.blocks) || []

  return h(
    'div',
    { className: 'qd-root' },
    h(
      'header',
      { className: 'qd-top' },
      h('h2', { className: 'qd-top__title' }, '询价工作台'),
      h(
        'div',
        { className: 'qd-top__stats' },
        h(Badge, null, `商品 ${stats.itemCount || 0}`),
        h(Badge, null, `报价 ${stats.quoteCount || 0}`),
        h(Badge, { tone: stats.quotesToday ? 'live' : undefined }, `今日 ${stats.quotesToday || 0}`),
        blocks.length > 0 && h(Badge, { tone: 'warn' }, `待处理 ${blocks.filter((b) => !b.resolvedAt).length}`),
      ),
      h('span', { className: 'qd-top__spacer' }),
      h(
        'button',
        { type: 'button', className: 'qd-btn qd-btn--ghost qd-btn--sm', onClick: () => setShowSettings(!showSettings) },
        '数据文件',
      ),
      h('button', { type: 'button', className: 'qd-btn qd-btn--ghost qd-btn--sm', onClick: downloadCsv }, '导出 CSV'),
      dirty &&
        h('button', { type: 'button', className: 'qd-btn qd-btn--primary qd-btn--sm', onClick: () => saveItems(items) }, '保存清单'),
    ),
    showSettings &&
      h(
        'div',
        { className: 'qd-settings' },
        h('div', null, h('em', null, '报价流水：'), h('code', null, quotesPath || '(未就绪)')),
        h('div', null, h('em', null, '清单文件：'), h('code', null, (snapshot && snapshot.files && snapshot.files.items) || '(未就绪)')),
        h('button', { type: 'button', className: 'qd-btn qd-btn--ghost qd-btn--sm', onClick: copyPath }, '复制流水路径'),
        h('div', { className: 'qd-settings__hint' }, 'Agent 每追加一行 JSON 到流水文件，面板 3 秒内自动长出新行；你也可以手工往里面写。'),
      ),
    error && h('p', { className: 'qd-error' }, `读取失败：${error}`),
    h(
      'div',
      { className: 'qd-tabs' },
      h(
        'button',
        { type: 'button', className: `qd-tab${tab === 'list' ? ' qd-tab--on' : ''}`, onClick: () => setTab('list') },
        `待询价清单（${items.length}）`,
      ),
      h(
        'button',
        { type: 'button', className: `qd-tab${tab === 'table' ? ' qd-tab--on' : ''}`, onClick: () => setTab('table') },
        `对比表（${(snapshot && snapshot.items && snapshot.items.length) || 0}）`,
      ),
    ),
    tab === 'list'
      ? h(
          'div',
          { className: 'qd-list' },
          h(RunBar, {
            snapshot: { items: items.map((it) => ({ item: it })), stats },
            platforms,
            setPlatforms,
            onStart: () => sendTask(null, 'start'),
            onResume: () => sendTask(null, 'resume'),
            running,
            busy,
            lastFeed: feed,
          }),
          h(BlockBar, { blocks: blocks.filter((b) => !b.resolvedAt), onResolve: resolveBlock }),
          items.map((item, i) =>
            h(ItemRow, {
              key: item.id || i,
              item,
              index: i,
              onChange: (next) => updateItem(i, next),
              onRemove: () => removeItem(i),
              onQuote: () => sendTask([item], 'start'),
              onClearQuotes: () => clearQuotes(item.id),
              quoteCount: ((snapshot && snapshot.items.find((v) => v.item.id === item.id)) || {}).quoteCount || 0,
            }),
          ),
          h(
            'div',
            { className: 'qd-list__foot' },
            h('button', { type: 'button', className: 'qd-btn qd-btn--ghost', onClick: addItem }, '+ 添加商品'),
            h(
              'button',
              { type: 'button', className: 'qd-btn qd-btn--primary', disabled: !dirty, onClick: () => saveItems(items) },
              dirty ? '保存清单' : '已保存',
            ),
          ),
        )
      : h(
          'div',
          { className: 'qd-tables' },
          h(BlockBar, { blocks: blocks.filter((b) => !b.resolvedAt), onResolve: resolveBlock }),
          feed && h('div', { className: 'qd-feed qd-feed--inline' }, feed),
          !snapshot &&
            h('p', { className: 'qd-empty' }, '正在读取…'),
          snapshot &&
            snapshot.items.filter((v) => v.quoteCount > 0).length === 0 &&
            snapshot.orphans.length === 0 &&
            h(
              'p',
              { className: 'qd-empty' },
              '还没有采集到报价。在「待询价清单」里填好商品后点「开始询价」，Agent 会把结果实时写进这里。',
            ),
          snapshot &&
            snapshot.items
              .filter((v) => v.quoteCount > 0)
              .map((view) =>
                h(ItemSection, {
                  key: view.item.id,
                  view,
                  onDeleteQuote: deleteQuote,
                  onClearQuotes: clearQuotes,
                  onQuoteOne: (item) => sendTask([item], 'start'),
                }),
              ),
          snapshot &&
            snapshot.orphans.map((o) =>
              h(
                'section',
                { key: o.itemId, className: 'qd-section qd-section--orphan' },
                h(
                  'header',
                  { className: 'qd-section__head' },
                  h('h3', { className: 'qd-section__title' }, o.itemName),
                  h(Badge, { tone: 'warn' }, '不在清单中'),
                  h(Badge, null, `${o.quoteCount} 条`),
                ),
                h(QuoteTable, {
                  view: { item: { name: o.itemName }, rows: o.rows, history: o.history, bestLandedUnitPrice: null, quoteCount: o.quoteCount },
                  onDelete: deleteQuote,
                }),
              ),
            ),
        ),
  )
}

// 自检钩子：仅供 test/render-check.mjs 直接用真实 React 渲染各子组件（宿主不会读取它）
globalThis.__QDESK_TEST__ = {
  buildTaskSheet,
  QuoteTable,
  ItemSection,
  BlockBar,
  QuoteDesk,
}

globalThis.__THETHING_PANEL__.define({
  'quote-desk': (host) => function QuoteDeskPanel() {
    return h(QuoteDesk, { host })
  },
})
