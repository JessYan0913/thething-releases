// 询价工作台 —— 面板侧 RPC（跑在 TheThing 的 node 服务端）
// 职责：读写 ~/.thething/plugin-data/quote-desk/ 下的 items.json 与 quotes.jsonl，
//      做字段规范化、聚合视图、CSV 导出。面板只拿现成的可渲染数据。
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { fileURLToPath } from "node:url";

const PLUGIN_ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), ".");

// 数据不能放插件目录里：插件重装/升级会整目录覆盖，清单和报价流水会一起没。
// 固定落到 ~/.thething/plugin-data/quote-desk，重装插件只换代码、不动数据。
function dataDir(ctx) {
  if (process.env.QUOTE_DESK_DIR) return process.env.QUOTE_DESK_DIR;
  try {
    return path.join(os.homedir(), ".thething", "plugin-data", "quote-desk");
  } catch {
    const base = ctx && ctx.dir ? ctx.dir : PLUGIN_ROOT;
    return path.join(base, "data");
  }
}

function paths(ctx) {
  const dir = dataDir(ctx);
  return {
    dir,
    items: path.join(dir, "items.json"),
    quotes: path.join(dir, "quotes.jsonl"),
    batches: path.join(dir, "batches.json"),
  };
}

function ensureDir(dir) {
  fs.mkdirSync(dir, { recursive: true });
}

function readJson(file, fallback) {
  try {
    if (!fs.existsSync(file)) return fallback;
    const text = fs.readFileSync(file, "utf-8").trim();
    if (!text) return fallback;
    return JSON.parse(text);
  } catch {
    return fallback;
  }
}

function writeJsonAtomic(file, value) {
  ensureDir(path.dirname(file));
  const tmp = `${file}.tmp-${process.pid}`;
  fs.writeFileSync(tmp, JSON.stringify(value, null, 2) + "\n", "utf-8");
  fs.renameSync(tmp, file);
}

function readJsonl(file) {
  if (!fs.existsSync(file)) return [];
  const out = [];
  const lines = fs.readFileSync(file, "utf-8").split("\n");
  let lineno = 0;
  for (const line of lines) {
    lineno += 1;
    if (!line.trim()) continue;
    try {
      const rec = JSON.parse(line);
      if (rec && typeof rec === "object") {
        rec.__line = lineno;
        out.push(rec);
      }
    } catch {
      // 坏行跳过（Agent 手写 JSONL 时可能写断半行）
    }
  }
  return out;
}

function appendJsonl(file, records) {
  ensureDir(path.dirname(file));
  const body = records.map((r) => JSON.stringify(r)).join("\n") + "\n";
  fs.appendFileSync(file, body, "utf-8");
}

// ---------- 规范化 ----------

const nowIso = () => new Date().toISOString();

function str(v, max = 500) {
  if (v === undefined || v === null) return "";
  const s = String(v).replace(/\s+/g, " ").trim();
  return s.length > max ? s.slice(0, max) : s;
}

// "¥1,234.50" / "12.5元" / "1.2-1.5元" / "12元/件" -> 12.5
function parseMoney(v) {
  if (typeof v === "number" && Number.isFinite(v)) return v;
  if (v === undefined || v === null) return null;
  const s = String(v).replace(/,/g, "");
  const m = s.match(/(\d+(?:\.\d+)?)/);
  if (!m) return null;
  const n = Number(m[1]);
  return Number.isFinite(n) ? n : null;
}

// 显式给了数字字段就用它（含显式 null = 未知价，绝不回退去猜 priceText）
// 只有字段完全缺失时才退到文本里解析，避免把「1?.?」等占位价当成真实单价
function pickMoney(src, keys, fallbackText) {
  for (const k of keys) {
    if (src[k] === undefined) continue;
    if (src[k] === null || src[k] === "") return null;
    return parseMoney(src[k]);
  }
  return parseMoney(fallbackText);
}

function parseIntSafe(v) {
  if (typeof v === "number" && Number.isFinite(v)) return Math.round(v);
  if (v === undefined || v === null) return null;
  const s = String(v).replace(/,/g, "");
  const m = s.match(/(\d+)/);
  if (!m) return null;
  const n = parseInt(m[1], 10);
  return Number.isFinite(n) ? n : null;
}

function normPlatform(v, url) {
  const s = str(v, 40).toLowerCase();
  if (/taobao|tb|淘宝|天猫|tmall/.test(s)) return "taobao";
  if (/pdd|pinduoduo|拼多多|多多/.test(s)) return "pdd";
  if (/1688|alibaba/.test(s)) return "1688";
  if (s) return s;
  const u = str(url, 400);
  if (/taobao\.com|tmall\.com/.test(u)) return "taobao";
  if (/yangkeduo\.com|pinduoduo\.com/.test(u)) return "pdd";
  if (/1688\.com/.test(u)) return "1688";
  return "other";
}

function newId(prefix) {
  return `${prefix}-${Date.now().toString(36)}${Math.random().toString(36).slice(2, 6)}`;
}

// 稳定签名：同一条流水每轮读出来必须得到同一个 id，否则面板上的删除/已处理会打空
function stableId(prefix, parts) {
  const raw = parts.filter((v) => v !== undefined && v !== null && v !== "").join("|");
  let h = 5381;
  for (let i = 0; i < raw.length; i += 1) h = ((h << 5) + h + raw.charCodeAt(i)) | 0;
  return `${prefix}-${(h >>> 0).toString(36)}`;
}

function normItem(raw, index = 0) {
  const src = raw && typeof raw === "object" ? raw : {};
  const urls = src.urls && typeof src.urls === "object" ? src.urls : {};
  const platformsRaw = Array.isArray(src.platforms) ? src.platforms : [];
  const platforms = platformsRaw
    .map((p) => normPlatform(p, ""))
    .filter((p, i, arr) => p && arr.indexOf(p) === i);
  return {
    id: str(src.id, 60) || newId(`it${index}`),
    name: str(src.name, 120),
    spec: str(src.spec, 160),
    qty: parseIntSafe(src.qty),
    unit: str(src.unit, 16) || "件",
    keywords: str(src.keywords, 200),
    targetPrice: parseMoney(src.targetPrice),
    urls: {
      taobao: str(urls.taobao, 400),
      pdd: str(urls.pdd, 400),
      "1688": str(urls["1688"], 400),
    },
    platforms: platforms.length ? platforms : ["taobao", "pdd"],
    note: str(src.note, 400),
    status: ["todo", "running", "done", "paused"].includes(src.status) ? src.status : "todo",
    createdAt: str(src.createdAt, 40) || nowIso(),
    updatedAt: str(src.updatedAt, 40) || nowIso(),
  };
}

function normQuote(raw) {
  const src = raw && typeof raw === "object" ? raw : {};
  const kind = src.kind === "block" ? "block" : src.kind === "note" ? "note" : "quote";
  const url = str(src.url, 500);
  const unitPrice = pickMoney(src, ["unitPrice", "price"], src.priceText);
  const shipping = pickMoney(src, ["shipping", "freight"], src.shippingText);
  return {
    kind,
    id:
      str(src.id, 60) ||
      stableId(kind === "block" ? "bk" : "q", [
        src.itemId,
        src.platform,
        src.shop,
        url || src.title,
        src.capturedAt,
        unitPrice,
        src.priceText,
        src.reason,
      ]),
    batchId: str(src.batchId, 60),
    itemId: str(src.itemId, 60),
    itemName: str(src.itemName, 120),
    platform: normPlatform(src.platform, url),
    shop: str(src.shop ?? src.seller, 120),
    title: str(src.title, 200),
    spec: str(src.spec, 160),
    quantityText: str(src.quantityText ?? src.spec, 120),
    unitPrice,
    priceText: str(src.priceText, 60) || (unitPrice != null ? `¥${unitPrice}` : ""),
    moq: parseIntSafe(src.moq ?? src.minOrder),
    moqText: str(src.moqText, 60),
    // 报价单位折算：报价是 ¥18.8/包 而目标是「根」时，必须记下包里有多少根，否则无法横向比价
    packQty: parseIntSafe(src.packQty ?? src.packageQty),
    packUnit: str(src.packUnit, 20),
    shipping,
    shippingText: str(src.shippingText, 60),
    url,
    sales: str(src.sales, 60),
    note: str(src.note ?? src.message, 400),
    // 阻塞记录额外暴露 message / resolvedAt，面板要用它提示“我能帮着人工处理”和已处理状态
    ...(kind === "block" ? { message: str(src.message ?? src.note, 400) } : {}),
    ...(src.resolvedAt ? { resolvedAt: str(src.resolvedAt, 40) } : {}),
    reason: kind === "block" ? str(src.reason, 40) || "other" : "",
    capturedAt: str(src.capturedAt, 40) || nowIso(),
    __line: typeof src.__line === "number" ? src.__line : undefined,
  };
}

// ---------- 派生 ----------

function quoteKey(q) {
  return `${q.platform}|${q.shop}|${q.url || q.title}`;
}

// 单价折算：报价常是「¥18.8/包」而采购单位是「根」，packQty 记录一包多少根。
// 换算成目标单位单价后再加分摊运费，才能跨店铺横向比价。
function unitPriceOf(q) {
  if (q.unitPrice == null) return null;
  if (q.packQty && q.packQty > 1) return q.unitPrice / q.packQty;
  return q.unitPrice;
}

// 含运单价：运费优先按目标采购量分摊，没有目标量就按起订量（折算成最小单位）分摊
function landedUnitPrice(q, qty) {
  const per = unitPriceOf(q);
  if (per == null) return null;
  if (q.shipping == null) return per;
  const pack = q.packQty && q.packQty > 0 ? q.packQty : 1;
  const base = qty && qty > 0 ? qty : q.moq && q.moq > 0 ? q.moq * pack : null;
  if (!base) return per;
  return per + q.shipping / base;
}

function buildHistory(quotes) {
  // 按 (平台|店铺|链接) 归并成时间序列，用于 "上次 12.5 → 现在 11.8 (-5.6%)" 和 sparkline
  const groups = new Map();
  const sorted = quotes.slice().sort((a, b) => String(a.capturedAt).localeCompare(String(b.capturedAt)));
  for (const q of sorted) {
    if (q.unitPrice == null) continue;
    const key = quoteKey(q);
    if (!groups.has(key)) groups.set(key, []);
    groups.get(key).push({ t: q.capturedAt, p: q.unitPrice, id: q.id });
  }
  const out = {};
  for (const [key, series] of groups) {
    if (!series.length) continue;
    const latest = series[series.length - 1];
    const prev = series.length > 1 ? series[series.length - 2] : null;
    out[key] = {
      points: series.slice(-30),
      latestId: latest.id,
      latest: latest.p,
      prev: prev ? prev.p : null,
      delta: prev ? latest.p - prev.p : null,
      deltaPct: prev && prev.p ? ((latest.p - prev.p) / prev.p) * 100 : null,
      low: Math.min(...series.map((s) => s.p)),
      high: Math.max(...series.map((s) => s.p)),
      count: series.length,
    };
  }
  return out;
}


// 磁盘行通常没有 id 字段（Agent 手写只带业务字段），
// 所以改写类操作一律用派生 id 比对，不能直接读 r.id。
function recordId(raw) {
  return normQuote(raw).id;
}

function rewriteQuotes(file, dir, transform) {
  const records = readJsonl(file);
  const next = [];
  let changed = 0;
  for (const rec of records) {
    const copy = { ...rec };
    delete copy.__line;
    const out = transform(copy, recordId(copy));
    if (out === null) {
      changed += 1;
      continue;
    }
    if (out !== copy) changed += 1;
    next.push(out);
  }
  if (changed) {
    ensureDir(dir);
    const tmp = `${file}.tmp-${process.pid}`;
    fs.writeFileSync(tmp, next.map((r) => JSON.stringify(r)).join("\n") + (next.length ? "\n" : ""), "utf-8");
    fs.renameSync(tmp, file);
  }
  return { changed, remaining: next.length };
}

function snapshot(params, ctx) {
  const p = paths(ctx);
  const itemsRaw = readJson(p.items, { items: [] });
  const items = (Array.isArray(itemsRaw.items) ? itemsRaw.items : []).map((it, i) => normItem(it, i));
  const maxPerItem = Number.isFinite(params?.maxQuotesPerItem)
    ? Math.max(1, Math.min(200, Math.floor(params.maxQuotesPerItem)))
    : 60;

  const records = readJsonl(p.quotes).map(normQuote);
  const quotes = records.filter((r) => r.kind === "quote");
  const blocksRaw = records.filter((r) => r.kind === "block");

  // Agent 手写 JSONL，itemId 可能抄错或漏写；先按 id 归并，
  // 归不上但名字对得上的，回填到对应商品，避免整批掉进"不在清单中"
  const idSet = new Set(items.map((it) => it.id));
  const nameMap = new Map();
  for (const it of items) {
    const n = str(it.name, 120);
    if (n) nameMap.set(n, it.id);
  }
  const byItem = new Map();
  for (const q of quotes) {
    let key = q.itemId;
    if (!key || !idSet.has(key)) {
      const byName = nameMap.get(str(q.itemName, 120)) || nameMap.get(str(q.title, 120));
      if (byName) {
        key = byName;
        q.matchedBy = "name";
      }
    }
    key = key || q.itemName || "(未标注)";
    if (!byItem.has(key)) byItem.set(key, []);
    byItem.get(key).push(q);
  }

  const itemViews = items.map((item) => {
    const list = (byItem.get(item.id) || []).slice().sort((a, b) =>
      String(a.capturedAt).localeCompare(String(b.capturedAt)),
    );
    byItem.delete(item.id);
    const rows = list.slice(-maxPerItem).map((q) => ({
      ...q,
      unitPriceNormalized: unitPriceOf(q),
      landedUnitPrice: landedUnitPrice(q, item.qty),
    }));
    const priced = rows.filter((r) => r.landedUnitPrice != null);
    const best = priced.length ? Math.min(...priced.map((r) => r.landedUnitPrice)) : null;
    return {
      item,
      rows,
      history: buildHistory(list),
      bestLandedUnitPrice: best,
      quoteCount: list.length,
      lastCapturedAt: list.length ? list[list.length - 1].capturedAt : "",
    };
  });

  // 清单里没有、但 Agent 采回来的（比如临时加问的商品）
  const orphans = [];
  for (const [key, list] of byItem) {
    const rows = list
      .slice(-maxPerItem)
      .map((q) => ({ ...q, unitPriceNormalized: unitPriceOf(q), landedUnitPrice: landedUnitPrice(q, null) }));
    orphans.push({
      itemId: key,
      itemName: list[0].itemName || key,
      rows,
      history: buildHistory(list),
      quoteCount: list.length,
    });
  }

  const blocks = blocksRaw
    .slice()
    .sort((a, b) => String(b.capturedAt).localeCompare(String(a.capturedAt)))
    .slice(0, 50);

  const today = new Date().toISOString().slice(0, 10);
  return {
    items: itemViews,
    orphans,
    blocks,
    stats: {
      itemCount: items.length,
      quoteCount: quotes.length,
      quotesToday: quotes.filter((q) => String(q.capturedAt).startsWith(today)).length,
      blocked: blocks.filter((b) => !b.resolvedAt).length,
      shops: new Set(quotes.map((q) => `${q.platform}|${q.shop}`)).size,
    },
    files: { items: p.items, quotes: p.quotes, dir: p.dir },
    serverTime: nowIso(),
  };
}

const BLOCK_REASON_LABEL = {
  login: "需要登录",
  captcha: "验证码/滑块",
  risk: "风控拦截",
  empty: "搜不到结果",
  timeout: "加载超时",
  other: "其他阻塞",
};

function csvCell(v) {
  if (v === undefined || v === null) return "";
  const s = String(v);
  return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
}

// 采购单价常是 0.0172 元/根这种量级，统一保留两位会把不同报价压成同一个数字
function fmtNum(n) {
  if (n == null || !Number.isFinite(n)) return "";
  if (n === 0) return "0.00";
  const a = Math.abs(n);
  const d = a >= 1 ? 2 : a >= 0.1 ? 3 : a >= 0.01 ? 4 : 6;
  return n.toFixed(d);
}

function exportCsv(params, ctx) {
  const snap = snapshot({ maxQuotesPerItem: 500 }, ctx);
  const itemFilter = str(params?.itemId, 60);
  const header = [
    "商品", "规格/型号", "目标数量", "采购单位", "平台", "店铺", "商品标题",
    "报价份价（元/份）", "每份数量", "折算单价（元/采购单位）", "起订量", "运费", "含运单价",
    "单价原文", "规格原文", "起订量原文", "运费原文", "链接", "采集时间", "备注",
  ];
  const lines = [header.map(csvCell).join(",")];
  const pushRows = (itemName, item, rows) => {
    for (const r of rows) {
      if (itemFilter && item && item.id !== itemFilter) continue;
      lines.push(
        [
          item ? item.name : itemName,
          item ? item.spec : r.spec,
          item && item.qty != null ? item.qty : "",
          item ? item.unit : r.packUnit,
          r.platform,
          r.shop,
          r.title,
          fmtNum(r.unitPrice),
          r.packQty ?? "",
          r.unitPriceNormalized == null ? "" : fmtNum(r.unitPriceNormalized),
          r.moq ?? "",
          fmtNum(r.shipping),
          fmtNum(r.landedUnitPrice),
          r.priceText,
          r.quantityText,
          r.moqText,
          r.shippingText,
          r.url,
          r.capturedAt,
          r.note,
        ]
          .map(csvCell)
          .join(","),
      );
    }
  };
  for (const v of snap.items) pushRows(v.item.name, v.item, v.rows);
  for (const o of snap.orphans) pushRows(o.itemName || o.itemId || "(未匹配)", null, o.rows);
  // 被登录墙/风控卡住的也算交付物的一部分，否则导出后没人知道哪几条没采到
  for (const b of snap.blocks) {
    const row = new Array(header.length).fill("");
    row[0] = "(未采到)";
    row[4] = b.platform || "";
    row[6] = b.message || "";
    row[header.length - 3] = b.url || "";
    row[header.length - 2] = b.capturedAt;
    row[header.length - 1] = `阻塞：${BLOCK_REASON_LABEL[b.reason] || b.reason}`;
    lines.push(row.map(csvCell).join(","));
  }
  const csv = "\ufeff" + lines.join("\r\n");
  return {
    filename: `quotes-${new Date().toISOString().slice(0, 10)}.csv`,
    rowCount: lines.length - 1,
    csv,
  };
}

// ---------- entry ----------

async function handle(method, params, ctx) {
  const body = params && typeof params === "object" ? params : {};
  const p = paths(ctx);

  if (method === "snapshot") {
    return snapshot(body, ctx);
  }

  if (method === "paths") {
    return { ...p, exists: { quotes: fs.existsSync(p.quotes), items: fs.existsSync(p.items) } };
  }

  if (method === "saveItems") {
    const incoming = Array.isArray(body.items) ? body.items : [];
    const prev = readJson(p.items, { items: [] });
    const prevById = new Map((prev.items || []).map((it) => [it.id, it]));
    const items = incoming.map((raw, i) => {
      const it = normItem(raw, i);
      const old = prevById.get(it.id);
      it.createdAt = old?.createdAt || it.createdAt;
      it.updatedAt = nowIso();
      return it;
    });
    writeJsonAtomic(p.items, { version: 1, updatedAt: nowIso(), items });
    return { ok: true, count: items.length, items };
  }

  if (method === "appendQuote") {
    const rec = normQuote(body.quote || body);
    rec.kind = rec.kind || "quote";
    appendJsonl(p.quotes, [rec]);
    return { ok: true, quote: rec };
  }

  if (method === "resolveBlock") {
    const id = str(body.id, 60);
    if (!id) throw new Error("resolveBlock 需要 id");
    const res = rewriteQuotes(p.quotes, p.dir, (rec, rid) =>
      rid === id ? { ...rec, resolvedAt: nowIso() } : rec,
    );
    return { ok: res.changed > 0, changed: res.changed };
  }

  if (method === "deleteQuote") {
    const id = str(body.id, 60);
    if (!id) throw new Error("deleteQuote 需要 id");
    const res = rewriteQuotes(p.quotes, p.dir, (rec, rid) => (rid === id ? null : rec));
    return { ok: res.changed > 0, remaining: res.remaining };
  }

  if (method === "clearItemQuotes") {
    const itemId = str(body.itemId, 60);
    if (!itemId) throw new Error("clearItemQuotes 需要 itemId");
    const res = rewriteQuotes(p.quotes, p.dir, (rec) =>
      str(rec.itemId, 60) === itemId ? null : rec,
    );
    return { ok: true, removed: res.changed, remaining: res.remaining };
  }

  if (method === "exportCsv") {
    return exportCsv(body, ctx);
  }

  if (method === "openDataDir") {
    return { dir: p.dir };
  }

  throw new Error(`未知方法：${method}`);
}

export { handle };
