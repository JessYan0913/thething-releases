# 询价工作台（quote-desk）

TheThing 插件面板。你维护待询价商品清单，点「开始询价」把本批任务单经 `host.askAgent` 递进当前对话；
Agent 用内建浏览器在淘宝 / 拼多多 / 1688 逐个采集，把每条结果追加进 `quotes.jsonl`；
面板轮询这个文件，实时长成可对比、可看历史价格、可导出 CSV 的表。登录墙和风控由你人工处理。

## 文件

| 文件 | 作用 |
| --- | --- |
| `plugin.json` | 插件清单：面板 id / 入口 / 样式 / RPC 入口 |
| `index.js` | 面板 UI（单文件、无 import、无 JSX，顶层同步 `define`） |
| `panel.css` | 面板样式 |
| `ui-rpc.mjs` | 服务端 RPC：清单与流水的读写、归一化、聚合、CSV 导出 |
| `parts/*.js` | `index.js` 的分段源码，改这里再 `./build.sh` 拼回去 |
| `test/rpc-check.mjs` | RPC 层闭环自检（19 项） |
| `test/render-check.mjs` | 用真实 React 19 渲染面板子组件（28 项） |
| `test/make-preview.mjs` | 拿真实快照渲染静态 HTML 预览，用于核对样式 |

## 数据落在哪

```
~/.thething/plugin-data/quote-desk/
├── items.json      # 你的待询价清单
└── quotes.jsonl    # 报价流水，一行一条，只追加
```

面板右上角「数据文件」能看到实际路径并复制。

## RPC 方法

| method | params | 说明 |
| --- | --- | --- |
| `snapshot` | `maxQuotesPerItem?` | 面板轮询用的完整视图（分组、历史、最低价、阻塞、统计） |
| `saveItems` | `items[]` | 覆盖保存清单 |
| `appendQuote` | `quote` | 追加一条记录（与 Agent 直接 `echo >>` 等价） |
| `resolveBlock` | `id` | 标记阻塞已人工处理 |
| `deleteQuote` | `id` | 删除一条报价 |
| `clearItemQuotes` | `itemId` | 清空某商品全部报价 |
| `exportCsv` | `itemId?` | 导出 CSV（含折算单价与阻塞行） |
| `paths` | — | 返回数据文件路径与是否存在 |

## 报价记录的字段契约

Agent 写 JSONL 时按这个格式，一行一条：

```json
{"kind":"quote","batchId":"b20261025-ab12","itemId":"it-xxx","itemName":"尼龙扎带 4x200","platform":"taobao","shop":"扎带厂家直营","title":"页面上的商品标题","spec":"白色","quantityText":"1000根/包","priceText":"¥18.80/包","unitPrice":18.8,"packQty":1000,"packUnit":"根","moq":1,"moqText":"1包起订","shipping":0,"shippingText":"包邮","sales":"月销 3000+","url":"https://...","note":"阶梯价说明","capturedAt":"2026-10-25T09:00:00Z"}
```

被登录墙 / 验证码 / 风控卡住时写阻塞记录：

```json
{"kind":"block","batchId":"...","itemId":"it-xxx","platform":"pdd","reason":"login|captcha|risk|empty|timeout|other","url":"...","message":"页面上看到的情况","capturedAt":"..."}
```

### 关键取值规则

- `platform` 写 `taobao` / `pdd` / `1688`，写「淘宝」「拼多多」也能归一。
- `unitPrice` 是**这一份**的实付价；`packQty` 是一份里含多少采购单位（1000根/包 → 1000）。
  面板用 `unitPrice / packQty` 折算成「每根多少钱」再比价——少了 `packQty`，比价会差两三个数量级。
- `shipping` 包邮填 `0`，未知填 `null`（不要填 0 假装包邮）。
- `unitPrice` 看不清就填 `null` 并在 `note` 里说明，别硬猜。

## 面板怎么算

- **含运单价** = 折算单价 + `运费 / 目标采购量`（没填采购量时按起订量分摊，两者都没有就只报单价）。
- **历史价格**：按「平台|店铺|链接」归并时间序列，标出上次→本次涨跌、区间低高、sparkline。
  涨跌只标在该店铺最新一条上。
- **最低价**：同商品所有报价里含运单价最低的一条，行背景高亮 + 「最低」标签。
- **高于目标价**：价格显示红色。

## 开发

```sh
./build.sh                 # parts/*.js → index.js
node test/rpc-check.mjs    # RPC 闭环
node test/render-check.mjs # 组件渲染
node test/make-preview.mjs /tmp/snap.json   # 生成 test/preview.html
```

改完代码重新装一次：

```
plugin_manager install /Applications/TheThing.app/Contents/Resources/agent/packages/app/ceshi/quote-desk
```

## 清空示例数据

```sh
rm ~/.thething/plugin-data/quote-desk/quotes.jsonl ~/.thething/plugin-data/quote-desk/items.json
```

面板下一轮轮询（3 秒）会回到空状态。
